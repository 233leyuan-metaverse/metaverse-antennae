---
name: custom-data
description: 为单个 UGC 场景对象创建、修改或删除独立自定义属性与自定义事件定义。玩家字段使用 user-data；全游戏共享字段使用 game-data。
---

# 对象自定义数据编排

## 工作流

1. 用 `inspectSceneObjectDetail` 确认唯一对象、现有 `CustomAbility`、属性和事件。
2. 缺少载体时先用 `scene_set_ability` 挂载 `CustomAbility`。
3. 使用 `object_data_manage(action="create|update|delete")` 管理对象字段；使用 `custom_event_manage` 管理事件模板和对象绑定。
4. 字段名、类型、默认值和事件参数必须来自用户需求及 Tool Schema，不复制玩家或游戏数据字段。
5. 新的运行时读写、广播、监听和业务逻辑转 `custom-component`；组件实现前必须确保字段和事件已在编辑态创建并回读。

## 边界

- 对象字段互相独立且不等同于跨会话玩家数据。
- 等级/经验使用已有 Level 能力，内置货币使用内置系统。
- 缺少 `CustomAbility` 时禁止跳过挂载直接创建字段。

## 验真

写后用对象详情核对能力、字段路径、类型、默认值、事件模板和绑定。所有运行时逻辑只引用已回读存在的字段与事件。

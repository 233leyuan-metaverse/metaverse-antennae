---
name: preset-edit
description: 创建或修改 UGC 预设资源，包括道具、武器等专用类型的资源创建，从场景对象保存预设，复制预设变体，以及修改和应用已有预设。只修改场景实例上的能力配置时使用 ability-manage；需要新的运行时逻辑时使用 custom-component。
---

# 预设编辑

预设是可复用的最小单元。本 Skill 覆盖预设的创建、修改、复制与应用，不实现新的运行时逻辑。

全局不变式（ID 纪律、不编造、写入后回读、异常处理、`preset_apply` 仅在明确要求时调用）见 AGENTS.md 第二节，此处不重复。

## 一、判定创建路径

预设有两条来源，先确定走哪条：

**路径 A：专用类型有对应的 create tool** —— 直接调用，一步产出预设。

| 类型 | 工具 | 类型专属参数 |
| ---- | ---- | ------------ |
| 道具 / 消耗品 / 可入背包物品 | `item_resource_create(name)` | — |
| 武器 | `weapon_resource_create(name, weapon_kind)` | `weapon_kind` 取值见 Tool Schema |

**路径 B：无专用 tool 的组合体** —— 先在场景中把对象、层级、能力、属性配置完整（逐阶段回读确认），再 `preset_save_objects(name, targets)` 保存。

判定依据：需求对应的类型在上表中有 create tool 就走 A，没有就走 B。不要用 B 去手工拼一个 A 能直接创建的类型。

## 二、修改已有预设

1. 先 `inspectPresetDetail` 建立基线，拿到真实 `presetAssetId` 和现有属性值。
2. `preset_edit` 写入。`properties` 只能使用当前 Tool Schema/Contract 证明的路径。
3. **`preset_edit` 内部自行管理会话**，不要拆分成打开、提交、关闭三步去调用。
4. 禁止重新创建同名资源来规避修改。

## 三、复制与应用

- 复制变体：`preset_copy_local`。用户未表达"复制/另存"时不复制。
- 同步到场景实例：`preset_apply`。

## 四、官方自带逻辑预设

官方带逻辑的资源**优先保留其内置逻辑**。修改前明确判断当前是在**追加**还是**替换**——两者的正确做法不同。

不要手工拼一个"看起来相同"的预设来替代官方资源，内置逻辑无法通过外部组合复现。

## 五、类型专属约束

**道具**
- 背包能力在运行态自动提供，**不要额外给玩家挂载**。
- 持续状态效果 → 转 `buff-edit` 创建 Buff 后再关联。
- 需要上架商店 → 把真实 `presetAssetId` 交给 `shop-edit`。
- 使用、拾取、发放的新增运行时逻辑 → 转 `custom-component`。

**武器**
- 给角色装备已有武器 → 转 `ability-manage` 配置 `WeaponSlotAbility`，不在本 Skill 内处理。
- 外观、动画、音效、特效必须来自对应类型的**真实资源查询结果**，不使用记忆中的资源名。
- 攻击、命中、击杀等新运行时逻辑 → 转 `custom-component`。

## 六、放入场景

用户明确要求时调用 `scene_create_object(asset_id=<presetAssetId>, ...)`。

## 七、验真

写入后立即回读，核对项按操作类型区分：

| 操作 | 回读工具 | 核对内容 |
| ---- | -------- | -------- |
| 创建 / 修改预设 | `inspectPresetDetail` | 资源类型、能力、属性、外观、事件 |
| 路径 B 保存 | `inspectPresetDetail` | 预设 ID、分类、根节点、层级、能力、属性、事件 |
| `preset_apply` | 实例详情 | 更新实例数，以及目标实例的实际状态 |
| 放入场景 | 场景对象详情 | 对象的 `presetAssetId` 与 transform |

路径 B 的临时宿主对象，只在保存成功且确认不再需要后删除，并**报告任何残留**。

最终报告：目标、实际产出的预设 ID、属性改动、验证结果、未实现的缺口。

---
name: conversation-edit
description: 创建和维护 UGC 对话组、对话内容、选项及按钮绑定。NPC 外观和交互入口使用 ability-manage；选项触发后的新业务逻辑使用 custom-component。
---

# 对话编排

所有编辑态对话数据统一使用 `conversation_manage(entity, action, group_name?, settings?)`。

## 创建流程

1. 创建唯一对话组：`entity="group", action="create"`。
2. 创建内容：`entity="config", action="create"`，明确说话人、正文和 config index。
3. 每个选项先创建全局 option 数据，再给 config 添加按钮槽并绑定；index 从 0 开始。
4. `btnId` 必须符合当前 Tool Schema 并在后续调用中原样复用，显示文字单独保存。
5. 选项点击后的商店、任务、传送或分支逻辑转 `custom-component`；NPC 互动入口转 `ability-manage`。

## 约束与验真

- `bind_button` 前必须已有 option 和按钮槽。
- 不传底层操作码，不从场景猜玩家实体。
- 每步读取结构化结果并检查当前对话域状态；partial 时先查重，避免重复创建选项。
- 完成时核对组、内容顺序、选项、按钮槽和绑定关系。

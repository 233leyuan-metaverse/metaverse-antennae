---
name: skill-create
description: 创建、复制、修改、删除和保存 UGC 技能资源，并编排技能时间轴、动画、特效、音频和投射物 Task。把已有技能装备到对象时使用 ability-manage。
---

# 技能资源编排

## 工具路由

- CRUD：`skill_create`、`skill_copy`、`skill_update`、`skill_delete`、`skill_save`。
- 时间轴：`skill_timeline_add`、`skill_timeline_modify`、`skill_timeline_remove`、`skill_timeline_set_duration`。
- 新的自定义 Task 或跨时间轴运行时逻辑：`custom-component`。

## 工作流

1. 创建或复制后只使用工具返回的真实 `skillId`。修改前读取技能详情和完整时间轴。
2. `skill_update.field` 仅使用 Tool Schema 枚举；不替用户补未要求的冷却、消耗、伤害、击退或状态效果。
3. 添加 Timeline Task 前先 inspect 当前 Task Catalog。动画、特效、音频和投射物必须来自对应类型的真实资源。
4. 以动作时长和关键帧为基准安排其他 Clip；总时长不得短于任一 Clip 的结束时间。
5. 修改完成后调用 `skill_save`。把技能装备到对象转 `ability-manage`。
6. 删除是破坏性操作，只有用户明确要求且目标 ID 唯一时执行。

## 验真

用技能详情 readback 核对名称、描述、冷却、资源、总时长、轨道、Clip 类型、起止时间和 Task 字段。资源存在但全部 Clip 无依据地从 0 开始不算完成。

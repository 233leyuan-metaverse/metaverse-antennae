---
name: environment-edit
description: 配置 UGC 全局天空、天气、昼夜、环境光、背景音乐及音乐/音效音量。对象局部灯光或特效使用 ability-manage。
---

# 全局环境编排

## 天空与天气

1. 修改前查询可用天空模板和当前状态。
2. 使用 `sky_configure(reset=false, settings=...)` 修改，只传用户要求变化的字段；恢复默认用 `reset=true`。
3. 模板 ID 和枚举必须来自查询结果或 Tool Schema。

## BGM 与音量

- `bgm_configure(mode="music")` 切换 BGM，成对传真实 `musicGuid` 与资源原名 `musicName`。
- `mode="music_volume"|"sound_volume"` 只传 `[0,1]` 的 `settings.volume`。
- 停止 BGM 使用 Contract 支持的空资源值；不编造描述性音乐名。

运行时天气、昼夜或音乐切换的新逻辑转 `custom-component`。写后回读天空模板、修改字段、BGM GUID/名称及音量；再提醒用户进入运行态确认视觉和听感。

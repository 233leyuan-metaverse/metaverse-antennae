---
name: game-config
description: 创建、更新或删除 UGC 游戏配置表，维护表结构、数据行和单元格。适用于怪物、掉落、关卡、奖励等静态配置；运行时状态使用 user-data、custom-data 或 game-data。
---

# 游戏配置表编排

## 工作流

1. 先用 `inspect(operation="sideapi_game_config_all_basic_info", request_json={})` 读取基础信息，按精确表名取得真实 `fileId`。
2. 再用 `inspect(operation="sideapi_game_config_details", request_json={"fileIdList":["<fileId>"]})` 读取当前结构和数据。
3. 使用 `game_config_manage`：整表 `upsert/upsertTable`，行操作 `upsertRows/deleteRows`，单元格 `setCells`，删除表 `deleteTable`。
4. 新建表通常不传 `id`；更新、删除和增量操作的 `settings.id` 必须使用基础信息回读的真实 `fileId`。
5. AI 只传业务列、行和值，不传 Head、内部列描述、Base64 或文件路径。客户端生成的首列行名字不放进 `cols/rows`。

当前详情响应没有独立 `tableId`。不要生成、猜测或用别的 ID 替代 `fileId`；若未来流程确实要求独立表 ID、而实时响应仍未提供，停止并报告接口缺口。

## 模型侧数组编码

当前工具把 `cols` 与 `rows` 暴露为字符串数组。每个字符串必须是一个序列化 JSON 数组；MCP 会在发给编辑器前还原为真实数组。例如：

```json
{
  "name": "怪物配置",
  "cols": ["[\"怪物名称\",\"String\"]", "[\"生命值\",\"Number\"]"],
  "rows": ["[\"史莱姆\",100]", "[\"哥布林\",180]"]
}
```

不要把列编码成序列化对象字符串（如 `{"name":"怪物名称","type":"String"}`）。`cells` 继续使用三元素数组 `[行名字, 列名, 值]`；行名字取详情回读中的系统行名字。

## 类型约束

- 未经用户要求不要自动添加 ID/编号/索引列。
- 颜色语义使用 `Color`，资源引用只传真实 `assetId`，实体引用只传真实 `gameObjectId`。
- 增量操作不改变列结构；`setCells` 使用回读的真实行名字和列名。
- 引用无法解析时停止，不编造 ID。

## 验真

每次写入后都重新读取基础信息和详情，精确核对：

- 基础信息中的表名、描述和 `fileId`；
- 详情中的 `fileName`、`catalogueDescript`、`name`，以及 `Head` 的列名、类型和稳定列 ID；
- `Data` 的系统行名字、行数和全部改动单元格；
- 增量修改前后未触碰列的 ID、未触碰行和未触碰单元格保持不变。

只有这些语义值全部匹配才算成功。失败、timeout、partial 或 `READBACK_MISMATCH` 时先读取基础信息和详情协调真实落盘状态，禁止盲目重复创建或更新。

---
name: custom-component
description: 为 UGC 项目设计、创建或修改用户自定义组件源码，实现依赖官方组件或系统的运行时玩法逻辑。适用于组件职责拆分、API 实现、依赖装配、事件编排、属性暴露、生命周期清理和日志诊断；只需组合已有能力或组件时使用 ability-manage。
---

# UGC 自定义组件实现

生成内聚、可配置、可清理、可诊断的用户组件。官方组件和系统是依赖与权威状态来源；自定义组件只补充缺失的运行时行为或协调多个所有者，不复制官方状态。

## 证据检索顺序

按需渐进读取，不要一开始加载整个声明库：

1. 读取 `manifest/components/index.json`，用一句话描述初选官方组件。
2. 对每个候选读取 `manifest/components/<path>/component.manifest`，确认精确组件名、属性、事件、网络语义、限制和配套声明。必要时查看同目录 `component.json`，但不得用它推翻 manifest 的限制。
3. 玩法组件和 UGC API 优先在 `engine-docs/ugc` 中搜索相关 `.d.ts`。凡是代码中出现 `mw.*` 符号或基础数据类型，必须继续读取 `engine-docs/engine` 中对应声明；它是 MW 引擎层 API 的权威来源。
4. UGC 与 MW 都不能证明签名、类型、事件或清理方式时，停止该部分实现并报告证据缺口。不得凭记忆编造 API，也不要自动下探 UE。
5. 用户组件发现与读取只走工程本地文件。枚举 `DataFile/userComponent/description/*.data`，解析其中的 `classId`、`componentName`、`componentDescription`、`componentRevision` 及完整托管数组；源码读取 `DataFile/userComponent/classes/<classId>.js.mfile`。禁止调用已屏蔽的 `inspectUserComponents`、`inspectUserComponentApi` 或 `sideapi_user_component_read`。

`manifest` 是工程根目录下的实际目录名，不要添加 `cli/` 前缀或改写目录名。组件名、系统名、事件名、参数类型和返回值必须来自以上证据。

### `mw.*` 基础类型

- `mw.Vector`、`mw.Rotation`、`mw.Transform`、`mw.LinearColor` 等基础类型也属于 API 证据，不得凭名称、经验或示例猜测其结构和用法。
- 在 `engine-docs/engine` 中核对实际类型名、构造函数、静态成员、字段范围、可变性、参数类型和返回类型后才能编码。颜色类型应以声明中的 `mw.LinearColor` 为准，不得擅自写成 `mw.LineColor`。
- 即使 UGC 声明把这些类型用作参数或返回值，也必须到引擎层读取类型本身；不要为了基础类型自动下探 `engine-docs/ue`。

## 客户端运行时 API

声明中的 `runtime=client` 只说明静态调用约束，不证明当前 UserComponent 实例的执行 peer，也不证明已连接运行时已加载相同方法。当前 Apply 协议没有 execution-side 字段时，不得承诺或命名一个“client-only UserComponent”。

- 调用前检查单例和必需方法；非异步功能缺失时报告稳定的 `runtime_api_unavailable`，不要通过重复 Apply 修复版本漂移。对声明明确说明在 `initialize()` 前未就绪的单例，可按对应 domain Skill 做低频、有上限的就绪重试。
- 访问客户端运行时单例前，必须用声明证明的精确类名调用 `api.js.getClassByName(...)`，并检查返回类及所需静态方法均已就绪。
- 把 `CLIENT_ONLY` 当作当前 peer 的结构化停止结果；JavaScript exception 必须保留准确调用 stage，不能反推成 `CLIENT_ONLY`。
- 源码、revision 和 reload 回读只证明安装成功。运行态成功必须有 API 结果及语义读回；涉及客户端 UI 时还要完整遵循 `ui-edit` 的运行态属性门禁和视觉验收级别。
- 订阅 `UIModuleSystem.onClientUIButtonClicked` 时必须完整读取 `ui-edit/references/client-button-events.md`：绑定前 query 真实 target，保持 UDelegate owner/handler 引用稳定，精确过滤事件，并在 `Destroy` 用同一引用解除。

## 职责拆分

写代码前记录精简规划：组件、状态所有者、触发器/生命周期、单一职责、依赖、公开配置和清理责任。

- 同一领域、同一状态所有者、兼容生命周期且共同完成一个职责的逻辑留在一个组件。
- 状态所有者、生命周期、复用、权限、故障隔离或启停方式不同，才拆成多个组件。
- 官方组件已拥有的状态留在官方组件；协调器只编排，不复制状态。
- 优先复用职责一致的已有用户组件。只有真正独立的职责边界才创建新组件。

## 依赖装配

所有官方组件和系统都使用字符串名称访问。禁止把类构造器、导入类或猜测的类型对象传给这些入口。

依赖组件时必须先取后补并保存引用，不得无条件重复添加：

```js
let touchDetector = this.entity.getComponent("TouchDetectorComponent");
if (!touchDetector) {
  touchDetector = this.entity.addComponent("TouchDetectorComponent");
}
```

- 每个 `getComponent`、`addComponent` 都必须传字符串字面量，如 `getComponent("XXX")`、`addComponent("XXX")`。
- 字符串必须是对应 `component.manifest` 证明的精确组件名。
- 缺失但不允许添加，或添加失败时，记录诊断并安全退出，不得继续解引用。
- 只读取依赖时不要在销毁阶段移除官方组件；只回收本组件创建且契约要求清理的资源。

场景系统也使用字符串：

```js
const system = this.entity.scene.findSystem("XXX");
```

系统名和 API 必须由声明证明。未找到时按可选或必需依赖降级或终止，不制造替代系统。

## 属性暴露

只把用户需要配置、且不同实例可能不同的稳定参数放入 `properties`：

- 适合暴露：开关、阈值、次数、时间、范围、文案、资源/目标引用和玩法调参。
- 保持私有：组件/系统缓存、监听与计时器句柄、派生值、瞬时状态、内部计数和实现细节。
- 每个公开属性提供清晰名称、说明、准确类型和安全默认值。
- 不暴露 `classId`、revision、日志参数或可从官方组件读取的重复状态。
- 在绑定事件或启动行为前验证配置；无效时记录诊断并安全停止。

## 生命周期与清理

- 初始化阶段获取依赖、验证配置并绑定监听，避免重复初始化和订阅。
- 保存每个外部事件的回调、句柄或订阅对象，使用声明证明的解除 API。
- 在 `onDestroy` 对称解除所有外部监听，停止计时器/调度任务，取消异步回调并释放临时资源。
- 监听其他组件事件时必须在 `onDestroy` 移除；无法解除的匿名回调不得用于长期订阅。
- 清理必须可重复调用、兼容部分初始化，并在依赖已销毁时安全返回。
- 优先事件和定时器；`Update` 中不得无界重复查/加组件、找系统或打印日志。只有声明已证明存在异步初始化窗口时，才允许按 domain Skill 用低频、有上限的就绪尝试。
- 异步物化对象的就绪重试必须是明确状态机：`Started` 首次尝试，`Update` 只低频计数和调用单一尝试方法，成功、终止结果或超过上限后停止重试。

## 日志

- `UserComponentRuntimeBase` 已提供 `protected log(...args)`、`warn(...args)` 和 `error(...args)`；组件方法中直接调用 `this.log(...)` / `this.warn(...)` / `this.error(...)`，不要自建日志函数、不要直接查找 `LogSystem`，也不要把日志函数加入托管 `functions`。
- 这些方法在试玩态缓存日志；退出试玩并**回到编辑态后**，编辑器才会将本轮缓存落盘到工程的 `DataFile/demoLogFile.data`。不得在试玩中或切回完成前以“文件不存在/未更新”判定日志失败。
- 需要运行时验证时，引导用户触发关键路径，然后退出试玩回到编辑态；确认已回到编辑态后，再读取 `DataFile/demoLogFile.data` 并按时间、级别和组件名核对本次输出。日志文件只证明已执行到相应记录点，业务完成仍需要求的语义读回。
- 日志参数会以空格拼接，只传可读的标量或有界摘要；如需结构化信息，先显式格式化成稳定字符串。
- 状态所有者记录权威结果，协调器不重复成功日志。
- 禁止记录密钥、完整对象或无界负载；禁止从 `Update` 直接调用日志辅助方法。

## 写入与验真
1. 新职责用 `sideapi_user_component_create` 创建，`classId` 只能由编辑器生成。结果不明确时重新枚举 `DataFile/userComponent/description/*.data`，按 `classId`、组件名和职责协调，禁止盲目重建。
2. 修改前从 `description/<classId>.data` 获取正数 `componentRevision` 和完整托管状态，并从 `classes/<classId>.js.mfile` 读取当前源码。文件缺失、JSON 无法解析、classId 不一致或 revision 非正数时停止。
3. 用该 revision 调用 `sideapi_user_component_apply`。`description`、`properties`、`fields`、`functions`、`lifecycleHooks` 和 `events` 都是完整替换；修改现有组件时保留无关条目。
4. 一次只应用一个规划组件。Apply 后重新读取同一 `.data` 与 `.js.mfile`，要求 revision 递增，并核对源码、公开属性、字符串依赖、事件绑定/解绑和日志方法；本地文件尚未刷新时不得宣称完成。
5. 可试玩时触发关键路径，引导用户退出试玩并回到编辑态；仅在切回完成后读取 `DataFile/demoLogFile.data` 验证 `this.log` / `this.warn` / `this.error` 记录点。无法确认已回到编辑态时，请用户完成切回后再读，不要用旧文件作为本轮运行证据。

完成前确认：组件依赖均为“字符串 get → 缺失时字符串 add”，系统均为字符串 `findSystem`，API 遵循 UGC→MW 顺序，每个外部订阅都有 `onDestroy` 对称清理，公开属性只含用户配置，职责内聚，并已取得精确语义回读。

---
name: game-data
description: 创建、修改或删除全游戏、全房间共享的一份 UGC 数据字段。每个玩家独立的数据使用 user-data；单个对象状态使用 custom-data。
---

# 游戏级共享数据编排

## 工作流

1. 用 `sideapi_inspect(operation="inspectGameData")` 按 `uuid` 或 `displayName` 查重。
2. 使用 `game_data_manage(action="create|update|delete", property_id, settings)`，只传公开业务字段。
3. 类型使用 Tool Schema 支持的精确枚举；`Date` 默认值使用 `0`。只有明确需要跨房间同步时才同时配置广播和持久化。
4. 金币/派对币不是游戏级共享字段。游戏配置表也不是运行时共享状态。
5. 若当前 API 无法完成运行时读写，明确报告缺口；需要代码实现时转 `custom-component`，不得编造属性路径或指令。

## 验真

写后再次 inspect，核对 uuid、显示名、类型、默认值、持久化与广播设置。失败不等于未落盘；重试前必须协调实际状态。

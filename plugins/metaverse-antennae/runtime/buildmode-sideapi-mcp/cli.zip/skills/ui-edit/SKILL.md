---
name: ui-edit
description: 创建或修改 UGC 屏幕 UI、HUD、弹窗、表单和世界 UI，管理控件树、样式、属性绑定与交互入口。UI 触发后的新业务逻辑使用 custom-component。
---

# UI 编排

## 工作流

1. 用 `inspectUiTree` 发现画布和控件，用 `inspectUiDetail` 读取选定目标；修改任务必须保留未要求变化的结构与样式。
2. 创建或重建 UI 使用 `build_ui_screen` 的 `screenSpec`。显式填写 `surface="screen"|"world"`，字段仅来自当前 Tool Schema，禁止猜 CSS 风格字段。
   - `RankList`、技能按钮、摇杆及跳跃/攻击/换弹/瞄准专用按钮使用 `tree` 的真实专用节点；字段表见 [专用控件参考](references/specialized-widgets.md)，禁止用通用 `image`/`button` 冒充。
3. 属性绑定使用 `ui_bind_property(action="bind"|"unbind")`；先验证目标画布/控件、数据源、属性路径和类型。
4. World UI 需要宿主能力或挂载时配合 `ability-manage`。按钮、输入框等触发后的新运行时业务逻辑转 `custom-component`。

## 接管人工 UI

编辑器中人工创建的画布或控件不得用 `build_ui_screen` 重建。固定走以下 MCP 语义流程：

1. 用 `inspectUiTree` / `inspectUiDetail` 定位真实 `canvasGuid` 和 `widgetGuid`，再用 `inspectPropertyValues` 读取待改 canonical path 的当前值。
2. 调用 `ui_widget_adopt`。首次可以省略 `expected_source_sha256` 以取得 `sourceSha256`；确认目标未变后，把该值原样传回第二次调用。它只确认人工控件的实时身份、父子树和已有 AI context；`description/role/tags` 作为本次语义意图回显，不为它们重写整张 `.ui`。
3. 调用 `ui_widget_patch`，将当前 `sourceSha256After` 传入 `expected_source_sha256`，且 `expected_values` 必须与 `changes` 含有完全相同的路径和精确旧值。只使用当前 Tool Schema 暴露的白名单路径。工具通过编辑器原位属性命令修改已挂载控件，由编辑器 dirty-document 增量保存链持久化；禁止卸载、替换或重挂整张画布。
4. SHA 或旧值冲突时立即停止并重新发现；禁止绕过保护、直接改项目 `.ui` 文件或重复非幂等 save。只有 `outcome="succeeded_verified"`、每个 `propertyReadback.ok=true` 且 `structureReadback.ok=true` 才算设计态修改完成。`canonicalDiskPersistenceObserved=false` 只表示本次返回时编辑器还未将 dirty document 刷到磁盘，不得因此转用整画布 save/mount。

## 设计约束

- 先明确信息层级、布局、交互状态和响应反馈，再生成控件；不要堆叠无关控件。
- 默认文字、颜色、显隐、尺寸、间距和资源 ID 必须忠于需求或回读值。
- 初次生成控件时，图片资源选择不得隐式覆盖控件自身的图片绘制默认值；通用 Image、Button、ProgressBar 图片槽保持 `CustomUIProperties` 声明的默认 Image 绘制与默认边距。只有用户明确要求且当前 Tool Schema 暴露对应属性时才改变绘制方式。
- 修改已有 UI 时只改请求字段，不顺手换色、重排或重命名。
- 世界 UI 必须结合宿主 `boundSize`、朝向与画布尺寸计算 transform，不凭感觉猜位置。
- MCP 的 `build_ui_screen` 会把视觉丰富度问题放入 `uiQuality.advisoryIssues`；可以发送不等于可忽略它们，仍应按用户需求修正。`blockingIssues` 是结构/安全问题，不得绕过。

## 客户端按钮事件

使用 UserComponent 响应 Screen/World UI 按钮时，必须完整读取并遵循 [客户端按钮事件可靠绑定](references/client-button-events.md)。该流程使用真实目标查询作为物化门禁，有界处理初始化时序，并对非 client peer 安全终止。

## 当前客户端运行态属性

只把 `setClientUIRuntimeProperty` 用于当前客户端临时、未绑定的视觉覆盖。多人一致或服务端权威显示使用同步业务数据后的属性绑定或已有 UI Instruction；默认值和设计态修改仍使用原画布、原 GUID 的 `build_ui_screen`。

运行态路线必须同时加载 `custom-component`，并满足以下门禁：

1. 从 `inspectUiDetail` 取得真实 `canvasGuid`、`widgetGuid`；World UI 还必须取得真实宿主 `ownerGuid`。
2. 用 `api.js.getClassByName("UIModuleSystem")` 获取类和单例，不直接引用沙箱未注入的 `UIModuleSystem`、`ClientUIRuntimeSurface` 或 `ClientUIRuntimeResultCode`。调用前确认 query/schema/get/set/clear 五个方法均为函数；缺失即报告 `runtime_api_unavailable`，静态声明不能替代此 live preflight。
3. 固定执行 `queryClientUIRuntimeTarget → getClientUIRuntimePropertySchema → setClientUIRuntimeProperty → getClientUIRuntimeProperty`。只使用 Schema 返回的 canonical path，并要求 `writable=true`、`bound=false`。
4. `CLIENT_ONLY` 是当前 peer 的正常结构化结果，不是 JavaScript 异常。只有 `TARGET_NOT_READY` 可以在同一 target 上有界重试；`CLIENT_ONLY`、`BOUND_PROPERTY`、`INVALID_VALUE` 和 `UNSUPPORTED_PROPERTY` 不重试。
5. `set` 成功后立即 `get`，精确比较 `effectiveValue`。源码/revision 回读最多是 `source_installed`；无运行态证据为 `runtime_unverified`；精确读回为 `runtime_readback_verified`；再有视口截图或用户明确视觉验收才是 `visual_verified`。
6. 异常按 `module/query/schema/set/get/clear` 记录准确 stage。运行态失败时冻结设计态 UI，不重建画布、不复制控件、不改背景；视觉替代方案必须由用户单独确认。

## 验真

写入后用 `inspectUiDetail` 核对画布归属、控件树、GUID、文本、样式、显隐和绑定，再用 `inspectPropertyValues` 检查关键路径。需要验收重载后持久性时，等编辑器完成增量保存或用户显式保存后重新回读；不得由 MCP 代替编辑器整张重挂。最后提醒用户进入运行态手动验证交互和不同分辨率表现。

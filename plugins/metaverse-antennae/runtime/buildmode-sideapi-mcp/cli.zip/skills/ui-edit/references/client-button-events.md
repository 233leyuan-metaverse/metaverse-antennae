# 客户端 UI 按钮事件可靠绑定

## 必要证据

编码前从 `engine-docs/ugc/ui.d.ts` 确认 `UIModuleSystem`、`ClientUIRuntimeTarget`、`ClientUIButtonRuntimeEvent` 和结果码，从 `engine-docs/ugc/common.d.ts` 确认 `UDelegate.add/remove`。从 `inspectUiDetail` 取得真实 `canvasGuid` / `widgetGuid`；World UI 还要取得真实宿主 `ownerGuid`。

- `surface` 只使用声明证明的字符串 `"screen"` 或 `"world"`，不在沙箱中直接引用未注入的枚举。
- Screen 事件的 `ownerGuid` 必须是空字符串；World 事件必须匹配宿主 GUID。
- `ClientUIButtonRuntimeEvent` 不含 `canvasGuid`：画布 GUID 用于绑定前 `queryClientUIRuntimeTarget`，事件回调则精确过滤 `surface + widgetGuid + ownerGuid`，不得猜一个不存在的事件字段。

## 状态机

1. `Started` 立即尝试一次。`UIModuleSystem.ins` 在子系统 `initialize()` 之前可以未定义；本地类/单例/delegate 未就绪可以低频、有上限重试。
2. 每次真正绑定前都调用 `queryClientUIRuntimeTarget(target)`。结果为 `TARGET_NOT_READY` 时保留重试；`CLIENT_ONLY` 说明当前实例不在 client peer，立即进入终止态。其他失败码不重试。
3. 查询成功后才向 `onClientUIButtonClicked` 订阅。listener owner 和 handler 都保存为稳定实例字段；绑定成功后不再重试，禁止重复 add。
4. `Update` 只递增私有计数并低频触发就绪尝试；到达上限后进入终止态。不在 `Update` 直接找系统、重复 add 或记录日志。
5. `Destroy` 用完全相同的 delegate / owner / handler 引用调用 `remove`，并将状态置为终止；清理允许在部分初始化状态重复调用。

## UserComponent 函数模板

下列代码是普通类方法。把 GUID 和 surface 作为已验证的公开配置或生成时常量；计数器、delegate 和 handler 保持私有。示例的 `handleVerifiedUIButtonClick` 由具体业务实现。

```js
startUIButtonBinding() {
  if (this.uiButtonBound || this.uiButtonTerminal) return;
  this.tryBindUIButtonClick();
}

tryBindUIButtonClick() {
  if (this.uiButtonBound || this.uiButtonTerminal) return;

  const UiModuleClass = api.js.getClassByName("UIModuleSystem");
  const uiModule = UiModuleClass?.ins;
  const delegate = uiModule?.onClientUIButtonClicked;
  if (!uiModule || typeof uiModule.queryClientUIRuntimeTarget !== "function" ||
      typeof delegate?.add !== "function" || typeof delegate?.remove !== "function") {
    this.uiButtonWaitingForModule = true;
    return;
  }
  this.uiButtonWaitingForModule = false;

  const target = {
    surface: this.uiSurface,
    canvasGuid: this.uiCanvasGuid,
    widgetGuid: this.uiWidgetGuid,
    ownerGuid: this.uiSurface === "world" ? this.uiOwnerGuid : "",
  };
  const targetResult = uiModule.queryClientUIRuntimeTarget(target);
  const resultCode = String(targetResult?.code ?? "");
  if (resultCode === "CLIENT_ONLY") {
    this.uiButtonTerminal = true;
    return;
  }
  if (!targetResult?.ok) {
    if (resultCode !== "TARGET_NOT_READY") this.uiButtonTerminal = true;
    return;
  }

  if (!this.uiButtonListenerOwner) this.uiButtonListenerOwner = {};
  if (!this.uiButtonHandler) {
    this.uiButtonHandler = (event) => {
      const expectedOwnerGuid = this.uiSurface === "world" ? this.uiOwnerGuid : "";
      if (event?.surface !== this.uiSurface ||
          event?.widgetGuid !== this.uiWidgetGuid ||
          event?.ownerGuid !== expectedOwnerGuid) return;
      this.handleVerifiedUIButtonClick(event);
    };
  }
  delegate.add(this.uiButtonListenerOwner, this.uiButtonHandler);
  this.uiButtonDelegate = delegate;
  this.uiButtonBound = true;
}

updateUIButtonBinding() {
  if (this.uiButtonBound || this.uiButtonTerminal) return;
  this.uiButtonRetryTick += 1;
  if (this.uiButtonRetryTick < 15) return;
  this.uiButtonRetryTick = 0;
  this.uiButtonRetryCount += 1;
  if (this.uiButtonRetryCount > 20) {
    this.uiButtonTerminal = true;
    return;
  }
  this.tryBindUIButtonClick();
}

stopUIButtonBinding() {
  if (this.uiButtonDelegate && this.uiButtonListenerOwner && this.uiButtonHandler) {
    this.uiButtonDelegate.remove(this.uiButtonListenerOwner, this.uiButtonHandler);
  }
  this.uiButtonBound = false;
  this.uiButtonTerminal = true;
  this.uiButtonDelegate = null;
}
```

生命周期 body 保持只做编排：

```js
// Started
this.startUIButtonBinding();

// Update
this.updateUIButtonBinding();

// Destroy
this.stopUIButtonBinding();
```

需要的私有初始状态至少包括：`uiButtonBound=false`、`uiButtonTerminal=false`、`uiButtonWaitingForModule=false`、`uiButtonRetryTick=0`、`uiButtonRetryCount=0`、`uiButtonListenerOwner=null`、`uiButtonHandler=null`、`uiButtonDelegate=null`。

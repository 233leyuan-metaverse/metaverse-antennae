# build_ui_screen 专用控件

仅用于 `surface:"screen"` 的 `tree`。所有节点支持 `id/name`、`w/h`、`visible`、`opacity`、`description/role/tags`。

| type | 控件 | 额外字段 |
|---|---|---|
| `ranklist` | 排行榜 | 下述排行属性字段 |
| `skill-button` | 技能按钮 | `skillNumber`（非负整数） |
| `joystick` | 移动摇杆 | 无 |
| `jump-button` | 跳跃按钮 | 无 |
| `hot-weapon-fire` | 热武器攻击按钮 | 无 |
| `hot-weapon-joystick` | 热武器攻击摇杆 | 无 |
| `hot-weapon-reload` | 换弹按钮 | 无 |
| `hot-weapon-aim` | 瞄准按钮 | 无 |
| `melee-weapon-fire` | 近战攻击按钮 | 无 |

排行榜无需另建绑定或配置，只选择真实属性：

- 能力属性排行：`dataType:"componentData"` + `abilityName` + `propertyName`。
- 玩家自定义属性排行：`dataType:"userCustomData"` + `userPropertyKey`；key 必须来自 `inspectUserData` 回读。
- `rankScope:"global"` 表示全服，`rankScope:"room"` 表示本房间。
- 可选字段：`title`、`useBigNumberFormat`。

```json
{
  "surface": "screen",
  "kind": "hud",
  "title": "排行榜",
  "tree": {
    "type": "ranklist",
    "id": "level_rank",
    "title": "排行榜",
    "dataType": "componentData",
    "rankScope": "global",
    "abilityName": "LevelAbility",
    "propertyName": "level"
  }
}
```

禁止把 `RankList` 做成文本列表，也禁止用图片或普通按钮模拟专用操作控件。

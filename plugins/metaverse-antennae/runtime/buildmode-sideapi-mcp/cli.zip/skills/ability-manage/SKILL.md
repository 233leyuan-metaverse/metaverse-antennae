---
name: ability-manage
description: 在 UGC 项目中为场景对象或预设选择、挂载、移除、组合并配置已经存在的官方能力与用户自定义组件。适用于已有能力/组件编排和属性修改；需要实现或修改自定义组件源码时使用 custom-component。
---

# UGC 已有能力与组件编排

把玩法意图落实为最小、可验证的已有能力组合。本 Skill 不实现新的自定义组件源码。

## 权威数据源

1. 读取 `manifest/abilities/index.json`，按 `path` 初选官方能力，再读取候选目录的 `body.md`；仅在需要时读取 `reference.md` 和 `examples.md`。
2. 用户组件只从工程本地文件发现：枚举 `DataFile/userComponent/description/*.data` 获取真实 `classId`、组件名、说明、revision 和公开配置；需要理解实现时读取 `DataFile/userComponent/classes/<classId>.js.mfile`。禁止调用已屏蔽的 `inspectUserComponents`、`inspectUserComponentApi` 或 `sideapi_user_component_read`。
3. 工具 schema、能力文档和实时回读是事实来源。不得编造能力名、组件、`classId`、属性路径、枚举、事件或资源 ID。

`manifest` 是工程根目录下的实际目录名，不要添加 `cli/` 前缀或改写目录名。

## 工作流

### 1. 读取目标基线

- 区分场景对象与预设，解析唯一目标；名称不唯一时先检查，不要猜测。
- 场景对象用 `inspectSceneOverview` 完整分页发现，再用 `inspectSceneObjectDetail` 读取现有能力、组件、属性和绑定。
- 预设用 `inspectPresetDetail` 读取现有结构和属性。
- 明确要保留、添加、移除、组合和修改的内容，只触碰用户要求的部分。

### 2. 设计最小组合

- 将每项需求映射到已证明存在的官方能力或已有用户组件，并记录各自职责和依赖。
- 官方能力能完成时优先配置官方能力；已有用户组件已拥有该职责时直接复用，避免重复状态、监听和生命周期逻辑。
- 如果现有能力与组件不能实现需求，停止该部分写入并转用 `custom-component` 实现新职责；不得用相近组件冒充。

### 3. 写入

- 场景对象使用 `scene_set_ability` 挂载或移除官方能力。遵守能力文档声明的内置、自动注入或不可挂载限制。
- 必须先确认能力已挂载，再用 `scene_configure_ability` 写文档证明可编辑的属性路径；当前值已满足时不制造无意义写入。
- 能力文档指定槽位、对象数据或其他专用语义工具时，使用专用工具，不强行改成通用属性写入。
- 预设使用 `preset_edit` 修改 Contract 证明的属性；需要同步场景实例时再用 `preset_apply`。
- 已有用户组件只按其公开契约组合和配置。本 Skill 不创建新组件、不改组件源码，也不自行生成 `classId`。

### 4. 精确验真

- 每次写入后立即回读；工具返回 success 不能替代验证。
- 场景对象用 `inspectSceneObjectDetail` 验证能力/组件，再用 `inspectPropertyValues` 验证所有改动路径和值。
- 预设用 `inspectPresetDetail` 验证提交结果；应用到实例后继续检查目标实例。
- 结果不明确时先回读协调真实状态，再决定是否重试，禁止盲目重复非幂等操作。

只有全部请求均取得精确语义回读才算完成。最终报告目标、实际组合、属性改动、验证结果和未实现缺口。

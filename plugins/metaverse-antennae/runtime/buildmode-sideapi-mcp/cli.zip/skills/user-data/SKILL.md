---
name: user-data
description: 创建、修改或删除每个玩家各自拥有的 UGC 数据字段，可选择跨会话持久化。对象级状态使用 custom-data；全游戏共享状态使用 game-data。
---

# 玩家数据编排

## 选域门禁

- 每个玩家各一份：本 Skill。
- 单个场景对象各自拥有：`custom-data`。
- 全游戏/全房间共享一份：`game-data`。
- 静态数值表：`game-config`。

目标不是玩家或字段不属于玩家时禁止使用本 Skill。金币、派对币等内置货币不得重复创建为玩家数据。

## 工作流

1. 用 `sideapi_inspect(operation="inspectUserData")` 按稳定英文 `uuid/property_id` 或显示名查重。
2. 使用 `user_data_manage(action="create|update|delete", property_id, settings)`；settings 只含 Tool Schema 字段，不接受 `gameObjectId`。
3. 明确类型、默认值和 `saveKV`。跨会话数据才启用持久化，不因“可能有用”默认开启。
4. 需要运行时读写、计分或事件联动时转 `custom-component`，并以真实玩家实体为目标。

## 验真

写后再次 inspect，核对 uuid、显示名、类型、默认值和持久化设置。结果不明确时先回读；已存在则更新，禁止重复创建同一字段。

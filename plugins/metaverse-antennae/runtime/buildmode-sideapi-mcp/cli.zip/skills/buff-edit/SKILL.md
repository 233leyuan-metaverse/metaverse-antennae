---
name: buff-edit
description: 创建、修改或删除 UGC Buff 基础数据，包括持续时间、周期、标签和基础状态配置。Buff 生命周期或施加/移除的新增运行时逻辑使用 custom-component。
---

# Buff 基础数据编排

## 硬边界

`buff_manage` 只管理编辑态基础数据。`onBuffBegin`、`OnBuffPeriod`、`onBuffEnd` 三个生命周期键不得出现在其对象中，即使值为空。

## 工作流

1. 用 `inspectDomainState(domains=["buff"])` 按 uuid/名称查重。
2. 使用 `buff_manage` 的 `create|update|delete` 及当前 Tool Schema 字段。create 使用稳定 `buff_id` 和显示名；update 只传需要修改的字段。
3. 周期配置要求 `period > 0`，生命周期固定拼写 `OnBuffPeriod`。
4. 生命周期响应、施加、移除、周期效果或复杂状态跟踪转 `custom-component`，由组件访问已证明的 Buff/AbilitySystem API；不使用旧脚本工作流。
5. 特效、音频或其他资源必须来自对应类型的真实查询结果。

## 验真

写后重新读取 buff domain，核对 uuid、duration、period、tags 和所有改动字段。失败或结果不明确时先查当前状态，禁止重复 create 同一 `buff_id`。

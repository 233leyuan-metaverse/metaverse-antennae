---
name: preciseEdit
nameZh: 精确编辑
abilityNames: [preciseEdit]
keywords: 位置,坐标,position,旋转,rotation,缩放,scale,移动到,定位,偏移,父子关系,跟随,朝向,方向,世界坐标,本地坐标,拉伸
depends: []
description: |
  preciseEdit 能力：精确变换控制（位置/旋转/缩放）、世界/本地坐标切换、父子跟随设置、方向向量获取。
  适用: 精确定位对象、运行时移动/旋转、调整缩放拉伸、父子跟随、轴锁、获取对象朝向。
  常见组合: basemove(自动运动修改position) + interactive/touchDetector(触发移动) + model(物理对象位置)。
---

# PreciseEdit 精确变换系统

能力名: `preciseEdit`
组件: `TransformComponent`(ownerComponent:0)

<!-- 2026-07-12 11:18:00 调整；原因：按 Skill 文档整理原则，仅保留使用流程、关键约束与常见组合。 -->

## 使用流程

1. 编辑态修改 `preciseEdit.*` 前，先用 `scene_set_ability` 挂载 `preciseEdit`。
2. 编辑态用 `scene_configure_ability` 写 `position` / `rotation` / `scale` / `absolute*` / 轴锁属性。
3. 运行态脚本用 `blockly-dsl` 的 `property.set`，坐标、旋转、缩放分别写 `preciseEdit.positionRef` / `preciseEdit.rotationRef` / `preciseEdit.scaleRef`。
4. 事件触发来自对应 skill，例如 `touchDetector.onEnter` 或 `Interactive.showButtonClickDelegate`；`preciseEdit` 只提供变换属性路径。

## 关键约束

1. 旋转轴定义：X=俯仰(Pitch)，Y=倾斜(Roll)，Z=转向(Yaw)，不要按通用欧拉角口径互换。
2. 位置、旋转、缩放分别调用 `scene_set_position`、`scene_set_rotation`、`scene_set_scale`，直接传数值分量；不要生成包装器或完整属性路径。
3. 坐标轴以引擎方向为准：上=+Z，下=-Z，左=-Y，右=+Y，前=+X，后=-X；调用 V2 工具时直接把对应分量传入 `x/y/z`。
4. **高度轴固定为 Z**：用户说“高/高度/变高/越来越高/柱体高度/向上拉伸”时，缩放必须改 `preciseEdit.scale` 的 Z 分量（如 `"1,1,高度倍率"`），不要改 Y；Y 是左右方向，不是高度。
5. **缩放路径固定**：编辑态缩放写 `preciseEdit.scale`，运行态缩放写 `preciseEdit.scaleRef`；不要编造 `model.Scale`、`model.scale` 等路径。
6. `transformType_pos` / `transformType_rot` / `transformType_scale` 控制 world/local；有父物体时 local position 是相对偏移量，无父物体时 world position 是世界坐标。
7. `absolutePosition` / `absoluteRotation` / `absoluteScale` 表示是否跟随父物体对应变换；`true`=跟随，`false`=不跟随。
8. `forward` / `backward` / `left` / `right` / `up` / `down` 是只读方向向量，适合运行态读取，不要用作写入目标。
9. `MoveAxisLock` / `RotationAxisLock` / `ScaleAxisLock` 结构为 `{ "x": boolean, "y": boolean, "z": boolean }`；这是轴锁对象，不是 `_Vector` 包装器，锁定轴会保留当前值。
10. 角色、武器等实体可能隐藏或禁用缩放相关属性，缩放失败时优先检查实体类型和属性可见条件。

## 属性速查

> 完整属性表见 `preciseEdit/reference.md` 各能力节 `### 属性`。

## EditTime vs Runtime

| 场景 | 模式 | 说明 |
|------|------|------|
| 创建时设置位置/旋转/缩放 | EditTime | scene_configure_ability 直接赋值 |
| 切换坐标系(world/local) | EditTime | `transformType_pos` / `transformType_rot` / `transformType_scale`，`showInCommand=false` |
| 配置父子跟随关系 | EditTime 或 Runtime | 编辑态写 `absolute*`；运行态脚本可通过 `property.set` 写 `absolute*` |
| 运行时移动/旋转/缩放对象 | Runtime | `property.set` 写 `positionRef` / `rotationRef` / `scaleRef` |
| 读取对象朝向 | Runtime | 读 `forward` / `right` / `up` 等只读向量 |

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| 自动运动对象 | preciseEdit + basemove |
| 互动触发移动(门/平台) | preciseEdit + interactive 或 touchDetector |
| 物理对象精确控制 | preciseEdit + model |
| 机械结构(齿轮/连杆) | preciseEdit(父子跟随) + basemove(旋转) |
| 角色传送 | preciseEdit + character |
| 特效挂载点 | preciseEdit(父子跟随) + effect |

## V2 运行约束

- preciseEdit is auto-mounted on many normal scene objects; inspect/prove it instead of adding it as boilerplate.
- Use preciseEdit.position/rotation/scale after readback supplies a canonical gameObjectId.
- For a just-created object, put initial placement in createObject.payload.position, then use preciseEdit for follow-up transform edits.
- Do not write direction getters such as preciseEdit.forward; they are read-only direction values.
- Use transformType_* values world/世界 or local/本地.
- Use absolutePosition/Rotation/Scale true for followParent/跟随父物体 and false for independent/不跟随父物体.
- The visible preciseEdit absolute* API stores the inverse internally; agent-facing values should use the visible follow-parent meaning.
- Do not catalog preciseEdit.forward/backward/left/right/up/down as writable edit-time properties.
- Scale properties can be hidden for character and weapon roles; rely on propertyCapabilities/readback before writing scale settings.

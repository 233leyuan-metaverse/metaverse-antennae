# preciseEdit — JSON 指令示例

> 配合 `preciseEdit/body.md` 和 `preciseEdit/reference.md` 使用。所有 `gameObjectId` 和 GUID 都是占位符，实际使用时需替换为真实值。
> <!-- 2026-07-12 11:18:00 调整；原因：按属性可修改判定规则精简示例，补齐编辑态 scene_set_ability，并保留最小 Blockly runtime 示例。 -->

---

## EditTime 示例（编辑态直接赋值）

### 设置对象位置、旋转、缩放
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 设置父子关系跟随
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 设置轴锁
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## Runtime 示例（积木 blockly DSL）

> DSL 结构与规则见 `blockly-dsl/body.md`；触发 `eventPath` 与参数来自事件所属 skill。
> Blockly 取/写坐标用 `preciseEdit.positionRef`，旋转用 `preciseEdit.rotationRef`，缩放用 `preciseEdit.scaleRef`；目标对象需已挂载 `preciseEdit`。

### 运行时修改对象位置（property.set preciseEdit.positionRef）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "object_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_setPosition_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "touchDetector.onEnter",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "owner", "type": "Entity" },
        { "index": 1, "argId": "triggerEntity", "name": "entered", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "set_position_1",
        "type": "property.set",
        "abilityId": "preciseEdit.positionRef",
        "operator": "=",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "value": { "type": "literal", "valueType": "Vector", "value": [5000, 0, 0] }
      }
    ]
  }
}
```

### 运行时旋转对象（property.set preciseEdit.rotationRef）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "object_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_setRotation_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "touchDetector.onEnter",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "owner", "type": "Entity" },
        { "index": 1, "argId": "triggerEntity", "name": "entered", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "set_rotation_1",
        "type": "property.set",
        "abilityId": "preciseEdit.rotationRef",
        "operator": "=",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "value": { "type": "literal", "valueType": "Rotation", "value": [0, 0, 45] }
      }
    ]
  }
}
```
> 若要作用在“进入触发区的对象”而非触发区本身，把 `owner` 换成 `{ "type": "event.arg", "argId": "triggerEntity" }`，或用 `entity.scene` 指定真实 `gameObjectId`。

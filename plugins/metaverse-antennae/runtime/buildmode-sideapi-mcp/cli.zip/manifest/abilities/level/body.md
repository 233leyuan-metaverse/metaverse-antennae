---
name: level
nameZh: 等级系统
abilityNames: [LevelAbility]
keywords: 等级,升级,经验值,经验,exp,成长,level,角色成长,经验条
depends: []
description: |
  LevelAbility 能力：等级系统、经验值累计升级、升级事件触发。
  适用: 玩家等级成长、敌人分级、升级奖励(恢复生命/提升属性)、等级限制门、多等级怪物分布。
  常见组合: combat(击杀获取经验) + character(升级提速) + ui(等级/经验条显示)。
---

# Level 等级与经验系统

能力名: `LevelAbility`
组件: `LevelComponent`(ownerComponent:0)

## 关键约束 ⭐ (源自前端 LevelComponent.ts + LevelExpConfig.ts 验证)

1. **先挂载再设属性**: 修改 `LevelAbility.*` 前必须 `scene_set_ability` 挂载 LevelAbility

2. **⚠️ initLevel setter 约束**:
   - 设置 initLevel 同时自动把 `_level` 也设为同值
   - 超过 maxLevel(100) 时被 clamp 到 100
   - 范围 `@range([1, 100])`, `@precision(0)` → 整数

3. **⚠️ level setter 约束** (运行时):
   - `level < initLevel` → **静默丢弃**（不能低于初始等级）
   - 等级改变时自动将 exp 置 0 并触发 onLevelChange 事件

4. **maxLevel = 100**: 内置 100 级经验表，超过 100 不会升级
5. **maxExp 只读**: 运行时属性，表示当前等级升级所需经验，不可直接修改
6. **经验表偏小**: 1级=5exp, 10级=275exp, 30级=2325exp, 50级=6375exp, 100级=max

## 属性速查

> 完整属性表见 `level/reference.md` → `## LevelAbility — 等级/经验系统` 下 `### 属性`。

## Functions (前端定义但均 showInCommand=false)

> Builder Functions: `level/reference.md` → `## Functions (前端定义但均 showInCommand=false)`。

## 可绑定事件（供 blockly 使用）

> 事件路径与参数槽: `level/reference.md` → `## 事件（Blockly 参数槽）`。

## 运行态升级/加经验（供 blockly 使用）

> 等级/经验运行态指令: `blockly-dsl/reference.md` →「积木所支持指令列表」→ `### 指令·战斗技能BUFF与生命`（`AddExpInstruction` / `AddLevelInstruction`）。

## EditTime vs Runtime 决策

| 场景 | 模式 | 说明 |
|------|------|------|
| 初始化等级 | EditTime | initLevel 设置创建时等级(同步设 level) |
| 运行时升级/加经验 | → blockly-dsl 积木 | 积木 ability.call 调 AddLevelInstruction / AddExpInstruction |
| 升级事件响应绑定 | → blockly-dsl 积木 | 积木绑定 onLevelChange 事件响应 |

## 经验表参考 (前5级)

| 等级 | 升级所需exp | 累计exp |
|:---:|:---:|:---:|
| 1 | 5 | 5 |
| 2 | 15 | 20 |
| 3 | 30 | 50 |
| 5 | 75 | 175 |
| 10 | 275 | 1400 |

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| RPG 角色成长 | level + combat + weapon |
| 击杀获取经验 | level + combat(onDeath 绑 AddExpInstruction) |
| 等级限制门 | level + interactive(IfInstruction 检查 level) |
| 升级特效 | level + effect |
| 等级/经验条 HUD | level + ui |

## V2 运行约束

- initLevel 是编辑态初始值；level/exp/maxExp 只能运行态指令修改（增经验用 AddExpInstruction、升级用 AddLevelInstruction）。

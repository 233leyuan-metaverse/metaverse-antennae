# level — JSON 指令示例

> 配合 level.md 主文件使用。所有示例中的 GUID 为占位符，实际使用时需替换为真实资源 GUID。

---

## EditTime 示例（编辑态直接赋值）

### 添加等级能力并设置初始等级
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 为 Boss 设置高初始等级
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 配置不同等级的敌人
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## 运行态示例（积木 blockly DSL）

<!-- 2026-07-02 14:52:00 调整；原因：等级事件签名与属性路径归 level skill，blockly-dsl 只维护 DSL 结构和公共规则。 -->
> DSL 结构与规则见 `blockly-dsl/body.md`；`eventPath` 与 `dsl.event.arguments` 来自 `level/body.md`，等级指令 abilityId 见 `level/body.md`。目标 `entity` 须已挂 `LevelAbility`。

### 升级时恢复满血（LevelAbility.onLevelChange）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "player_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onLevelChange_healFull_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "LevelAbility.onLevelChange",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "restore_full_hp_1",
        "type": "property.set",
        "abilityId": "health.hp",
        "operator": "=",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "value": {
          "type": "property.get",
          "abilityId": "health.maxHP",
          "owner": { "type": "event.arg", "argId": "ownerEntity" }
        }
      }
    ]
  }
}
```
> 恢复满血 = 把 `health/hp` 设为同一实体 `health/maxHP` 的当前值；两端 `owner` 都是升级的实体 `self`。

### 击杀敌人时给击杀者加经验（health.onDeath）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "enemy_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onDeath_addExp_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "health.onDeath",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "killerEntity", "name": "killer", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "add_exp_1",
        "type": "ability.call",
        "abilityId": "instruction.__80079/__80567/AddExpInstruction",
        "owner": { "type": "event.arg", "argId": "killerEntity" },
        "args": [
          { "type": "literal", "valueType": "Number", "value": 50 }
        ]
      }
    ]
  }
}
```
> `index=1`（`killerEntity`）是击杀者（通常玩家），`index=0`（`self`）是死亡的敌人；经验加给击杀者。

### 互动点击后给玩家升 1 级（Interactive.showButtonClickDelegate）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "互动对象gameObjectId" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_levelUpInteractive_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "Interactive.showButtonClickDelegate",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "interactPlayer", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "add_level_1",
        "type": "ability.call",
        "abilityId": "instruction.__80079/__80567/AddLevelInstruction",
        "owner": { "type": "event.arg", "argId": "interactPlayer" },
        "args": []
      }
    ]
  }
}
```
> `interactPlayer`（index 1）是互动发起者；若要给被点击物体升级，改传 `ownerEntity`。目标实体必须已挂 `LevelAbility`。

---

## 完整场景示例

### 创建带等级系统的玩家角色
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_create_object`, `scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

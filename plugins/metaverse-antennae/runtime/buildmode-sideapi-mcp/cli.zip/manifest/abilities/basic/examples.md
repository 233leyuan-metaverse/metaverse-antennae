# basic — JSON 指令示例

> 配合 `basic/body.md` 与 `basic/reference.md` 使用。示例中的对象 ID、资源 GUID、阵营 ID 都是占位符，必须替换为真实值。

---

## EditTime 示例

### 设置对象名称、描述和名称显示

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 设置阵营

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## Runtime 示例（积木 blockly DSL）

### 创建时隐藏对象（BasicAbility.onCreateEvent）

```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "hidden_object_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onCreate_hide_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "BasicAbility.onCreateEvent",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "set_visible_hide_1",
        "type": "property.set",
        "abilityId": "BasicAbility.visible",
        "operator": "=",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "value": { "type": "literal", "valueType": "Number", "value": 2 }
      }
    ]
  }
}
```

### 选中对象时显示对象（BasicAbility.onGameObjectSelected）

```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "selectable_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onSelected_show_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "BasicAbility.onGameObjectSelected",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "playerEntity", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "set_visible_show_1",
        "type": "property.set",
        "abilityId": "BasicAbility.visible",
        "operator": "=",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "value": { "type": "literal", "valueType": "Number", "value": 1 }
      }
    ]
  }
}
```

---

## 完整场景示例

### 创建带阵营的 NPC

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_create_object`, `scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---
name: basic
nameZh: 基础属性
abilityNames: [BasicAbility]
keywords: 阵营,敌对,faction,camp,名称,可见性,显示,隐藏,basicability,生命周期,创建事件,销毁事件,选中,描述
validContext: [sceneObject, presetNode]
depends: []
description: |
  基础属性能力：对象名称/描述、名称显示、阵营设置、可见性控制、生命周期事件(创建/销毁/选中)、广播自定义事件。
  适用: 设置对象名称和描述、配置名称显示、设置阵营(敌对/友方)、控制显示隐藏、绑定生命周期事件。
  常见组合: combat(战斗属性) + character(角色AI) + touchDetector(交互检测)。
  ✅ validContext=sceneObject+presetNode: BasicAbility 随所有对象自动挂载，EditTime 属性在活体对象和预设节点编辑会话中均可设置。
---

# Basic 基础属性

能力名: `BasicAbility`
组件: `BasicInfoComponent`(ownerComponent:0) + `HeadUIComponent`(ownerComponent:1) + `FactionComponent`(ownerComponent:2) + `CustomEventComponent`(ownerComponent:3)

## 关键约束

1. **内置能力**: BasicAbility 随所有实体自动挂载(TAG_All)，通常不需要手动添加
2. **⚠️ 阵营 faction="1" 是特殊值**: DamageComponent 源码检查 `factionName==='1'` 时直接跳过伤害计算。faction="1"(无/中立) 的对象**不能造成也不能接受伤害**。玩家如需参与战斗，应设为 faction="2"(友善) 而非 "1"(无)
3. **阵营默认值**: 普通对象默认 factionID="1"(无), Character 默认 factionID="3"(敌对)
4. **阵营值来源**: `faction` 值从工具返回的 `campDataList` 获取阵营 ID 字符串，不要硬编码
5. **visible 枚举**: PropertyStatus 枚举 — 0=FromParent(跟随父节点), 1=On(显示), 2=Off(隐藏含碰撞)
6. **entityName 非空**: setter 检查 `StringUtil.isEmpty(v)` → 空字符串会被静默丢弃
7. **description 仅编辑态**: `showInCommand=false`，运行时不可通过 `property.set` 修改
8. **visible 仅运行态**: `showInProperty=false` / `showInCommand=true`，运行态用 `blockly-dsl` 的 `property.set` 写 `BasicAbility.visible`
9. **uiHeight 不开放修改**: `showInProperty=false` / `showInCommand=false`，不要在示例或生成结果中配置
10. **onGameObjectSelected 限制**: 不支持 Floor/PlayerStart/Scene/Effect 类型实体

## 属性速查

> 完整属性表见 `basic/reference.md` 各能力节 `### 属性`。

## 可绑定事件（供 blockly 使用）

> 事件路径与参数槽: `basic/reference.md` → `## 事件（Blockly 参数槽）`。

## 关联指令

运行态逻辑（触发/事件响应/定时/条件）用 `blockly-dsl` 生成积木 DSL；Basic 业务属性查本 skill，积木指令 abilityId 查 `blockly-dsl/reference.md`「积木所支持指令列表」。

> **显隐统一走属性**（2026-07-10 更新；原因：按 Ability `showInCommand/showInProperty` 重新校准）：对象运行态显隐一律用 `BasicAbility.visible` 的 `property.set`，值直接填枚举原值 `1显示/2隐藏(含碰撞)/0跟随父物体`。用 `visible=2` 隐藏后，必须再写 `visible=1` 或 `0` 恢复；不要生成 `HideInstruction_V2` / `ShowInstruction`。

## EditTime vs Runtime 决策

| 场景 | 模式 | 说明 |
|------|------|------|
| 初始化名称/描述 | EditTime | `entityName`、`description` 用 `scene_configure_ability` |
| 初始化阵营 | EditTime | `faction` 用 `scene_configure_ability`；阵营 ID 必须来自查询结果 |
| 初始化名称显示 | EditTime | 只配置 `BasicAbility.nameVisible`；`BasicAbility.uiHeight` 不开放修改 |
| 运行时控制可见性 | Runtime | 用 `blockly-dsl` `property.set` 写 `BasicAbility.visible`，值为 `0/1/2` |
| 生命周期事件绑定(onCreate) | → blockly-dsl 积木 | `event.eventPath="BasicAbility.onCreateEvent"` |
| 运行时改名称/阵营 | → blockly-dsl 积木 | 运行态改值走 blockly `property.set`（entityName/faction） |
| 广播自定义事件 | → blockly-dsl 积木 | 运行态广播自定义事件用 blockly 积木（broadcastCustomEvent） |

## 能力组件管理（EditTime）

对象上的能力组件可以动态挂载和移除。

| 指令 | 作用 | 格式 |
|------|------|------|
| `scene_set_ability` | 挂载能力组件到对象 | `target=<唯一对象>, ability_name=<Contract 能力名>, enabled=true` |
| `scene_set_ability` | 从对象上移除能力组件 | `target=<唯一对象>, ability_name=<Contract 能力名>, enabled=false` |

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| NPC 名称+阵营 | basic + character |
| 可交互物体(选中反馈) | basic + interactive + effect |
| 隐藏机关(触发显示) | basic + touchDetector + interactive |
| 敌方怪物 | basic + combat + character + weapon |
| 可破坏物体 | basic(销毁事件) + combat + effect |
| 名称+血条 | basic + combat(hpVisibleMode) |

## V2 运行约束

- BasicAbility is auto-mounted on normal scene entities; inspect/prove it instead of adding it.
- Do not remove BasicAbility; the live ability descriptor marks it not deletable.
- Use BasicAbility.visible for visibility through scene.display.basic-visible; keep other BasicAbility properties in scene.basic-ability.property.
- Use faction values from camp/faction inspect data rather than guessing hard-coded ids.

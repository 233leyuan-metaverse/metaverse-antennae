# character — JSON 指令示例

> 示例中的 GUID 均为占位符，实际使用时替换为真实资源 GUID。编辑态写 `CharacterAbility.*` 前必须先挂载 `CharacterAbility`。

---

## EditTime 示例

### 创建角色并设置基础属性

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_create_object`, `scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 配置追踪型敌人

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 配置巡逻 NPC

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 自定义球形碰撞盒

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 覆盖待机动画与运动音效

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 配置 NPC 待机随机语音

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## Runtime 示例（blockly-dsl）

### 碰撞触发时修改自身移动速度

```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "npc_guard_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onTouch_set_walkSpeed_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "CharacterAbility.showOnTouch",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "hitEntity", "name": "other", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "set_walk_speed_1",
        "type": "property.set",
        "abilityId": "CharacterAbility.walkSpeed",
        "operator": "=",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "value": { "type": "literal", "valueType": "Number", "value": 600 }
      }
    ]
  }
}
```

### 碰撞触发时播放音效

```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "npc_guard_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onTouch_sound_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "CharacterAbility.showOnTouch",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "hitEntity", "name": "other", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "play_touch_sound_1",
        "type": "ability.call",
        "abilityId": "instruction.__80055/__80106/Play2DSoundInstruction",
        "owner": { "type": "system" },
        "args": [
          { "type": "asset.ref", "assetId": "碰撞音效GUID" },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Boolean", "value": true },
          { "type": "event.arg", "argId": "hitEntity" }
        ]
      }
    ]
  }
}
```

---
name: character
nameZh: 角色能力
abilityNames: [CharacterAbility]
keywords: 怪物,monster,npc,角色,boss,ai行为,ai追踪,追击,巡逻,侦测,主动攻击,characterability,动画,移动速度,跳跃高度,碰撞盒,外观,声音,待机语音,idle voice,npc语音,随机语音,飞行,游泳,姿态
validContext: [sceneObject]
depends: [basic]
dependsReason: "BT_MonsterTracking/BT_Partrol 行为树通过 BasicAbility.faction 判断敌我；未设阵营时 AI 无法识别攻击目标，怪物站立不动"
description: |
  角色能力：NPC/怪物/玩家的外观、姿态、动画覆盖、移动参数（速度/跳跃）、AI行为树（追踪/巡逻）、碰撞盒、碰撞事件、NPC 待机随机 3D 语音。
  角色/NPC/怪物**预设资源**（preset_save_objects、刷怪器引用）→ case **`create_character_resource`**；**场景直建**（无保存语义）→ case **`create_character_in_scene`**：`search_asset(kind=character)`。本 skill 的 V2 属性工具/Blockly 仍适用配置阶段。
  适用: 创建NPC/怪物、设置角色外观动画、配置移动速度跳跃高度、AI追踪巡逻、碰撞盒调整、碰撞事件绑定、为 NPC 配置待机语音。
  常见组合: combat(生命值) + weapon(武器) + basic(阵营faction，AI追踪必须!) + ui(血条) + effect(特效)。
  ⚠️ validContext=sceneObject: 所有属性只对有具体 gameObjectId 的活体场景对象有效，预设节点编辑会话不适用。
---

# Character 角色/NPC 系统

能力名: `CharacterAbility`
组件: DescriptComponent(0) + StanceComponent(1) + CharMovementComponent(2) + AIComponent(3) + CharacterSoundComponent(4) + CharacterCollisionComponent(5) + BasicInfoComponent(6) + CharacterMoveToComponent(7)

## 使用流程

1. 修改 `CharacterAbility.*` 前，先对目标对象执行 `scene_set_ability`。
2. 编辑态写属性用 `scene_configure_ability`，路径和可编辑状态查 `character/reference.md`。
3. 运行态普通属性修改用 `blockly-dsl` 的 `property.set`，只写 `character/reference.md` 中「可指令=✅」的路径。
4. 运行态追踪、巡逻、移动、朝向、播放动画、覆盖姿态等行为优先用 `blockly-dsl/reference.md` 的角色指令。

## 关键约束

1. `BT_MonsterTracking` 必须配合 `BasicAbility.faction` 设为敌对阵营；无阵营或双方阵营为无阵营 `1` 时，AI 无法识别攻击目标。
2. 行为树距离参数单位是厘米，例如 `_enemyRadius=1000` 表示 10 米侦测。
3. 切换 `CharacterAbility._information.aiName` 会重建动态参数；编辑态配置时必须先写 `aiName`，再写 `_dynamicProperties.*`。
4. 自定义碰撞盒必须先写 `CharacterAbility.collisionModify=true`，再写 `collisionShape` 和对应尺寸字段。
5. `CharacterAbility.gravityScale` 既不可编辑也不可指令修改；飞行/游泳速度字段可改，但进入飞行/游泳状态仍需用角色运行态指令或状态控制。
6. NPC 待机随机语音用 `CharacterAbility._idleVoiceDataShow.*`；运动音效用 `CharacterAbility._soundDataShow.dataMap.*`，不要把 Idle 槽位写进运动音效 `dataMap`。
7. 待机语音仅编辑态配置，至少需要 `enabled=true` 且存在一条有效 `voiceAssets.{index}.soundGuid` 或 `animationGuid`；本地玩家角色会被运行时排除。

## 可绑定事件（供 blockly 使用）

> 事件路径与参数槽: `character/reference.md` → `## 事件（Blockly 参数槽）`。

## 关联运行时能力

> 角色运行态指令: `blockly-dsl/reference.md` →「积木所支持指令列表」→ `### 指令·动画与姿态` / `### 指令·移动变换与朝向`。

## EditTime vs Runtime 决策

| 场景 | 模式 | 说明 |
|------|------|------|
| 设置外观/姿态资源 | EditTime 或 Runtime | `assetId` / `stanceAssetId` 可编辑、可指令 |
| 设置移动速度/跳跃 | EditTime 或 Runtime | `walkSpeed` / `jumpHeight` / `maxJumpCount` 等按 Contract reference 可指令列判断 |
| 配置 AI 行为树 | EditTime | `aiName` + `_dynamicProperties.*`，先设 `aiName` 再设参数 |
| 自定义碰撞盒 | EditTime | `collisionModify` + `collisionShape` + 对应尺寸 |
| 配置 NPC 待机随机语音 | EditTime | `_idleVoiceDataShow.*`，禁止 Runtime `property.set` |
| 碰撞/追踪事件绑定 | blockly-dsl | 事件路径和参数槽查 `reference.md` |
| 运行时 AI 控制 | blockly-dsl | 追踪、巡逻、移动、朝向、动画等用角色指令 |

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| 可攻击怪物(追踪+攻击) | character + combat + weapon + basic(阵营!) |
| Boss 战 | character + combat + weapon + effect + basic + ui(血条) |
| 巡逻 NPC | character + basic(阵营) |
| 有活人感的待机 NPC（随机说话） | character（`_idleVoiceDataShow`） |
| 碰撞触发(踩踏/区域) | character(onTouch) + effect/combat |
| 运行时 AI 控制 | character + blockly-dsl |

> JSON 指令示例: `character/examples.md`

## V2 运行约束

- assetId / stanceAssetId 及各资源字段须为 resource inspect 拿到的真实 guid，禁止编造。
- _information._dynamicProperties.* 是编辑态行为树参数；运行态追踪/巡逻/移动请用 blockly-dsl 角色指令，不要用 property.set 写这些路径。
- gravityScale / complexMovementEnabled 在 Ability 内不可编辑不可指令，故不暴露为可写属性。

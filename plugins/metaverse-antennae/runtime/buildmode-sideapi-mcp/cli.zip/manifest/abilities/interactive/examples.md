# interactive — JSON 指令示例

> 配合 `interactive/body.md` 和 `interactive/reference.md` 使用。所有示例中的 GUID 为占位符，实际使用时需替换为真实资源 GUID。
> <!-- 2026-07-10 17:46:00 调整；原因：按 Interactive Contract reference 可编辑/可指令状态精简示例，避免编辑态写入不可编辑属性。 -->

---

## EditTime 示例（编辑态直接赋值）

### 添加基础互动能力
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 配置互动范围
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。
> transform 是相对变换（"坐标|旋转|缩放"），需考虑挂载对象的位置旋转缩放。

### 启用互动次数限制开关
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。
> `Interactive.interactTimes` 运行态可指令修改、编辑态不可修改；需要动态限制次数时，用 `blockly-dsl` 的 `property.set` 写该字段。

### 配置自动互动（自动门）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## Runtime 示例（积木 blockly DSL）

<!-- 2026-07-02 14:52:00 调整；原因：互动事件签名与互动属性路径归 interactive skill，blockly-dsl 只维护 DSL 结构和公共规则。 -->
> DSL 结构与规则见 `blockly-dsl/body.md`；`eventPath` 与 `dsl.event.arguments` 来自 `interactive/body.md`。事件 `Interactive.showButtonClickDelegate` 参数槽：`0:ownerEntity:self:Entity`，`1:interactPlayer:player:Entity`。GUID 为占位符，需替换为真实 `assetId`/`canvasGuid`/`widgetGuid`。

### 互动时播放音效（Interactive.showButtonClickDelegate）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "button_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onInteractSound_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "Interactive.showButtonClickDelegate",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "interactPlayer", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "play_button_sound_1",
        "type": "ability.call",
        "abilityId": "instruction.__80055/__80106/Play2DSoundInstruction",
        "owner": { "type": "system" },
        "args": [
          { "type": "asset.ref", "assetId": "按钮音效GUID" },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Boolean", "value": true },
          { "type": "event.arg", "argId": "interactPlayer" }
        ]
      }
    ]
  }
}
```
> `_playInClient=true` 时最后一个 `_entity` 必须是玩家，此处传 `interactPlayer`（index 1）。

### 互动时修改位置（开门 / 滑动门）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "sliding_door_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onInteractMove_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "Interactive.showButtonClickDelegate",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "interactPlayer", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "set_door_position_1",
        "type": "property.set",
        "abilityId": "preciseEdit.positionRef",
        "operator": "=",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "value": { "type": "literal", "valueType": "Vector", "value": [-4320, 1680, 0.25] }
      }
    ]
  }
}
```
> Blockly 取/写坐标只用 `preciseEdit.positionRef`（非 Ref 的 `position` 不暴露给 Blockly，取到的不是合法 Vector）；`owner` 为被移动的门自身（`ownerEntity`，index 0）。<!-- 2026-07-09 14:22:00 调整；原因：Blockly 普通业务属性恢复点号业务路径。 -->

### 互动后禁用自身互动
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "one_shot_button_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onInteractDisable_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "Interactive.showButtonClickDelegate",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "interactPlayer", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "disable_interactive_1",
        "type": "property.set",
        "abilityId": "Interactive.enableInteract",
        "operator": "=",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "value": { "type": "literal", "valueType": "Boolean", "value": false }
      }
    ]
  }
}
```

### 互动时播放特效
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "magic_button_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onInteractEffect_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "Interactive.showButtonClickDelegate",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "interactPlayer", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "play_button_effect_1",
        "type": "ability.call",
        "abilityId": "instruction.__80059/__687/PlayEffectOnGameObjectInstruction",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "args": [
          { "type": "enum.value", "value": "0" },
          { "type": "asset.ref", "assetId": "魔法特效GUID" },
          { "type": "literal", "valueType": "Number", "value": 2 },
          { "type": "literal", "valueType": "Vector", "value": [0, 0, 0] },
          { "type": "literal", "valueType": "Rotation", "value": [0, 0, 0] },
          { "type": "literal", "valueType": "Vector", "value": [1, 1, 1] },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Color", "value": [255, 255, 255, 1] },
          { "type": "literal", "valueType": "Color", "value": [255, 255, 255, 1] }
        ]
      }
    ]
  }
}
```

### 互动触发 UI（仅对发起者玩家）⭐
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "console_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onInteractUI_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "Interactive.showButtonClickDelegate",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "interactPlayer", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "show_result_canvas_1",
        "type": "ability.call",
        "abilityId": "instruction.__80074/__81212/ScreenUICanvasVisibleInstruction",
        "owner": { "type": "event.arg", "argId": "interactPlayer" },
        "args": [
          { "type": "literal", "valueType": "String", "value": "canvas_result" },
          { "type": "literal", "valueType": "Boolean", "value": true },
          { "type": "literal", "valueType": "Boolean", "value": false },
          { "type": "literal", "valueType": "Number", "value": 0 }
        ]
      },
      {
        "nodeId": "set_result_text_1",
        "type": "ability.call",
        "abilityId": "instruction.__80074/__81212/ScreenUISetTextInstruction",
        "owner": { "type": "event.arg", "argId": "interactPlayer" },
        "args": [
          { "type": "literal", "valueType": "String", "value": "canvas_result" },
          { "type": "literal", "valueType": "String", "value": "text_result" },
          { "type": "literal", "valueType": "String", "value": "你完成了任务！" }
        ]
      }
    ]
  }
}
```
> UI 只对发起者生效：屏幕 UI 指令按 `blockly-dsl/reference.md` 的 `rawParams` 映射规则生成，玩家实体由 `owner=event.arg.interactPlayer` 承载，DSL `args` 从 `canvasGuid` / `widgetGuid` 等 UI 参数开始。`canvasGuid`/`widgetGuid` 为占位符，需替换为真实 UI GUID。

---

## 完整场景示例

### 创建宝箱（启用次数限制）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_create_object`, `scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 自动门（范围触发）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_create_object`, `scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 按钮开关（带音效）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_create_object`, `scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。
> 编辑态建好按钮后，「点击播放音效 / 显隐 UI / 开门」等运行态逻辑用 `blockly-dsl` 积木绑定 `Interactive.showButtonClickDelegate`；UI 类指令 owner 须为发起者玩家（`interactPlayer`，index 1）。

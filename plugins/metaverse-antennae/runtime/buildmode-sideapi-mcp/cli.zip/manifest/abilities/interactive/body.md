---
name: interactive
nameZh: 互动能力
abilityNames: [Interactive]
keywords: 交互,互动,点击,拾取,按键,按钮,开关,门,宝箱,NPC对话,自动门,机关,触发,按F,互动范围,阵营检测,一次性互动
depends: []
description: |
  Interactive 能力：互动系统（按钮/开关/门/宝箱/NPC对话触发）、互动范围与次数控制、自动互动、阵营检测。
  适用: 可互动门/宝箱/按钮、一次性开关、自动门(靠近触发)、阵营限制互动、互动播放音效特效。
  常见组合: basemove(机关门运动) + preciseEdit(互动移动位置) + effect(互动特效) + combat(互动回血)。
---

# Interactive 交互系统

能力名: `Interactive`
组件: `TouchDetectorComponent`(ownerComponent:0) + `InteractiveProcessComponent`(ownerComponent:1)

<!-- 2026-07-10 17:46:00 调整；原因：按 Contract reference 判定规则收敛正文，只保留使用流程、关键约束和常见组合。 -->

> ⚠️ **TouchDetectorComponent 是 Interactive 的内部实现细节，不对外暴露任何 `Interactive.touchDetector*` 属性路径。**
> 如需单独的进入/离开区域检测（触发陷阱、刷怪区、传送门等），请使用独立的 **`touchDetector` 能力**，挂载方式 `scene_set_ability abilityName=touchDetector`，事件路径为 `touchDetector.onEnter` / `touchDetector.onLeave`。
> Interactive 与 touchDetector 是两个完全独立的能力，目的不同，**禁止混用、禁止用 `Interactive.*` 路径操作触发检测行为**。

初始化值: `sphereDiameter=2`，`shape=Sphere`，`factionDetectTypes=-2`（全部含无阵营），`autoInteract=false`。

## 关键约束

1. **先挂载再设属性**: 修改 `Interactive.*` 前必须 `scene_set_ability` 挂载 Interactive
2. **阵营检测必须查询**: 设置 `factionDetectTypes` 前**必须调用`【阵营系统查询工具】`**获取阵营列表，对 `campName_lang` 语义匹配后填入序号。禁止凭经验猜测
3. **factionDetectTypes 单选**: 仅接受单个序号字符串。`"-1"`=所有阵营(不含无阵营)，`"-2"`=所有阵营(含无阵营)
4. **interactTimes 与 enableWithTimes 配合**: `enableWithTimes=true` 时 `interactTimes` 才生效；次数耗尽后自动隐藏按钮
5. **interactTimes 范围**: @range([0, 9999999])，@precision(0) 整数
6. **interactName 默认空**: 空字符串时客户端显示内置默认文案
7. **运行态事件只绑定点击入口**: 使用 `Interactive.showButtonClickDelegate`；`buttonClickDelegate`、`onInteractStart`、`buttonCancelDelegate`、`showButtonCancelDelegate` 都不要作为 AI 事件路径

## 属性速查

> 完整属性表见 `interactive/reference.md` 各能力节 `### 属性`。

## 可绑定事件（供 blockly 使用）

> 事件路径与参数槽: `interactive/reference.md` → `## 事件（Blockly 参数槽）`。

## 内部 Listener 工作流（自动，无需手动配置）

1. `TouchDetectorComponent.onTouchDetectorEnter` → 调用 `InteractiveProcessComponent.showButtonUI`（显示按钮）
2. `InteractiveProcessComponent.showButtonClickDelegate` → 执行 `Interactive.showButtonClickDelegate` 上绑定的积木逻辑
3. `TouchDetectorComponent.onTouchDetectorLeave` → 调用 `InteractiveProcessComponent.hideButtonUI`（隐藏按钮）

## EditTime vs Runtime 决策

| 场景 | 模式 | 说明 |
|------|------|------|
| 搭建互动能力 | EditTime | 先 `scene_set_ability abilityName=Interactive`，再写 `reference.md` 中可编辑的属性 |
| 运行态修改互动开关/次数/按钮信息 | Runtime | 只改 `showInCommand=true` 的属性，走 `blockly-dsl` 的 `property.set` |
| 互动响应逻辑（点击后做什么） | Runtime 事件 | `event.eventPath="Interactive.showButtonClickDelegate"`，玩家专属 UI/音效 owner 用 `interactPlayer` |

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| 机关门/升降平台 | interactive + basemove |
| 宝箱(打开+掉落) | interactive + effect + spawner |
| 传送门/检查点 | interactive + playerstart |
| 按钮控制灯光 | interactive + pointLight |
| NPC 对话触发 | interactive + character |
| 商店/售卖机 | interactive + ui |

> JSON 指令示例: `interactive/examples.md`

## V2 运行约束

- Add/prove Interactive before writing Interactive.* properties.
- Use factionDetectTypes as one string value: allCombatFactions -> -1, allIncludingNoFaction -> -2, or one inspect-backed faction id.
- Use autoInteract=false/manualButton for showing a button and waiting for player input; use autoInteract=true/autoTrigger for enter-range auto trigger.
- Set enableWithTimes=true before interactTimes controls one-time or limited interactions.
- Pick interactIcon from asset/resource inspect data; do not invent asset ids.

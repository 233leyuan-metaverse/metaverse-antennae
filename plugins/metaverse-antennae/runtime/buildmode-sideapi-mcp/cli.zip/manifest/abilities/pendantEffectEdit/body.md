---
name: pendantEffectEdit
nameZh: 挂件特效
keywords: 特效挂件,挂件,pendant,特效,粒子效果,挂载特效,添加特效,删除特效,光效,火焰特效,闪电特效,发光
depends: []
description: |
  PendantEffect: 对象特效挂件的编辑态添加/删除/属性编辑。
  适用: 给对象挂载特效、调整挂件属性、删除已有特效挂件。
  常见组合: combat(战斗特效) + weapon(武器特效) + character(角色特效)。
---

# Effect Pendant (特效挂件编辑)

## 关键约束

1. **先挂载能力**: 对 `effectObj.effectInfos.*` 做增删改前，必须先用 `scene_set_ability` 挂载 `effectObj`。
2. **只走编辑态流程**: `effectObj.effectInfos` 在 Ability 配置中 `showInCommand=false`，运行态不可用 `property.set` 修改。
3. **GUID 唯一性**: 创建时 `guid` 不能与已有特效挂件重复，推荐生成规则为 `时间戳字符串-随机id`。
4. **改/删先查询**: 修改或删除特效前，调用 `getPendantList_effect` 获取当前列表、`guid`、`index` 和旧值，不要猜测。
5. **路径前缀**: 属性路径使用 Ability 名 `effectObj`，子属性写完整路径，例如 `effectObj.effectInfos.{index}.effectAssetId`。

## 命令类型

所有编辑态操作统一使用 `pendant_effect_manage`，通过 `action` 区分:

- `0` = 添加特效挂件
- `1` = 删除特效挂件
- `2` = 编辑特效挂件属性

## 使用流程

1. 编辑态新增：先挂 `effectObj`，再用 `action="create"` 写入新 `guid`，随后查询列表获得 `{index}`。
2. 编辑态改属性：用查询到的 `{index}` 写完整子属性路径，并带上 `oldValue` 与 `value`。
3. 编辑态删除：先查询目标 `guid`，再用 `action="delete"` 删除。

## 参考位置

- 属性、枚举、事件路径、可修改状态：`pendantEffectEdit/reference.md`
- 最小 JSON 示例：`pendantEffectEdit/examples.md`

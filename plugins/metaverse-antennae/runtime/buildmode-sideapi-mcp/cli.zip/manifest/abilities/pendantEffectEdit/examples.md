# pendantEffectEdit — JSON 指令示例

> 配合 `pendantEffectEdit/body.md` 与 `pendantEffectEdit/reference.md` 使用。所有 ID / GUID / `{index}` 均为占位符，实际使用前需查询或替换。

---

## 编辑态：添加特效挂件

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

## 编辑态：修改挂件资源

> 旧底层 payload 示例已移除。对应 V2 调用：`pendant_effect_manage`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

## 编辑态：删除特效挂件

> 旧底层 payload 示例已移除。对应 V2 调用：`pendant_effect_manage`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

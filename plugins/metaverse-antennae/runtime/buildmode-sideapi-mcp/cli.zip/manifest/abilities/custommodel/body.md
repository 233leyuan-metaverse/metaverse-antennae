# CustomModel 参数化几何体

能力名：`customModelAbility`。用于创建和调整立方体、金字塔、圆台、圆锥、圆柱、空心棱柱、环面等参数化几何体。

## 关键约束

1. `customModelAbility` 随自定义模型实体自动挂载，不能通过 `scene_set_ability` 添加。
2. 所有形状属性仅支持 EditTime，使用 `scene_configure_ability`；不支持运行时修改。
3. 场景最多包含 75 个自定义模型变体。
4. 属性存在浮点容差，低于 `0.0001` 的变化可能被忽略。
5. 属性路径、类型、范围和枚举必须来自当前 Tool Schema/Contract，不得凭几何名称猜字段。

## 选型

| 需求 | 参数组 |
|---|---|
| 方块、倒角方块 | `bevel*` |
| 金字塔、多棱锥 | `pyramid*` |
| 圆柱、圆锥、圆台、弯管 | `frustum*` |
| 空心柱、管道 | `hollowPrism*` |
| 环面、拱门 | `polygonTorus*` |
| 球体 | `sphere*` |
| 可编辑曲面 | `editableSurface*` |

不同几何体只写对应参数组。材质、颜色和透明度组合 `model`，位置、旋转和缩放组合 `preciseEdit`。

## 工作流与验真

创建正确类型的自定义模型实体，读取对象详情确认内置能力，再用 `scene_configure_ability` 设置参数。写后用 `inspectPropertyValues` 精确核对每条路径，并重新读取 `boundSize` 验证实际几何尺寸。

---
name: basemove
nameZh: 移动能力
abilityNames: [BaseMoveAbility]
keywords: 往返,升降,弹跳,传送带,电梯,移动平台,旋转障碍,obby,跑酷,风车,齿轮,摆动,钟摆,运动器,动态机关,秋千,自动旋转,呼吸灯,消失平台,波浪,螺旋,延时启动
depends: []
description: |
  BaseMoveAbility 能力：自动运动系统（平移/旋转/缩放/摆动）、往返运动、延时启动、停顿控制。
  适用: 移动平台(电梯/升降)、旋转障碍(风车/齿轮/刀片)、摆动跳板(钟摆/秋千)、缩放机关(呼吸灯/消失平台)、Obby跑酷关卡。
  常见组合: preciseEdit(位置控制) + interactive(按钮启动) + model(碰撞) + touchDetector(踩踏检测)。
---

# BaseMove 运动器

能力名: `BaseMoveAbility`
组件: `BaseMoveComponent`(ownerComponent:0)

## 先读结论

1. 先用 `scene_set_ability` 挂载 `BaseMoveAbility`，再写任何 `BaseMoveAbility.*` 属性。
2. `BaseMoveAbility.integratedMoverEnable=true` 是运动总开关；能力挂载时 initializer 默认启用，但显式配置更稳。
3. 平移、旋转、缩放、摆动可叠加；对应速度为 `_Vector`，全 0 表示该类运动不启动。
4. `motionCoordinate`：`"0"` 为世界坐标，`"1"` 为本地坐标。
5. `rotationRepeat=false` 配合非零 `rotationSpeed` 可做持续旋转，如风车/齿轮。
6. `linearRepeat` / `rotationRepeat` / `scaleRepeat=true` 时，单程时间、到达停顿、返程停顿才有意义。

## 配置流程

| 步骤 | 操作 |
|------|------|
| 1 | 创建或选中要运动的物体 |
| 2 | 挂载 `BaseMoveAbility` |
| 3 | 设置 `integratedMoverEnable=true` |
| 4 | 选择 `motionCoordinate`，按需设置 `duration` / `smooth` |
| 5 | 写入一个或多个运动组：`baseMoveConfig_Move` / `baseMoveConfig_Rotate` / `baseMoveConfig_Scale` / `baseMoveConfig_Swing` |

完整属性、枚举和范围见 `basemove/reference.md`。

## 运动组速记

| 运动组 | 关键属性 | 典型用途 |
|------|------|------|
| 平移 `baseMoveConfig_Move` | `linearSpeed`、`linearRepeat*` | 电梯、移动平台、传送带 |
| 旋转 `baseMoveConfig_Rotate` | `rotationSpeed`、`rotationRepeat*` | 风车、齿轮、旋转门 |
| 缩放 `baseMoveConfig_Scale` | `scaleSpeed`、`scaleRepeat*` | 呼吸灯、消失/伸缩平台 |
| 摆动 `baseMoveConfig_Swing` | `swingSpeed`、`swingAngle` | 钟摆、秋千、摆锤 |

往返周期约为：`RepeatTime * 2 + RepeatDelay + ReturnDelay`。

## EditTime vs Runtime 决策

| 场景 | 模式 | 说明 |
|------|------|------|
| 配置运动参数 | EditTime | 速度、坐标系、周期、延时、停顿等用 `scene_configure_ability` |
| 运行时启停运动器 | Runtime | 用 `blockly-dsl` `property.set` 写 `BaseMoveAbility.integratedMoverEnable` |
| 预览/平滑/坐标系/运动细节 | EditTime | 不作为运行态指令控制项 |

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| Obby 跑酷关卡 | basemove + model(碰撞) + preciseEdit |
| 按钮控制升降平台 | basemove + interactive |
| 旋转障碍+伤害 | basemove + touchDetector + combat |
| 机械结构(齿轮组) | basemove + preciseEdit(父子跟随) |
| 波浪效果(多平台错开) | basemove(不同 DelayStartTime) |
| 消失平台 | basemove(scaleRepeat) + model(collision) |

> JSON 指令示例: `basemove/examples.md`

## V2 运行约束

- Use BaseMoveAbility for moving platforms, elevators, conveyor belts, windmills, rotating hazards, pendulums, and scaling/breathing platforms.
- Use nested paths such as BaseMoveAbility.baseMoveConfig_Move.linearSpeed; flat paths such as BaseMoveAbility.linearSpeed are compatibility aliases only.
- Speed values are vectors; do not send scalar values such as 50.
- Use motionCoordinate friendly values worldAxis/世界坐标系 -> 0 and localAxis/本地坐标系 -> 1.
- For one-way continuous rotation, set rotationRepeat=false.

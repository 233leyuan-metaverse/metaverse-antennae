# basemove — JSON 指令示例

> 配合 `basemove/body.md` 和 `basemove/reference.md` 使用。示例中的 ID / GUID 都是占位符；升降用 Z 轴，水平移动再改 X/Y。

---

## EditTime 最小片段

### 启用运动器 + 上下移动
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 旋转门
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 呼吸灯（缩放动画）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 摆动钟摆
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 配置平移延时和停顿
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## 完整场景示例

### 创建上下移动平台
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_create_object`, `scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 创建旋转风车
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_create_object`, `scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 复合运动机关（平移+旋转）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_create_object`, `scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

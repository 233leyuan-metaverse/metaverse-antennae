# worldUIV2 — JSON 指令示例

> 配合 worldUIV2 SKILL.md 主文件使用。所有 GUID 为占位符，实际使用时替换为真实资源 GUID / 对象 ID。
> **两层分工**：canvas 内容（条/文本/排版）一律用 `build_ui_screen(surface="world")` 产；挂实体（worldUIV2/world_ui_mount/transform）与绑数据（`ui_bind_property`）走指令。
> **guid 必须回读**：build_ui_screen 落盘后控件 guid 由编辑器重发，agent 起的名字不生效。canvasGuid 取 build_ui_screen 返回的挂载 canvasGuid，widgetGuid 用 `inspectUiDetail({"canvasGuidList":["<canvasGuid>"]})` 的 `widgets` 回读（画布作用域，按 name 匹配）。**绝不预测 guid**。
> ⚠️ 回读紧跟 build_ui_screen 之后做，中途不切回 screenUI 子模式（canvasMap 按子模式隔离）。
> **前提**: worldUIV2 挂载与槽位设置统一通过 `world_ui_mount`，不要拆成底层能力/槽位/属性命令。

---

## 基础操作示例

### 添加世界UI(WorldUI/3DUI)能力
无需单独挂能力；调用 `world_ui_mount` 时由 Application Service 幂等完成。

### 挂载世界 UI
使用 `world_ui_mount`，参数以当前 Tool Schema 为准；槽位与属性写入由 Application Service 内部完成。

### 为模型对象挂载世界UI（世界空间）

> canvas 内容先用 `build_ui_screen(surface="world")` 产，拿到挂载 canvasGuid（这里占位 `chest_label_canvas`），再挂实体。

`world_ui_mount(target=<对象>, canvas_guid=<真实canvasGuid>, settings={"spaceMode": 0, "transform": <计算值>})`，写入后 inspect。
> 如果 WorldUI 只是纯展示文本/进度条，`spaceMode` 按用户需求选择，`touchEnable` 可不设。`spaceMode=1(Screen)` 渲染到屏幕、等效始终朝向玩家并置顶，`transform` 只设 pos、不设 rot/scale，也不要再设置 `alwaysFaceCamera` / `alwaysOnTop`。图层里有按钮/输入框时：World(`spaceMode=0`) 必须设 `touchEnable=true`；Screen(`spaceMode=1`) 默认支持交互，无需 `touchEnable`。

### 设置 transform（位置 + 旋转 + 缩放，管道分隔）

`_Transform` 的 `value` 格式为 **`pos|rot|scale`**（与 `templates` skill 的 `_Transform` 约定一致）。贴附到模型或悬浮在头顶时，**三段都要写**；仅改高度时 rot 可为 `0,0,0`，scale 按牌面/可视需求调整。

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 设置可见距离

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## 完整场景示例

### NPC 名称标签（世界空间，按需设 alwaysFaceCamera）

**① build_ui_screen 产标签 canvas**（surface=world，tree 节点描述结构，不手算坐标）:

```python
import json
spec = {
    "surface": "world",
    "kind": "screen",
    "title": "NPC名称",
    "worldWidth": 300, "worldHeight": 120,
    "tree": {
        "type": "col", "pad": 12, "gap": 6,
        "children": [
            { "type": "title", "text": "村民" },
            { "type": "text", "text": "友好 NPC", "size": 20 }
        ]
    }
}
result = build_ui_screen(request_json=json.dumps(spec, ensure_ascii=False), name="NpcNameLabel")
# result["canvasGuid"] → 下一步 targetUICanvasGuid；禁止用 result["newAssetGuid"] 顶替 canvasGuid
```

**② 挂实体**（worldUIV2 + 槽位 + 属性；`<canvasGuid>` = ① 返回的挂载 canvasGuid）:

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

> 该示例是纯展示标签，所以未开启 `touchEnable`。若 WorldUI 含按钮或输入框，在 `world_ui_mount.settings` 中传 `touchEnable=true`；Screen 模式默认支持交互。

---

### 广告牌 / 告示牌贴字（世界空间，rot 必填）

> **UI 平面正面朝 +X，模型正面朝 +Y，差 90°。** 贴面前先把 `worldUIV2.worldUIData.0.transform` 的 **rot 设为 `(0,0,90)`**，UI 正面即对齐模型正面 +Y。rot 是 **local** 值，世界UI 随模型一起转（worldRot 变、localRot 不变），所以不用管模型朝向；只有想让 UI 故意偏离模型正面时才在 `(0,0,90)` 上再加偏转。**禁止**只写 `pos` 或沿用已废弃的 `_offset` 路径。
> 下面是**结构模板，不是可直接照抄的数值答案**。必须先结合 `sideapi_inspect(operation="inspectSceneObjectDetail", request_json={"gameObjectIds":["<gameObjectId>"]})` 的场景对象详情，或 `getAssets` / 资源详情返回的模型 `boundInfo` / `boundSize`（高度、厚度、锚点），并调用 `sideapi_inspect(operation="inspectUiDetail", request_json={"canvasGuidList":["<canvasGuid>"]})` 获取 `worldCanvasWidth/worldCanvasHeight` 后，再根据对象当前 rotation 与截图效果，计算实际 `pos|rot|scale`。**没有宿主真实尺寸或 WorldUI 图层尺寸时，禁止生成最终 transform 数值。**

**① build_ui_screen 产告示牌 canvas**（牌面文字排版，尺寸按牌面给 worldWidth/worldHeight）:

```python
import json
spec = {
    "surface": "world",
    "kind": "screen",
    "title": "公告",
    "worldWidth": 512, "worldHeight": 256,
    "tree": {
        "type": "col", "pad": 24, "gap": 12,
        "children": [
            { "type": "title", "text": "公告" },
            { "type": "text", "text": "前方危险，注意脚下", "size": 28 }
        ]
    }
}
result = build_ui_screen(request_json=json.dumps(spec, ensure_ascii=False), name="NoticeBoard")
```

**② 挂实体 + transform**（计算顺序见下；`<canvasGuid>` = ① 返回值）:

计算顺序：
1. **先对齐正方向（rot）**：用 `sideapi_inspect(operation="inspectPropertyValues", request_json={"target":"scene","queries":[{"gameObjectId":"<gameObjectId>","paths":["worldUIV2.worldUIData.0.transform"]}]})` 读 rot；≠ `(0,0,90)` 就设为 `(0,0,90)`，UI 正面(+X) 即对齐模型正面(+Y)。rot 是 local 值、随模型转，不用管模型朝向（想故意偏离才在此基础上再加偏转）。对齐后再算 pos/scale。
2. **查询宿主尺寸**：`sideapi_inspect(operation="inspectSceneObjectDetail", request_json={"gameObjectIds":["<gameObjectId>"]})` 获取场景宿主对象详情；详情缺有效 bounds 再查资源详情 / `getAssets`。拿到可用 `boundInfo` / `boundSize` 后才能算贴面距离。
3. **查询 WorldUI 图层尺寸**：`sideapi_inspect(operation="inspectUiDetail", request_json={"canvasGuidList":["<canvasGuid>"]})` 获取 `worldCanvasWidth/worldCanvasHeight`（① 里给的 `worldWidth/worldHeight`，落盘后回读确认）。
4. 设置 `transform.pos`：**坐标轴随 rot 一起转（rot 绕 Z）**。rot=`(0,0,0)` 时 前+X/后-X/左+Y/右-Y/上+Z/下-Z；rot=`(0,0,90)`（已对齐模型）时 前+Y/后-Y/左-X/右+X/上+Z/下-Z。对齐后贴正面沿"前"推出防穿模（≥10cm）：`pos.y=模型前向半厚+max(10cm,余量)`、`pos.x=左右偏移`、`pos.z=面中心高度`。
5. 设置 `transform.scale`：世界UI 缩放受父节点（模型）缩放影响——**实际尺寸 = 图层px(1px=1cm) × scale × 模型scale**。目标真实尺寸 → `scale = 目标cm ÷ (图层px × 模型scale)`（例：模型 scale=0.5、图层 100×100，要 100×100cm 需 scale=2）。内容建议占牌面 **50%~80%**，文字少放大、多则换行。

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

> rot 段固定 `0,0,90`（UI 正面对齐模型 +Y）。对齐后坐标轴：前+Y/上+Z/右+X，pos 第一段（x,y,z）通常形如 `<左右偏移>,<前向半厚+epsilon>,<面中心高度>`（`epsilon ≥ 10cm`）；scale 需按模型 scale 折算（`目标cm ÷ (图层px × 模型scale)`）。占位符必须查到宿主真实 bounds 与模型 scale 后替换成实际数值，不要把尖括号原样发给工具。

---

### ❌ 角色自身血条（不要用 worldUIV2 — 请用 health 内置 HeadUI）

> 有 `health` 能力（combat skill）的对象，其 **自身** 3D 血条由 health 能力内置 HeadUI 统一管理。
> 直接设 `hpVisibleMode` 即可，**不要**给该对象再挂 worldUIV2 另造 ProgressBar 绑定自己的 `hp`——冗余且难维护。
>
> **这不适用于**：独立告示牌/公告牌上显示远程对象（如某玩家/BOSS）的 HP——那种场景 build_ui_screen + worldUIV2 + `ui_bind_property` 是正确方案，见下方“动态数据绑定”示例。

---

### 动态数据绑定 — Text `ui_bind_property`（玩家HP实时显示）🥇

> 场景：独立告示牌显示当前玩家的实时 HP 值。EditTime 属性绑定，引擎自动同步，无需 Runtime 轮询。

**① build_ui_screen 产文本 canvas**:

```python
import json
spec = {
    "surface": "world",
    "kind": "screen",
    "title": "玩家血量",
    "worldWidth": 400, "worldHeight": 160,
    "tree": {
        "type": "col", "pad": 16, "gap": 8,
        "children": [
            { "type": "title", "text": "玩家血量" },
            { "type": "text", "id": "hp", "text": "100", "size": 48 }
        ]
    }
}
result = build_ui_screen(request_json=json.dumps(spec, ensure_ascii=False), name="PlayerHpText")
```

**② 回读 widgetGuid**:

```python
# 紧跟 ①，不切 submode。用 inspectUiDetail（画布作用域）而非 inspectUiTree（全局累积，多画布会挑到别的画布同名陈旧控件 → `ui_bind_property` 报 UI_WIDGET_MISSING）。
detail = sideapi_inspect(operation="inspectUiDetail",
                         request_json='{"canvasGuidList":["<canvasGuid>"]}')
# 返回 data.canvases[].widgets = [{name, widgetGuid}, ...]，仅该画布的控件。
# 定位：你在 tree 里给的叶子 id（如 {"type":"text","id":"hp"}）会落进 widget 的 name
#       （多个同名会变 "hp"/"hp_1"）→ 找 name 含 "hp" 的那个，取它的 widgetGuid。
```
> ⚠️ 用 `inspectUiDetail` 的 `widgets`，**别用** `inspectUiTree`（它返回所有已挂载画布的控件，多画布并存会挑错）。canvas 里还有系统自带控件，按 name 精确挑。

**③ `ui_bind_property` 绑玩家 HP**（`<C>` = ① 挂载 canvasGuid，`<W>` = ② 回读的 hp 文本 widgetGuid）:

`ui_bind_property(action="bind", surface="world", canvas_guid=<C>, widget_guid=<W>, path="data.textProperties.textProperties.text", entity_from="player", data_from="component", ability_name="health", property_name="hp")`

> `entity_from="player"` 绑定当前玩家，**不传 `target`**
> `propertyName:"hp"` = 运行时 HP；最大血量用 `"maxHp"`
> 绑定后**无需 Runtime 代码**，引擎自动同步 HP 变化到 Text

### 动态数据绑定 — ProgressBar `ui_bind_property`（玩家HP进度条）🥇

> 场景：独立告示牌显示 HP 进度条（当前值 / 最大值），引擎自动更新。

**① build_ui_screen 产进度条 canvas**（`bar` 是真 MWProgressBar，不是图片模拟）:

```python
import json
spec = {
    "surface": "world",
    "kind": "screen",
    "title": "血量",
    "worldWidth": 400, "worldHeight": 160,
    "tree": {
        "type": "col", "pad": 16, "gap": 8,
        "children": [
            { "type": "title", "text": "血量" },
            { "type": "bar", "id": "hp", "percent": 1.0, "h": 48 }
        ]
    }
}
result = build_ui_screen(request_json=json.dumps(spec, ensure_ascii=False), name="PlayerHpBar")
```

**② 回读 widgetGuid**（同上，`inspectUiDetail` 的 `widgets`，按 `name` 含你给的 `id` 定位 bar）

**③ `ui_bind_property` 绑 currentValue + sliderMaxValue**（`<C>` = 挂载 canvasGuid，`<W>` = bar widgetGuid）:

分别调用两次 `ui_bind_property`：`path="data.barProperties.currentValue", property_name="hp"` 与 `path="data.barProperties.sliderMaxValue", property_name="maxHp"`；其余参数使用 `surface="world", entity_from="player", data_from="component", ability_name="health"`。
> `bar` 节点已带默认 `sliderMinValue=0`（build_ui_screen 固化，不绑定）。
> 属性类型由 Contract 路径自动推导。ProgressBar 引擎根据 currentValue / sliderMaxValue 自动计算填充百分比。

### 动态数据绑定 — Text `ui_bind_property`（场景对象属性）

> 场景：告示牌显示指定 BOSS/NPC 的 HP。与 player 绑定的区别：`entity_from="scene"` + `target=<唯一对象>`。
> canvas 仍由 build_ui_screen 产、widgetGuid 仍回读，仅 `ui_bind_property` 的 entity 来源不同。

`ui_bind_property(action="bind", surface="world", canvas_guid=<C>, widget_guid=<W>, path="data.textProperties.textProperties.text", entity_from="scene", target=<唯一对象>, data_from="component", ability_name="health", property_name="hp")`

### 动态数据绑定 — Text `ui_bind_property`（玩家自定义数据）

> 场景：告示牌显示玩家金币/分数等自定义属性。canvas 由 build_ui_screen 产、widgetGuid 回读。

`ui_bind_property(action="bind", surface="world", canvas_guid=<C>, widget_guid=<W>, path="data.textProperties.textProperties.text", entity_from="player", data_from="user_property", property_key=<inspectUserData返回uuid>)`

---

### 道具说明牌（屏幕空间）

> spaceMode=1(Screen) 时，WorldUI 渲染到屏幕，效果等同始终朝向玩家并置顶；`transform` 只设 pos（位置），无需 rot/scale，也不要再设置 `alwaysFaceCamera` / `alwaysOnTop`。canvas 内容仍由 build_ui_screen(surface="world") 产，仅挂实体时 spaceMode 设 1。Screen 模式含按钮或输入框时默认支持交互，无需 touchEnable。

**① build_ui_screen 产说明牌 canvas**:

```python
import json
spec = {
    "surface": "world",
    "kind": "screen",
    "title": "神秘宝箱",
    "worldWidth": 400, "worldHeight": 160,
    "tree": {
        "type": "col", "pad": 16, "gap": 8,
        "children": [
            { "type": "title", "text": "神秘宝箱" },
            { "type": "text", "text": "开启获得随机奖励", "size": 22 }
        ]
    }
}
result = build_ui_screen(request_json=json.dumps(spec, ensure_ascii=False), name="ItemDescCard")
```

**② 挂实体（spaceMode=1 屏幕空间）**（`<canvasGuid>` = ① 返回值）:

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---
name: worldUI
nameZh: 世界界面
abilityNames: [worldUIV2]
keywords: 世界UI,世界空间UI,3D界面,对象UI,名称标签,WorldUI,世界标签,悬浮UI,NPC标签,贴附UI,动态血量,进度条,公告牌,告示牌
depends: [ui]
description: |
  能力：将 2D UI Canvas 贴附在 3D 游戏对象上，支持世界空间与屏幕空间两种模式。
  适用: NPC名称标签、道具悬浮说明牌、世界空间告示牌、动态数据展示（血量/计时/计分 — 推荐 `ui_bind_property` 属性绑定，引擎自动同步无需 Runtime 轮询）。
  canvas 内容（控件/布局/视觉）用 build_ui_screen(surface="world") 产，再回读 guid 挂实体/绑数据。
  ❌ 角色自身血条: 有 health 能力的对象，其血条由 health 内置 HeadUI 负责，不要用 worldUIV2 另造 ProgressBar 绑定自身 hp。
  ✅ 独立告示牌显示远程数据(如某玩家HP): build_ui_screen(surface=world) 产 canvas + worldUIV2 挂实体 + `ui_bind_property`，EditTime 绑定后引擎自动同步。
---

# WorldUI 世界UI系统

能力名: `worldUIV2` | 组件: `WorldUIComponentV2`(ownerComponent:0)
支持对象: Model、Character、MeleeWeapon、HotWeapon、Gear、Props、CustomModel## 🧱 两层分工（先记这个）

worldUI 做出来要分两层，别混：

| 层 | 装什么 | 走什么 |
|----|--------|--------|
| **UI 内容** | 血条、文本、告示牌排版、布局 | **`build_ui_screen(surface="world")`** 创建/修改 canvas 内容并 saveUiFile 落盘 |
| **挂实体 + 绑数据** | 把 canvas 贴到 3D 对象、绑 HP/数据、运行时逻辑 | `world_ui_mount(target, canvas_guid, settings)` + `ui_bind_property` |

**衔接命门**：build_ui_screen 落盘后控件 guid 由编辑器**重新生成**，agent 起的名字不生效——所以 **canvasGuid 只用 build_ui_screen 返回体的 `canvasGuid`；若为空，必须立刻 `inspectUiDetail` / `inspectUiTree` 回读真实 worldUI 图层 `canvasGuid`。`newAssetGuid` 是资源 GUID，禁止喂给 `worldUIV2.worldUIData.{index}.targetUICanvasGuid`。widgetGuid 用 `inspectUiDetail({"canvasGuidList":["<canvasGuid>"]})` 的 `widgets` 回读**（画布作用域，按 widget `name`==你给的节点 `id` 匹配），再喂给挂实体(`targetUICanvasGuid`)和 `ui_bind_property`(`widgetGuid`)。⚠️ **绝不预测 guid**。

> ⚠️ **为什么用 inspectUiDetail 不用 inspectUiTree 拿 widgetGuid**：`inspectUiTree` 返回**所有已挂载画布**的控件（全局累积），多画布并存时按 name/type 找会挑到**别的画布的同名陈旧控件**，`ui_bind_property` 拿错 guid 报 `UI_WIDGET_MISSING`。`inspectUiDetail` 的 `widgets` 是**该画布作用域**，稳。
> ⚠️ **回读时序**：回读必须**紧跟 build_ui_screen(surface=world) 之后**做，中途**不要切回 screenUI 子模式**（编辑器 canvasMap 按子模式隔离，切走就查不到 worldUI 的 canvasGuid）。canvasGuid 直接取 build_ui_screen 返回的 `canvasGuid`；没有该字段就先回读，不要用 `newAssetGuid` 顶替。
> ⚠️ **spaceMode 规则**：`0`=World（3D 贴场景对象，必须设 `transform` 的 `pos|rot|scale`），`1`=Screen（渲染到屏幕，等效始终朝向玩家并置顶，`transform` 只设 pos、无需 rot/scale，也不生成 `alwaysFaceCamera`/`alwaysOnTop`）。画布内有按钮/输入框时：World 必须设 `worldUIV2.worldUIData.{index}.touchEnable=true`；Screen 默认支持交互，无需 `touchEnable`。没有按钮/输入框时 `spaceMode` 按需选择。
> ⚠️ **alwaysFaceCamera 规则（用户优先）**：AI 可自行判断是否开启（广告牌/告示牌通常 `true`，标签/纯文字通常 `false`）。但**用户一旦明确说了就必须服从**：用户说"始终面向玩家/摄像机/我"→ 强制 `true`；用户说"不要面向玩家/固定朝向/不动"→ 强制 `false`。用户没表态时 AI 自由裁量。

## 🚦 决策树

| 我想做… | 方案 |
|---------|------|
| 角色/NPC 自身头顶血条 | ❌ worldUIV2 → ✅ `health` 内置 HeadUI（`hpVisibleMode` 开箱即用） |
| 独立告示牌显示"当前玩家"动态HP/数据 | ✅ worldUIV2 + `ui_bind_property`(`player`)，引擎自动同步 |
| 独立告示牌显示"指定对象"动态数据 | ✅ worldUIV2 + `ui_bind_property`(`scene`) + 目标 `gameObjectId` |
| 静态标签/固定文字告示牌 | ✅ worldUIV2，EditTime 一次性配置 |
| 进度条（HP百分比/经验条） | ✅ worldUIV2 + `ui_bind_property`（currentValue + sliderMaxValue 分别绑定） |
| 贴 3D 对象、需按位置/缩放/朝向摆放 | ✅ worldUIV2 + `spaceMode=0`(World) + `transform`(pos\|rot\|scale) |
| World 上有按钮/输入框 | ✅ worldUIV2 + `spaceMode=0` + `touchEnable=true` + UI 控件 Blockly 事件/输入事件 |
| 屏幕空间提示牌（始终朝玩家/置顶） | ✅ worldUIV2 + `spaceMode=1`(Screen)；`transform` 只设 pos，不生成 `alwaysFaceCamera`/`alwaysOnTop`；有按钮/输入框也默认可交互，无需 `touchEnable` |
| 格式化拼接文本（"HP: 100/500"）/条件变色 | ⚠️ `ui_bind_property` 做不到 → 运行态用 `blockly-dsl` 积木（写：`WorldUISetTextInstruction`，owner=玩家；读：`WorldUIGetTextInstructionWithoutPlayer`，**禁止 owner=玩家**，owner=挂 worldUIV2 的宿主，玩家在 `targetEntity`） |
| 屏幕 HUD（非贴3D对象） | ❌ worldUIV2 → ✅ 直接用 `ui` skill |

## ⚡ 最小路径

### A. 静态标签
> 使用 `world_ui_mount` 一次完成能力、槽位与显示设置；参数只按当前 Tool Schema 生成，并在写入后执行 readback。
> 简单悬浮标签跳过精确贴面那步；`alwaysFaceCamera` AI 自行决定（用户表态则强制服从）

### B. 动态数据 `ui_bind_property` 🥇
> 先 `world_ui_mount`，再按当前 Tool Schema 调用 `ui_bind_property`，写入后执行 readback。
> `ui_bind_property` 是 EditTime 配置，引擎 Runtime 自动同步。**无需 NewTimerInstruction / WorldUISetTextInstruction。**
> canvas 内容（条、文本、排版）都在 ① 的 build_ui_screen 里产；修改内容时更新 screenSpec 后重新保存。

### C. Runtime 轮询（兜底）— 8+ 次 tool call
仅在 `ui_bind_property` 无法覆盖时使用（格式化拼接、条件变色、排行榜）。运行时逻辑统一走 `blockly-dsl` 生成积木 DSL，表达定时刷新与 `WorldUISetTextInstruction` 更新文本；需要回读当前控件文本时用 `WorldUIGetTextInstructionWithoutPlayer`。

## 📐 Transform 速算

`transform` 格式：`"pos.x,pos.y,pos.z | rot.x,rot.y,rot.z | scale.x,scale.y,scale.z"`（仅 World 模式需要；Screen 模式只设 pos）。

**① 对齐正方向（rot）**。世界UI 自身正面朝 **+X**，模型正面朝 **+Y**，差 90°。rot 是 **local** 值：世界UI 是模型子节点，模型转动它跟着转（worldRot 变、localRot 不变），所以不用管模型朝向——把 rot 设成 `(0,0,90)`，UI 正面即对齐模型正面 +Y。
- 读现值：`sideapi_inspect(operation="inspectPropertyValues", request_json={"target":"scene","queries":[{"gameObjectId":"<gameObjectId>","paths":["worldUIV2.worldUIData.{index}.transform"]}]})`，看 rot；≠ `(0,0,90)` 就用 `scene_configure_ability` 设为 `(0,0,90)`。（想让 UI 故意偏离模型正面，才在此基础上再加偏转。）

**② 算 pos（坐标轴随 rot 一起转，rot 绕 Z 轴）**。改 rot 后方向轴跟着转，按当前 rot 定方向：

| rot | 前 | 后 | 左 | 右 | 上 | 下 |
|---|---|---|---|---|---|---|
| `(0,0,0)`（正方向 +X） | +X | -X | +Y | -Y | +Z | -Z |
| `(0,0,90)`（正方向 +Y，已对齐模型） | +Y | -Y | -X | +X | +Z | -Z |

**先按当前 rot 把"前方/上方"落到具体 pos 分量**（对齐模型 `rot=(0,0,90)` 时：前方=+Y、上方=+Z、右=+X；未旋转 `rot=(0,0,0)` 时前方=+X）。**先查 `boundSize`**（`sideapi_inspect(operation="inspectSceneObjectDetail", request_json={"gameObjectIds":["<gameObjectId>"]})`），再按放置意图选方向：

- **贴正面（广告牌）**：沿**前方**推出防穿模 = 模型前向半厚 + max(10cm,余量)（前向半厚=模型沿正面法线的 boundSize 的一半）；左右、高低居中。⚠️ 前方偏移为 0 会把 UI 埋进模型——对齐后前方就是 +Y，所以此时必须给 `pos.y`。
- **放头顶（悬浮标签）**：不用前方偏移，沿**上方**往上放 `pos.z = 模型最高点 + 余量`（≈ `boundSize.z/2`，或从 bounds 顶点算）；左右、前后居中。

**③ 算 scale（受模型缩放影响）**。世界UI 缩放会被父节点（模型）缩放放大缩小：**实际渲染尺寸 = 图层像素(1px=1cm) × `transform.scale` × 模型 scale**。
- 先拿模型 scale（同上 `inspectSceneObjectDetail`）。目标真实尺寸 → `transform.scale = 目标cm ÷ (图层px × 模型scale)`。
- 例：模型缩放 `0.5`、图层 `100×100px`、`transform.scale=1` → 实际渲染 `50×50cm`；要 `100×100` 得设 `transform.scale=2`。
- 图层像素 = `inspectUiDetail` 回读的 `worldCanvasWidth/worldCanvasHeight`（build_ui_screen 的 `worldWidth/worldHeight`，缺省 `512×512`，范围 `64-1024`）；禁止按固定 1920×1080 推导。

| 场景 | pos（rot=0,0,90：前+Y/上+Z/右+X） | rot | scale |
|------|------|-----|-------|
| 正面告示牌（贴模型正面 +Y） | `左右偏移, 模型前向半厚+max(10cm,余量), 面中心高度` | `0,0,90`（UI 正面对齐模型 +Y） | `目标cm ÷ (图层px × 模型scale)` |
| 头顶悬浮（+Z） | `0, 0, boundSize.z/2+50` | `0,0,90`（默认不旋转） | 同上按模型 scale 折算 |

> 禁止不经查询写固定值。rot 不是固定值，需根据模型当前 rotation 计算。

## 🔑 属性速查

> 完整属性表见 `worldUI/reference.md` → `## worldUIV2 — 世界UI能力（WorldUIEntryDataV2 数组元素）` 下 `### 属性`。

## 📦 `ui_bind_property` 属性绑定（核心片段）

> canvas 与控件已由 `build_ui_screen(surface="world")` 产好；下面 `ui_bind_property` 里的 `<C>`=回读到的 canvasGuid、`<W>`=`inspectUiDetail` 的 `widgets` 回读到的 widgetGuid（画布作用域，按 name 匹配）。**不要自己起名/预测 guid**（落盘后编辑器会重发 guid）。

**Text 绑定玩家 HP**：调用 `ui_bind_property(action="bind", surface="world", canvas_guid=<C>, widget_guid=<W>, path="data.textProperties.textProperties.text", entity_from="player", data_from="component", ability_name="health", property_name="hp")`，写入后 inspect。
> `entity_from="player"` 不传 `target`。绑定后引擎自动同步，无需 Runtime 代码。

**ProgressBar 绑定玩家 HP 进度**:
> 旧底层 payload 示例已移除。对应 V2 调用：`ui_bind_property`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。
> `surface="world"` 必须与所属 Canvas 一致；属性类型由 Contract 根据 `path` 自动推导。

**变体 — 绑定场景对象**（非玩家）: `entity_from="scene"`，需填 `target=<唯一对象>`
**变体 — 绑定玩家自定义数据**: `data_from="user_property"`，需填 `property_key=<inspectUserData 返回的 uuid>`

> 完整分步 JSON 模板 → `worldUI/examples.md`

## 运行态 WorldUI 指令（供 blockly 使用）

> World UI 运行态指令: `blockly-dsl/reference.md` →「积木所支持指令列表」→ `### 指令·UI对话`。

## ⚠️ 约束速查

| # | 规则 | 违规后果 |
|---|------|---------|
| 1 | 使用 `world_ui_mount` 创建槽位并设置 canvas/显示参数 | 能力、槽位或属性不完整 |
| 2 | 后续修改前先 inspect 确认真实槽位索引 | 索引越界 |
| 3 | transform pos\|rot\|scale 三段必填，rot 不可省略 | 躺地/穿模/背面 |
| 4 | worldUIV2 全部属性 showInCommand=false，运行态文本走 `ui_bind_property`（首选）或 `blockly-dsl` 积木（写 `WorldUISetTextInstruction` / 读 `WorldUIGetTextInstructionWithoutPlayer`，兜底） | 指令无效 |
| 5 | `spaceMode=0(World)` 必须设 `transform`(pos\|rot\|scale) 贴场景；`spaceMode=1(Screen)` 渲染到屏幕、`transform` 只设 pos，不设 rot/scale，也不生成 `alwaysFaceCamera` / `alwaysOnTop` | 冗余配置、误判渲染行为 |
| 6 | 无 boundSize 或无 worldCanvasWidth/worldCanvasHeight 禁止写 transform 具体值 | 穿模/错位/比例错误 |
| 7 | `world_ui_mount.target` 传唯一场景目标，`canvas_guid` 与显示参数放入该工具声明的字段；不要再拆成底层槽位命令 | 重复槽位或参数漂移 |
| 8 | 世界 UI 尺寸必须从 `inspectUiDetail`（`request_json={"canvasGuidList":["<canvasGuid>"]}`）读取；不要用 `inspectUiTree` 的 `data.viewport`（那是屏幕尺寸） | 把屏幕尺寸误当世界 UI 尺寸 |
| 9 | 创建/修改 canvas 内容只用 `build_ui_screen(surface="world")`，改内容时更新 screenSpec 后重新保存 | 内容与 `.ui` 落盘一致 |
| 10 | canvasGuid/widgetGuid 必须回读：canvasGuid 取 build_ui_screen 返回；widgetGuid 用 `inspectUiDetail` 的 `widgets`，不要用 `inspectUiTree` | `ui_bind_property`/挂实体定位准确 |
| 11 | WorldUI 画布内有按钮/输入框：World(`spaceMode=0`) 必须设 `worldUIV2.worldUIData.{index}.touchEnable=true`（默认 false）；Screen(`spaceMode=1`) 默认支持交互，无需 `touchEnable` | World 下漏设时按钮点击/输入无响应 |

## 🔗 跨 Skill 速查

| 需求 | Skill | 精确字段 |
|------|-------|---------|
| Text 绑定玩家 HP | `ui` `ui_bind_property` | `path="data.textProperties.textProperties.text"`, `entity_from="player"`, `data_from="component"`, `ability_name="health"`, `property_name="hp"` |
| ProgressBar 绑定 HP | `ui` `ui_bind_property` | `path:"data.barProperties.currentValue"`→hp, `sliderMaxValue`→maxHp, 属性类型自动推导 |
| 绑定场景对象 | `ui` `ui_bind_property` | `entity_from="scene"` + `target` |
| 绑定玩家自定义数据 | `ui` `ui_bind_property` | `data_from="user_property"` + `property_key` |
| 创建 canvas 内容（条/文本/排版） | `ui` | `build_ui_screen(request_json=<screenSpec>, surface="world", name=...)`，screenSpec 用 `tree` 节点(bar/text/title/image)描述结构，**不手算坐标** |
| 回读控件 guid | inspect | build_ui_screen 返回挂载 canvasGuid；`sideapi_inspect(operation="inspectUiDetail", request_json={"canvasGuidList":["<canvasGuid>"]})` 的 `widgets`（画布作用域，按 name 匹配节点 id）拿各 `widgetGuid` |
| 查 worldUIV2 槽位数 | inspect | `sideapi_inspect(operation="inspectSceneObjectAttachments", request_json={"gameObjectIds":["<gameObjectId>"]})` → `data.objects[].worldUiCount` |

## V2 运行约束

- **全部 showInCommand=false**: 所有属性均为 EditTime（编辑态）only，不支持 sideapi_blockly_compile 运行时修改
- **先挂载能力**: 所有属性设置前必须先通过 `scene_set_ability` 挂载 `worldUIV2` 能力
- **World 模式**: `spaceMode=0` 是贴在场景对象上的 3D UI，必须设置 `transform`（`pos|rot|scale` 三段）来贴面/悬浮/缩放
- **正方向对齐**: 世界UI 正面朝 **+X**、模型正面朝 **+Y**，差 90°。算 pos/scale 前先 `inspectPropertyValues` 读 rot，≠ `(0,0,90)` 就设为 `(0,0,90)`，UI 正面即对齐模型 +Y。rot 是 local 值、随模型一起转，不用管模型朝向（想故意偏离才在此基础上再加偏转）
- **交互控件**: 画布内含按钮、输入框等需点击/输入的控件时——World(`spaceMode=0`) 必须设 `touchEnable=true`；Screen(`spaceMode=1`) 默认支持交互，无需 `touchEnable`
- 全部属性均为编辑态(showInCommand=false)，不支持运行态属性命令；运行态显隐用 WorldUICanvasVisibleInstruction / WorldUIWidgetVisibleInstruction。
- 本表只管挂实体属性；canvas 内容(控件/布局)由 build_ui_screen(surface="world") 产。
- spaceMode=0(World)含按钮/输入框须 touchEnable=true 且要设 transform 的 pos|rot|scale；spaceMode=1(Screen)只设 pos, 默认支持交互, 不显示 alwaysFaceCamera/alwaysOnTop/touchEnable。
- World模式 transform 先对齐正方向：世界UI 正面 +X、模型正面 +Y，rot 是 local 值随模型转，把 rot 设为 (0,0,90) 即对齐, 无需管模型朝向。
- alwaysFaceCamera 默认 false 不主动开启；仅当用户明确要求'始终面向玩家/摄像机'或'贴合'时才设 true。
- pos 坐标轴随 rot 一起转(rot绕Z)：rot=(0,0,0)时 前+X/后-X/左+Y/右-Y/上+Z/下-Z；rot=(0,0,90)(对齐模型)时 前+Y/后-Y/左-X/右+X/上+Z/下-Z。
- pos 用'前方/上方'描述别硬记轴(对齐后前方才是+Y)：贴正面(广告牌)沿前方推出防穿模=模型前向半厚+max(10cm,余量)，左右/高低居中(对齐后前方=+Y, 前方偏移为0会埋进模型, 须给 pos.y)；放头顶(悬浮标签)不用前方偏移, 沿上方 pos.z=模型最高点+余量(≈boundSize.z/2)往上放, 左右/前后居中。
- scale 受父节点(模型)缩放：实际尺寸=图层px(1px=1cm)×scale×模型scale；目标真实尺寸 → scale=目标cm÷(图层px×模型scale)(例 模型scale0.5、图层100×100 要100×100cm 需 scale=2)。

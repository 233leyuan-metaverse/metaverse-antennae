---
name: damage
nameZh: 伤害能力
abilityNames: [DamageAbility]
keywords: 伤害区域,陷阱,触碰伤害,伤害,damage,伤害值,击退,暴击,持续伤害,爆炸,毒雾,knockback
depends: []
description: |
  DamageAbility 能力：伤害源配置（接触伤害/持续伤害）、击退效果、暴击系统、伤害事件绑定。
  适用: 设置陷阱/爆炸/毒雾伤害、击退效果、暴击率与倍率、伤害/击杀/暴击事件回调。
  常见组合: combat(目标需health才能受伤) + basic(阵营判定，必须!) + touchDetector(触发区域) + effect(伤害特效)。
---

# Damage 伤害系统

能力名: `DamageAbility`
组件: `DamageComponent`(ownerComponent:0)

## 关键约束 ⭐ (源自前端 DamageComponent.ts 验证)

1. **先挂载再设属性**: 修改 `DamageAbility.*` 前必须 `scene_set_ability` 挂载 DamageAbility

2. **⚠️ 阵营是伤害前置条件**: 前端代码(L770-783)明确检查:
   - 没有 FactionComponent → 直接 return（无法造成伤害）
   - **factionName === '1' → 直接 return**（阵营"1"=无，完全禁用伤害系统！玩家不要设为"1"）
   - 同阵营 → 直接 return（只对敌对阵营造成伤害）
   - **结论**: 伤害源和目标都必须有 `BasicAbility.faction`，且不能是"1"，且必须是不同阵营

3. **DamageType 枚举值**: `Instance`(=0,接触伤害) / `Duration`(=1,持续伤害)。**默认是 Duration(持续)**，不是 Instance
   - `interval` 属性仅在 Duration 模式下可见(editorSetInternalVisible)

4. **criticalChance 有 @displayPercent 装饰**: 显示为百分比，但存储的是原始值（如 criticalChance=20 表示 20% 暴击率）

5. **负数伤害 = 治疗**: `damageMagnitude` 范围 [-99999999, 99999999]，负值为治疗效果

## 属性与事件速查

> 完整属性表见 `damage/reference.md` 各能力节 `### 属性`。
> 事件路径与参数槽: `damage/reference.md` → `## 事件（Blockly 参数槽）`。
> 运行态指令 abilityId / owner / args: `blockly-dsl/reference.md` →「积木所支持指令列表」→ `### 指令·战斗技能BUFF与生命`（`ApplyDamageInstruction`）/ `grep ApplyKnockBack`。

## EditTime vs Runtime 决策

| 场景 | 模式 | 说明 |
|------|------|------|
| 初始化伤害/击退/类型 | EditTime+Runtime | `damageMagnitude` / `damageType` / `knockBack*` 均 `showInCommand=true`；编辑态先挂载 `DamageAbility` 再设值 |
| 设置暴击率/倍率 | EditTime+Runtime | `criticalChance` / `criticalMultiplier` 是 `showInProperty=false`、`canBeSetVisibleInProperty=true`、`showInCommand=true` |
| 伤害事件绑定 | → blockly-dsl 积木 | 用 `blockly-dsl` 生成积木，`event.eventPath="DamageAbility.showOnHurtOtherInstruction"`/`showOnKillOtherInstruction`/`showOnCriticalInstruction` |
| 直接脚本扣血 | Runtime 指令 | 用 `ApplyDamageInstruction`；它是一次性伤害链，不等同于修改 `DamageAbility.*` 配置 |

## 机关效果选型（何时用 DamageAbility）

**DamageAbility 适合最简单的「站在区域内持续掉血」**。机关**场景直建**见 `create_mechanism_in_scene`；**可复用预设**见 `create_mechanism_preset`。角色/NPC 场景直建见 `create_character_in_scene`。路由规则见 `prefabNodeEdit` 场景放置 SSOT。熔岩/毒雾等优先 Buff 路线。

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| 尖刺/地刺陷阱 | damage + basic(阵营!) + combat(目标需health) |
| 毒雾/火焰持续伤害（无 debuff/进区特效） | damage(Duration) + basic + combat + touchDetector |
| 熔岩/进区 debuff+周期+进区特效 | **buffEdit**（优先，见 create_mechanism_preset case） |
| 爆炸(接触+击退) | damage(Instance+knockBack) + basic + touchDetector |
| 伤害+击杀事件 | damage(showOnKillOtherInstruction) + blockly-dsl(奖励指令) |

> JSON 指令示例: `damage/examples.md`

## V2 运行约束

- Use health for combat characters, enemies, bosses, destructible targets, health bars, hurt/death/reborn events, and RPG attributes.
- Use hpVisibleMode friendly values always/onlyWhenHurt/hidden; Honey compiles them to Always/OnlyWhenHurt/Hidden.
- Use damageFloatEffect friendly values show/hide; Honey compiles them to 0/1.
- Most RPG/resource fields are non-negative JSON numbers, not strings.
- Use health.hp/health.maxHP only through a future runtime-command/instruction surface, not setEditTimeProperty.
- Use payload.damagePrereqDisposition to say how factions, health target, and collision/contact are satisfied or intentionally deferred.
- Use DamageAbility for persistent/contact traps, spikes, poison zones, hazards, or explosion barrels.
- Use ApplyDamageInstruction for direct scripted runtime damage; do not mix it with DamageAbility property writes.
- Use a normal scene object as the damage source; live DamageAbility excludes effect-only objects.
- Use DamageAbility.knockBackMagnitude_m2cm, not deprecated DamageAbility.knockBackMagnitude.

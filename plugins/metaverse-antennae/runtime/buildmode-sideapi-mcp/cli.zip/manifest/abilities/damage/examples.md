# damage — JSON 指令示例

> 所有 `gameObjectId` / GUID 为占位符；使用前替换为真实对象 ID 和资源 GUID。编辑态设置 `DamageAbility.*` 前必须先挂载 `DamageAbility`。

---

## EditTime 示例

### 接触伤害陷阱
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 持续伤害与暴击
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 高伤害击退
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## Runtime 示例（Blockly DSL）

### 运行态修改伤害源配置
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "trap_spike_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_set_damage_<rand8hex>" },
    "statements": [
      {
        "nodeId": "set_damage_1",
        "type": "property.set",
        "abilityId": "DamageAbility.damageMagnitude",
        "owner": { "type": "entity.scene", "gameObjectId": "trap_spike_01" },
        "operator": "=",
        "value": { "type": "literal", "valueType": "Number", "value": 80 }
      }
    ]
  }
}
```

### 命中目标时播放特效
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "fire_trap_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onHurt_<rand8hex>" },
    "event": {
      "eventPath": "DamageAbility.showOnHurtOtherInstruction",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "victimEntity", "name": "victim", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "play_hurt_effect_1",
        "type": "ability.call",
        "abilityId": "instruction.__80059/__687/PlayEffectOnGameObjectInstruction",
        "owner": { "type": "event.arg", "argId": "victimEntity" },
        "args": [
          { "type": "enum.value", "value": "0" },
          { "type": "asset.ref", "assetId": "火焰伤害特效GUID" },
          { "type": "literal", "valueType": "Number", "value": 2 },
          { "type": "literal", "valueType": "Vector", "value": [0, 0, 0] },
          { "type": "literal", "valueType": "Rotation", "value": [0, 0, 0] },
          { "type": "literal", "valueType": "Vector", "value": [1, 1, 1] },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Color", "value": [255, 255, 255, 1] },
          { "type": "literal", "valueType": "Color", "value": [255, 255, 255, 1] }
        ]
      }
    ]
  }
}
```

> 击杀和暴击事件只替换 `eventPath`：`DamageAbility.showOnKillOtherInstruction` / `DamageAbility.showOnCriticalInstruction`，参数槽仍按 `damage/reference.md`。

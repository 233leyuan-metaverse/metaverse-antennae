---
name: liteScene
nameZh: 多关卡 liteScene
abilityNames: [MatchArea]
keywords: 多关卡,子关卡,liteScene,跳关,跳转子关卡,传送关卡,关卡管理,匹配区域,MatchArea,满员跳关,两人匹配,多人匹配,inspectLiteSceneLevelList,lite_scene_manage,JumpPlayerToSubLevel,JumpAllPlayersToSubLevel,GetCurrentLiteSceneLevel,ConditionCurrentLiteSceneLevel,levelFileName,requiredCount,targetLevelFileName
depends: [blockly-dsl, basic]
description: |
  多关卡（liteScene）创建/删除/编辑器切关；MatchArea 满员匹配跳关；运行态 Jump*/取当前关/条件分支。
  适用: 新建子关、删关、编辑态切关、匹配区域满 N 人跳目标关、互动后传送玩家/全员、按当前关分支。
  排除: 角色经验/升级 → level skill；普通「走进去瞬移坐标」→ touchDetector/asset-presets 传送门，不是 MatchArea。
  常见组合: liteScene(MatchArea) + basic；liteScene + interactive + blockly-dsl。
---

# liteScene 多关卡

## 关键约束 ⭐（不可跳过）

1. **与 `level` skill 严格区分**
   - 本包 = **多关卡场景**（liteScene 子关卡文件）
   - `level` = **角色经验等级**（LevelAbility / AddExp）
   - ❌ 禁止把「建关卡 / 跳关」做成 LevelAbility 或猜 `skills/level`

2. **前置门控：先 inspect，再写关卡名**
   - **Step 1**：从需求提取目标关展示名 / 跳转意图（新建 / 删除 / 切关 / 玩法传送）
   - **Step 2**：调用 `sideapi_inspect(operation="inspectLiteSceneLevelList")`（无额外 request 亦可）
   - **Step 3**：只用返回的 `data.levels[].levelFileName` / `levelId` / `displayName`；`data.currentLevelFileName` 为当前编辑关
   - ❌ 禁止猜测 `关卡1`、`level1`、`NewLevel2` 等未回读名称
   - 若 `freshness.staleReasons` 非空：禁止瞎编；先排除编辑态未就绪 / 无 LiteSceneLevelMgr

3. **EditTime 只用 `lite_scene_manage`**
   - `action="create"` 创建，`action="delete"` 删除；字段按 Tool Schema
   - 编辑态切关不属于该工具：请用户在编辑器 UI 切关，或只用运行态 Jump* 传送玩家
   - 字段与模板见 `liteScene/reference.md`

4. **运行态一律 blockly-dsl**
   - Jump* / GetCurrent* → `ability.call`，`abilityId` 查 `blockly-dsl/reference.md`「指令·多关卡 liteScene」
   - 当前关分支：优先 `GetCurrentLiteSceneLevelInstruction` 返回值 + `compare` + `control.if`（不要猜关卡名）
   - ❌ 禁止手写 `sideapi_blockly_compile.data` 嵌套 GetFixed* 包装器（旧路径已废弃）
   - Jump* 的 `levelFileName` **必须来自 inspect 回读**

5. **输出顺序**
   - 需要新建关时：`inspect` → `lite_scene_manage(action="create")` →（可选）再 inspect 确认 → 再写运行态跳转
   - 仅玩法传送已有关：`inspect` → 运行态 Jump* / MatchArea（不要用 EditTime Jump=2）

## MatchArea 匹配区域 ⭐（满员跳关唯一正确路径）

用户说「匹配区域 / 两人匹配 / 满员跳关 / 排队进副本」时，**必须**走 Ability `MatchArea`，**禁止**下列冒充：

| 错误做法 | 为何错 |
|---------|--------|
| 只放正方体 `672403` 改名叫「匹配区域」 | 没有 MatchArea 能力，不会排队/满员跳 |
| `touchDetector` + 瞬移坐标 / 官方传送门 `710545` | 那是「走进去改坐标」，不是 liteScene 关卡传送 |
| 只挂 Jump* 积木假装匹配 | 无人数队列、无匹配按钮 |

### 正确步骤（不可跳过）

1. `inspectLiteSceneLevelList` → 取目标关真实 `levelFileName`（主关常见 `NewLevel`；禁止猜「主关卡」中文）
2. `scene_create_object` 放一个场景壳（可用 `672403` 正方体）→ 得到 `gameObjectId`
3. `scene_set_ability`：`abilityName="MatchArea"`（会自带 TouchDetector；**不要**再单独加 touchDetector 冒充）
4. `scene_configure_ability`：
   - `MatchArea.targetLevelFileName` = inspect 回读的目标关
   - `MatchArea.requiredCount` = 需要人数（两人匹配 → `2`；单机作品人数会被锁 1）
5. 建议：`model.collisionEnabled=false`，避免挡住玩家
6. **不要**再叠 Jump* 指令完成「匹配跳关」——满员传送由 MatchArea 内部 `switchLiteSceneForUsers` 完成

### 属性速查

| 路径 | 含义 |
|------|------|
| `MatchArea.targetLevelFileName` | 满员跳转目标关（须来自 inspect） |
| `MatchArea.requiredCount` | 需要人数（默认 2） |
| `MatchArea.matchButtonText` / `cancelMatchButtonText` | 按钮文案（可选） |
| `MatchArea.shape` | 区域形状（随 TouchDetector，可选） |

> 字段模板见 `liteScene/reference.md`；完整 JSON 见 `liteScene/examples.md`「MatchArea」。

## EditTime vs Runtime

| 场景 | 模式 |
|------|------|
| 新建 / 删子关 | EditTime `lite_scene_manage`（0/1；自动 liteSceneLevel readback） |
| 编辑器内切关 | **勿** SideAPI Jump=2；用户 UI 切关 |
| **匹配区域满员跳关** | EditTime **MatchArea** Ability（上节） |
| 玩法内立即传送单玩家 / 全员（无匹配） | blockly `JumpPlayer*` / `JumpAllPlayers*` |
| 读当前关 / 按当前关分支 | blockly `GetCurrent*` + `control.if`；或Contract 声明内 Condition 指令 |

## 常见组合

| 场景 | skills |
|------|--------|
| **两人匹配进主关 / 副本关** | liteScene（MatchArea） |
| 通关点立即传送下一关（无排队） | liteScene + interactive/touchDetector + Jump* |
| 按当前关分支逻辑 | liteScene + blockly-dsl（control.if） |
| 先建副本关再挂匹配区 | `lite_scene_manage(action="create")` → inspect → MatchArea |

> schema / JSON 示例：`liteScene/reference.md`、`liteScene/examples.md`

## V2 运行约束

- `action="delete"`：删除已有子关；禁止删 `isMain=true` 主关

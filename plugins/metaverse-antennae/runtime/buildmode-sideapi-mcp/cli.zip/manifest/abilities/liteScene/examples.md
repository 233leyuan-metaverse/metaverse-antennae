# liteScene — JSON / DSL 示例

> GUID / levelFileName 均为占位；实际必须先 `inspectLiteSceneLevelList` 回读后替换。

---

## 0. 前置门控（必做）

```json
{
  "tool": "sideapi_inspect",
  "operation": "inspectLiteSceneLevelList"
}
```

期望 `data` 形如：

```json
{
  "currentLevelFileName": "NewLevel",
  "levels": [
    {
      "levelId": "<guid-main>",
      "levelFileName": "NewLevel",
      "displayName": "主关",
      "isMain": true
    },
    {
      "levelId": "<guid-sub>",
      "levelFileName": "<subGuid>",
      "displayName": "副本关",
      "isMain": false
    }
  ]
}
```

---

## 1. EditTime：创建空白子关

> 旧底层 payload 示例已移除。对应 V2 调用：`lite_scene_manage`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

## 2. EditTime：拷贝当前关

> 旧底层 payload 示例已移除。对应 V2 调用：`lite_scene_manage`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

## 3. EditTime：删除子关

> 旧底层 payload 示例已移除。对应 V2 调用：`lite_scene_manage`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

## 4. EditTime：编辑态切关（SideAPI 已阻断）

> 语义工具 `lite_scene_manage` 只接受 `create` / `delete`；编辑态切关不属于 AI 可执行操作。
> 请用户在编辑器关卡管理 UI 切关；玩法内传送用下方运行态 Jump* / MatchArea。

---

## 5. 运行态：互动后传送指定玩家

> `owner=system`；`args` 按 rawParams 全放：`levelFileName`, `targetEntity`, `bRoomPublic`。
> Interactive 点击事件玩家通常为 `interactPlayer`（index=1）。

```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "<交互物>" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_jumpPlayerSubLevel_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "Interactive.showButtonClickDelegate",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "interactPlayer", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "jump_player_1",
        "type": "ability.call",
        "abilityId": "instruction.__80024/__1482/JumpPlayerToSubLevelInstruction",
        "owner": { "type": "system" },
        "args": [
          { "type": "literal", "valueType": "String", "value": "<from inspect levelFileName>" },
          { "type": "event.arg", "argId": "interactPlayer" },
          { "type": "literal", "valueType": "Boolean", "value": true }
        ]
      }
    ]
  }
}
```

## 6. 运行态：传送所有玩家

```json
{
  "nodeId": "jump_all_1",
  "type": "ability.call",
  "abilityId": "instruction.__80024/__1482/JumpAllPlayersToSubLevelInstruction",
  "owner": { "type": "system" },
  "args": [
    { "type": "literal", "valueType": "String", "value": "<from inspect levelFileName>" },
    { "type": "literal", "valueType": "Boolean", "value": true }
  ]
}
```

## 7. 运行态：当前关分支（推荐 GetCurrent + control.if）

```json
{
  "nodeId": "if_current_level_1",
  "type": "control.if",
  "condition": {
    "type": "compare",
    "operator": "==",
    "left": {
      "type": "ability.call",
      "abilityId": "instruction.__80024/__1482/GetCurrentLiteSceneLevelInstruction",
      "owner": { "type": "system" },
      "args": []
    },
    "right": {
      "type": "literal",
      "valueType": "String",
      "value": "<from inspect levelFileName>"
    }
  },
  "then": [
    {
      "nodeId": "debug_on_level_1",
      "type": "ability.call",
      "abilityId": "instruction.__80074/__80075/DebugLog",
      "owner": { "type": "system" },
      "args": [
        { "type": "literal", "valueType": "String", "value": "已在目标关" }
      ]
    }
  ],
  "else": []
}
```

> `ConditionCurrentLiteSceneLevelInstruction` 已在 blockly-dsl Contract 声明登记（abilityId=`instruction.__80174/ConditionCurrentLiteSceneLevelInstruction`）；嵌套子指令场景优先用上方 GetCurrent + `control.if`，避免 nest 形态歧义。

---

## 8. MatchArea：两人匹配跳到主关

> 主关 `levelFileName` 以 inspect 为准（示例用 `NewLevel`）。
> ❌ 禁止只创建正方体改名；❌ 禁止 lookup_mechanism 传送门 / touchDetector 瞬移冒充。

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_create_object`, `scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

前置：`sideapi_inspect(operation="inspectLiteSceneLevelList")`，把 `value` 换成回读的主关 `levelFileName`（`isMain=true` 那条）。

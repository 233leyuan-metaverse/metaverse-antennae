# Water 水体能力

能力名：`WaterVolumeAbility`。用于湖泊、海洋、河流、泳池等水域的浮力、物理、水波、颜色、透明度与水下渲染。

## 关键约束

1. 水体使用预制资源 `asset_id="643652"`；普通装饰水面模型不具备游泳、浮力和水波逻辑。
2. 该资源已预挂 `WaterVolumeAbility`，不需要 `scene_set_ability`。
3. `transparency` 为 0 时完全透明、1 时完全不透明。
4. 浮力对象还需启用 `model.physicsEnabled` 与 `model.gravityEnabled`。
5. 切换 preset 会覆盖其他水体参数，因此先设置 preset，再写颜色、透明度和波浪参数。
6. preset 使用 Tool Schema 证明的数字字符串，不使用枚举显示名。

## 工作流

1. 用 `scene_create_object(asset_id="643652", ...)` 创建水体，或 inspect 定位已有水体。
2. 读取对象详情确认 `WaterVolumeAbility` 已存在。
3. 使用 `scene_configure_ability` 配置 preset、尺寸、颜色、透明度、浮力、摩擦、水波与水下渲染；字段和范围只取当前 Tool Schema。
4. 进出水检测可组合 `touchDetector`，水花组合 `effect`，浮力物体组合 `model`。
5. 新的运行时响应逻辑转 `custom-component`，不使用已排除的 Blockly 工作流。

## 验真

用 `inspectPropertyValues` 核对所有水体属性，用对象详情检查真实尺寸、位置和能力；再提醒用户进入运行态验证游泳、浮力、水下渲染及进出水行为。

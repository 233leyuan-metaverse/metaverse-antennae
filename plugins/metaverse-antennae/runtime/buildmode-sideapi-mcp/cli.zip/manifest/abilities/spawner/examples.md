# spawner — V2 示例

> 参数必须按当前 Tool Schema；示例 ID 是占位符，执行时替换为真实资源 ID。

## 每秒刷新一个怪物

```text
mechanism_create_spawner(
  name="每秒刷怪器",
  carrier_asset_id="<真实载体资源ID>",
  monster_asset_id="<真实怪物presetAssetId>",
  x=0, y=0, z=0,
  spawn_x=0, spawn_y=0, spawn_z=100,
  interval_seconds=1,
  max_alive=10,
  max_total_spawns=100,
  auto_start=true
)
```

执行后 inspect 核对宿主对象、怪物资源、间隔、生成点和两个数量上限。不要拆成挂能力、加槽和写属性请求。

## 玩家进入区域后开始刷怪

创建刷怪器时传 `auto_start=false`。随后在触发区的 `touchDetector.onEnter` 上用 `sideapi_blockly_compile` 绑定运行态逻辑，将目标刷怪器的 `ObjectSpawnerAbility.spawnCommand` 设置为 Contract reference 声明的继续生成枚举。

## 全部怪物消灭后发奖励

在刷怪器的 `ObjectSpawnerAbility.showOnAllObjectsDestroyed` 上用 `sideapi_blockly_compile` 绑定奖励逻辑。事件参数、DSL 节点和指令 ID 从 `spawner/reference.md` 与 `blockly-dsl/reference.md` 获取。

## 自定义战斗怪物

先按角色资源流程创建可复用怪物，配置生命、阵营和死亡事件，inspect 得到真实 `presetAssetId`；再把它作为 `monster_asset_id` 传给 `mechanism_create_spawner`。原始模型 ID、场景对象 ID 或 AI 描述 ID 都不能代替怪物预设。

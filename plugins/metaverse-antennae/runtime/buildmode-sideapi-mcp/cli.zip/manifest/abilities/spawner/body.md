---
name: spawner
nameZh: 刷怪器
abilityNames: [ObjectSpawnerAbility]
keywords: 刷怪,spawner,生成器,刷新,波次,刷怪点,刷新间隔,怪物生成,mechanism_create_spawner
depends: [blockly-dsl, prefabNodeEdit]
description: |
  创建固定点刷怪器并配置怪物资源、刷新位置、间隔、数量和自动启动。
  标准创建统一走 mechanism_create_spawner；运行态启停和事件逻辑走 Blockly DSL。
---

# Spawner 刷怪器

## 标准流程

1. 先取得真实怪物预设 ID。可复用自定义怪物必须先完成角色资源流程并通过 inspect 得到 `presetAssetId`；模型 GUID、场景对象 ID 都不能代替怪物预设。
2. 取得真实载体资源 ID。它只决定刷怪器在场景中的宿主外观。
3. 调用：

```text
mechanism_create_spawner(
  name,
  carrier_asset_id,
  monster_asset_id,
  x, y, z,
  interval_seconds,
  max_alive?,
  max_total_spawns?,
  auto_start?,
  spawn_x?, spawn_y?, spawn_z?
)
```

4. 工具内部负责创建宿主、挂载能力、建立位置槽和对象槽、写入属性、回读和失败清理。AI 不拆成底层步骤。
5. 写后核对结构化 readback：刷怪器对象 ID、`monster_asset_id`、间隔、数量上限和生成点。

## 参数语义

- `x/y/z`：刷怪器宿主位置。
- `spawn_x/spawn_y/spawn_z`：怪物实际生成位置；三者必须同时提供。省略时使用宿主位置。
- `interval_seconds`：每次生成间隔，最小 0.1 秒。
- `max_alive`：同时存活上限，默认 10，编辑器上限 20。
- `max_total_spawns`：本轮最多生成数量，默认 10。
- `auto_start`：是否进入运行态后自动开始。

“每秒刷新一个怪物”的默认解释是 `interval_seconds=1`，单对象槽每个间隔生成一个；不要虚构 `countPerCycle`。

## 运行态逻辑

- 启动、暂停、继续、重置等运行态行为通过 `sideapi_blockly_compile` 写入 `ObjectSpawnerAbility.spawnCommand` 或调用 Contract reference 中对应指令。
- 全部生成物被销毁后的逻辑绑定 `ObjectSpawnerAbility.showOnAllObjectsDestroyed`。
- 怪物死亡奖励、掉落、UI 提示属于怪物预设的事件脚本，不应塞进刷怪器创建参数。

## 长尾能力

当前公开 `mechanism_create_spawner` 覆盖单载体、单怪物、固定生成点。区域随机、多位置、多怪物槽和复杂波次若未出现在当前 Tool Schema 中，必须报告“当前 V2 语义工具尚未覆盖”，不得回退为手写适配器参数。扩展时应先在 Contract 增加语义字段，再由 Application Service 编译到底层步骤。

## 完成门禁

- 资源 ID 必须真实且类型正确。
- 工具失败或返回 partial 时先 inspect，避免重复创建宿主。
- 只有 readback 同时证明宿主、能力、对象槽、位置槽和关键配置存在时才报告完成。
- 测试阶段可以使用已确认的本地资源 GUID；正式环境仍通过 `search_asset` 或用户提供的真实资源取得 GUID。

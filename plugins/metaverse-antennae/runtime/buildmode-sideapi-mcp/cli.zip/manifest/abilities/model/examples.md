# model — JSON 指令示例

> 配合 `model/body.md` 主文件使用。所有示例中的 GUID 为占位符，实际使用时需替换为真实资源 GUID。

---

## EditTime 示例（编辑态直接赋值）

### 设置模型资源
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 设置颜色和透明度
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 启用物理模拟
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 配置碰撞属性
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 设置物理材质（低摩擦冰面）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 替换材质
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。
> `model.materialInfo.{index}.slotMaterialID` 仅编辑态可改；实际 JSON 路径用具体插槽下标替换 `{index}`。材质 GUID 必须通过 `ResourceSelectTools.getMaterialAssets()` 查询，不能猜测。

---

## Runtime 示例（积木 blockly DSL）

<!-- 2026-07-10 17:46:00 调整；原因：按 Ability showInCommand / showInProperty 规则同步事件路径与前置条件。 -->
> DSL 结构与规则见 `blockly-dsl/body.md`；`eventPath` 与 `dsl.event.arguments` 来自 `model/reference.md`。事件参数槽：`model.onTouch` / `model.onTouchEnd` = `0:ownerEntity:self:Entity`、`1:hitEntity:other:Entity`。`model.onTouch` 需先在编辑态设置 `model.collisionEnabled=true` + `model.canTouch=true`。GUID 为占位符，需替换为真实 `assetId`。

### 碰撞时播放音效（model.onTouch）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "trigger_box_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onTouchSound_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "model.onTouch",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "hitEntity", "name": "other", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "play_touch_sound_1",
        "type": "ability.call",
        "abilityId": "instruction.__80055/__80106/Play2DSoundInstruction",
        "owner": { "type": "system" },
        "args": [
          { "type": "asset.ref", "assetId": "碰撞音效GUID" },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Boolean", "value": true },
          { "type": "event.arg", "argId": "hitEntity" }
        ]
      }
    ]
  }
}
```
> `_playInClient=true` 时 `_entity` 须为玩家，此处传撞过来的对象 `hitEntity`（index 1，玩法中通常为玩家）。

### 碰撞时播放特效（model.onTouch）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "impact_zone_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onTouchEffect_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "model.onTouch",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "hitEntity", "name": "other", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "play_impact_effect_1",
        "type": "ability.call",
        "abilityId": "instruction.__80059/__687/PlayEffectOnGameObjectInstruction",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "args": [
          { "type": "enum.value", "value": "0" },
          { "type": "asset.ref", "assetId": "碰撞特效GUID" },
          { "type": "literal", "valueType": "Number", "value": 2 },
          { "type": "literal", "valueType": "Vector", "value": [0, 0, 0] },
          { "type": "literal", "valueType": "Rotation", "value": [0, 0, 0] },
          { "type": "literal", "valueType": "Vector", "value": [1, 1, 1] },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Color", "value": [255, 255, 255, 1] },
          { "type": "literal", "valueType": "Color", "value": [255, 255, 255, 1] }
        ]
      }
    ]
  }
}
```

### 碰撞结束时播放音效（压力板 · model.onTouchEnd）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "pressure_plate_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onTouchEndSound_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "model.onTouchEnd",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "hitEntity", "name": "other", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "play_leave_sound_1",
        "type": "ability.call",
        "abilityId": "instruction.__80055/__80106/Play2DSoundInstruction",
        "owner": { "type": "system" },
        "args": [
          { "type": "asset.ref", "assetId": "离开音效GUID" },
          { "type": "literal", "valueType": "Number", "value": 0.8 },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Number", "value": 1 },
          { "type": "literal", "valueType": "Boolean", "value": true },
          { "type": "event.arg", "argId": "hitEntity" }
        ]
      }
    ]
  }
}
```

---

## 取舍说明

`model.staticMeshAsset` 的运行态 `property.set` 能力由 `showInCommand=true` 确认，但 asset 类型 value 的 DSL 写法以 `blockly-dsl/reference.md` 为准；未确认前不提供运行态换模型示例。

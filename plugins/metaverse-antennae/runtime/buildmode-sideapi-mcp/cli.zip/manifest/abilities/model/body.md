---
name: model
nameZh: 模型物理
abilityNames: [model]
keywords: 物理,碰撞,摩擦,弹性,重力,密度,材质,透明度,颜色,physics,collision,推箱子,滚球,冰面,玻璃,隐形,阴影,穿模,可推动,物理解谜,撞上触发,碰到触发,onTouch,碰撞事件
depends: []
description: |
  model 能力：物理模拟（重力/质量/密度/摩擦力）、碰撞系统（碰撞检测/碰撞事件）、外观控制（颜色/透明度/材质/阴影）。
  适用: 可推动箱子、冰面滑行、半透明玻璃、碰撞触发音效特效（玩家撞上实体对象时触发）、替换材质纹理、隐形墙。
  ⚠️ 玩家撞上有实体的对象时触发逻辑 → 用 model.onTouch；玩家进入无形检测区域触发逻辑 → 用 touchDetector.onEnter。
  常见组合: combat(伤害源) + interactive(交互按钮) + effect(碰撞特效)。
---

# Model 模型与物理系统

能力名: `model`
组件: `ModelComponent`(ownerComponent:0) + `ModelCollisionComponent`(ownerComponent:1)

## 关键约束 ⭐ (源自前端 Model.ts + ModelCollisionComponent.ts 验证)

1. **先挂载再设属性**: 修改 `model.*` 前必须 `scene_set_ability` 挂载 model
2. **物理前置**: 启用物理(`physicsEnabled`)前必须先开阻挡(`collisionEnabled=true`)，setter 会自动强制开启
3. **材质 GUID 必须查询**: `model.materialInfo.{index}.slotMaterialID` 必须通过 `ResourceSelectTools.getMaterialAssets()` 获取，禁止猜测
4. **Color vs materialInfo**: `model.Color` 只改颜色叠加；`model.materialInfo` 替换或调整插槽材质（纹理+光照+金属度）
5. **颜色优先专用工具**：改模型颜色调用 `scene_set_color(target, color)`，`color` 使用工具 Schema 接受的颜色字符串；不要写 `model.Color` 底层包装器。
6. **model 不负责缩放**: 不存在 `model.Scale` / `model.scale` 路径；对象大小、高度、越来越高、向上拉伸都用 `preciseEdit.scale`，且高度轴是 Z，不是 Y
7. **物理属性可见性链**: mass 仅 massMode=ConstantMass(1) 时可见；density 仅 massMode=Density(0) 时可见；moveDamping/gravityEnabled 需 physicsEnabled=true
8. **摩擦力默认值**: friction 默认 0.3（非 0），DEFAULT_COLLISION_ENABLED=true，DEFAULT_PHYSICS_ENABLED=false
9. **ModelCollision 是内部组件，不是可补挂能力**: 客户端 `ModelCollision.ts` 已 `discard: true`；碰撞/物理仍通过 `model.*` 路径操作 `ModelCollisionComponent`

## 属性速查

> 完整属性表见 `model/reference.md` 各能力节 `### 属性`。

## 可绑定事件（供 blockly 使用）

> 事件路径与参数槽: `model/reference.md` → `## 事件（Blockly 参数槽）`。

> 模型/物理运行态指令（含 `ImpactInstruction` owner 接线）: `blockly-dsl/reference.md` →「积木所支持指令列表」→ `### 指令·移动变换与朝向`。

## EditTime vs Runtime 决策

| 场景 | 模式 | 说明 |
|------|------|------|
| 设置模型/颜色/透明度 | EditTime | 创建时直接赋值 |
| 替换材质(`model.materialInfo`) | EditTime | `showInCommand=false`，仅编辑态 |
| 投射阴影 | → blockly-dsl 积木 | 运行态改值走 blockly `property.set`（shadow） |
| 碰撞/物理/摩擦力 | EditTime+Runtime | 编辑态 scene_configure_ability 设初值；运行态改值走 blockly `property.set` |
| 碰撞事件绑定(onTouch) | → blockly-dsl 积木 | `event.eventPath="model.onTouch"` |
| 运行时物理控制 | → blockly-dsl 积木 | 运行态物理控制（冲量等）用 blockly 积木 |

> 运行态/编辑态可改状态以 `model/reference.md` 的 `可指令` / `可编辑` 列为准。

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| 物理解谜（推箱子/滚球） | model + preciseEdit |
| 碰撞触发陷阱（撞上实体触发伤害）| model（onTouch 事件）+ combat(damage) |
| 区域进入触发陷阱（走进范围触发）| touchDetector(onEnter 事件）+ combat(damage) |
| 半透明玻璃/隐形墙 | model(modelOpacity/collision) — 属性路径: `model.modelOpacity` |
| 碰撞计分/传送 | model + effect + playerstart |
| 物理+运动组合 | model + basemove |

## V2 运行约束

- model.staticMeshAsset must be a static-mesh asset guid from a fresh resource inspect, not an invented id.
- model.onTouch collision events require model.collisionEnabled=true and model.canTouch=true.
- materialInfo (贴图/材质参数) is edit-time only (showInCommand=false) and uses model.materialInfo.{index}.* paths — not exposed as a runtime property command here.
- materialInfo is edit-time only (showInCommand=false); apply via edit-time property writes, not runtime property commands.
- Replace {index} with the material slot index, e.g. model.materialInfo.0.slotMaterialID.
- slotMaterialID / slotTextureID must be asset guids from a fresh resource inspect, not invented ids.

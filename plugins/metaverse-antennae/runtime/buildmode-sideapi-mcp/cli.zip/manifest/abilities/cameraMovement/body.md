---
name: cameraMovement
nameZh: 相机运镜
abilityNames: [TrackAbilty]
keywords: 运镜,相机轨迹,摄像机轨迹,轨道相机,过场动画,镜头运动,相机路径,相机运动,轨迹摄像机,CameraMovement,TrackAbilty,PlayCameraMovement,运镜动画,过场镜头,镜头切换
depends: []
description: |
  相机/视角/镜头/运镜/过场动画/场景巡游 → 必须选此技能。TrackAbilty：沿轨迹点序列平滑移动相机。
  适用: 过场动画、剧情展示、关卡预览、场景巡游等需要相机沿固定路径运动的场景。
  常见组合: playerstart（游戏开始自动触发）、touchDetector（进入区域触发）、interactive（交互触发）等；运镜指令 PlayCameraMovementInstruction/StopCameraMovementInstruction 可挂在任意对象事件上。
---

# cameraMovement 相机运镜系统

能力名: `TrackAbilty`
组件: `CameraMovementComponent`(ownerComponent:0) + `TrackComponent`(ownerComponent:1)
支持对象: 所有非道具类对象（EEntityTag.TAG_All ^ TAG_Items）

## 核心逻辑说明

为目标对象挂载 `TrackAbilty` 能力后，通过 `trackPointInfoList` 配置一组相机轨迹点，每个轨迹点包含位置/旋转/缩放变换、到达该点的运动时长（`durationTime`）及到达后等待时间（`await`）。配置完成后，在触发源对象的事件上用 `blockly-dsl` 积木调用 `PlayCameraMovementInstruction`，运行时即可触发相机沿轨迹点序列平滑移动；`StopCameraMovementInstruction` 用于提前中止运镜。

> 轨迹点、完成/中断事件绑定均为编辑态配置；运行态只通过 Blockly 指令控制开始/停止，不动态改 `TrackAbilty.*` 属性。

## 关键约束 ⭐

1. **先挂载再设属性**: 设置 `TrackAbilty.*` 属性前，必须先 `scene_set_ability` 挂载 `TrackAbilty`
2. **运行态不可改属性**: `TrackAbilty.*` 属性均为编辑态配置，不支持运行态 `property.set`。
3. **编辑态可配置**: `trackPointInfoList`、`onPlayCameraMovementComplete`、`onPlayCameraMovementInterrupt` 可在编辑态通过 `scene_configure_ability` 写入
4. **积木绑在触发源对象事件上**: `PlayCameraMovementInstruction` / `StopCameraMovementInstruction` 是运行态指令，用积木绑在触发源对象（PlayerStart、touchDetector、interactive 等）的事件上；开始指令的 `entity` 参数指向挂 `TrackAbilty` 的运镜对象
5. **transform 格式**: 每个轨迹点的 `transform` 使用 `_Transform` 类型，value 格式为 `"pos|rot|scale"`（管道分隔三段，与 `templates` skill 的 `_Transform` 约定一致）
6. **轨迹点顺序**: `trackPointInfoList` 按索引顺序依次经过，`{index}` 从 0 开始
7. **durationTime 单位为秒**: 取值范围 `[0, 99999999]`，为相机从上一点移动到当前点的时长
8. **await 单位为秒**: 取值范围 `[0, 99999999]`，为相机到达当前点后停留等待的时长

## 属性速查

> 完整属性表见 `cameraMovement/reference.md` 各能力节 `### 属性`。

## 运行态指令（供 blockly 使用）

> 运镜 Blockly 指令（`PlayCameraMovementInstruction` / `StopCameraMovementInstruction`）: `blockly-dsl/reference.md` →「积木所支持指令列表」→ `### 指令·相机运镜滤镜`。
> 玩家相机参数（FOV/弹簧臂/切换/角度限制等）见同文件 `### 指令·相机运镜滤镜`。

## EditTime vs Runtime 决策

| 场景 | 模式 | 说明 |
|------|------|------|
| 挂载 TrackAbilty 能力 | EditTime | `scene_set_ability` |
| 添加并配置轨迹点 | EditTime | `scene_add_track_point(target, settings)`（每次一个，最多 15 个） |
| 绑定完成/中断事件回调 | EditTime | 事件路径用 `TrackAbilty.onPlayCameraMovementComplete` / `TrackAbilty.onPlayCameraMovementInterrupt` |
| 触发运镜开始 | Runtime Blockly | 在触发源对象事件中调用 `PlayCameraMovementInstruction` |
| 停止运镜 | Runtime Blockly | 在触发源对象事件中调用 `StopCameraMovementInstruction` |
| 运行时动态修改轨迹点 | 不支持 | `showInCommand=false` |

## 标准工作流程

```
1. 对每个轨迹点调用 `scene_add_track_point(target, settings={transform, durationTime, await})`；工具幂等挂载能力并回读新索引
2. inspect 核对轨迹点顺序和配置
3. 按需用 Blockly 绑定 `TrackAbilty.onPlayCameraMovementComplete` / `onPlayCameraMovementInterrupt`
4. 在触发源事件中用 Blockly 调用 `PlayCameraMovementInstruction`
```

## 常见组合

| 场景 | 需要的 skills | 推荐触发事件 |
|------|-------------|-------------|
| 游戏开始自动播放过场运镜 | cameraMovement + playerstart | `playerStart.onGameStart`（player index=0） |
| 玩家进入区域触发运镜 | cameraMovement + touchDetector | `touchDetector.onEnter`（player index=1） |
| 玩家与物体交互触发运镜 | cameraMovement + interactive | `interactive.onInteract`（index 按实际确认） |
| 运镜结束后执行下一步逻辑 | cameraMovement | `TrackAbilty.onPlayCameraMovementComplete` 绑后续指令 |

生成指令前先读属性表: `cameraMovement/reference.md`
> JSON 指令示例: `cameraMovement/examples.md`

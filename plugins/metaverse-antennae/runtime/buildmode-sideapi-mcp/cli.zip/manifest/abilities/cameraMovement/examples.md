# cameraMovement — JSON 指令示例

> 配合 `cameraMovement/body.md` 和 `cameraMovement/reference.md` 使用。示例中的 `gameObjectId` / GUID 都是占位符，实际使用时替换为真实值。

---

## EditTime 最小片段

### 挂载能力并配置两点运镜
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 绑定运镜完成事件
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## Runtime Blockly 最小片段

### 游戏开始播放运镜
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "player_start_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onGameStart_playCamera_<rand8hex>" },
    "event": {
      "eventPath": "playerStart.onGameStart",
      "arguments": [
        { "index": 0, "argId": "playerEntity", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "play_camera_1",
        "type": "ability.call",
        "abilityId": "instruction.__80028/PlayCameraMovementInstruction",
        "owner": { "type": "event.arg", "argId": "playerEntity" },
        "args": [
          { "type": "entity.scene", "gameObjectId": "track_camera_01" }
        ]
      }
    ]
  }
}
```

### 进入触发区停止运镜
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "trigger_zone_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onEnter_stopCamera_<rand8hex>" },
    "event": {
      "eventPath": "touchDetector.onEnter",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "owner", "type": "Entity" },
        { "index": 1, "argId": "triggerEntity", "name": "entered", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "stop_camera_1",
        "type": "ability.call",
        "abilityId": "instruction.__80028/StopCameraMovementInstruction",
        "owner": { "type": "event.arg", "argId": "triggerEntity" },
        "args": [
          { "type": "literal", "valueType": "Number", "value": 1 }
        ]
      }
    ]
  }
}
```

### 运镜完成后显示 UI
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "track_camera_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onComplete_showUi_<rand8hex>" },
    "event": {
      "eventPath": "TrackAbilty.onPlayCameraMovementComplete",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "playerEntity", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "show_ui_1",
        "type": "ability.call",
        "abilityId": "instruction.__80074/__81212/ScreenUICanvasVisibleInstruction",
        "owner": { "type": "event.arg", "argId": "playerEntity" },
        "args": [
          { "type": "literal", "valueType": "String", "value": "canvas_guid" },
          { "type": "literal", "valueType": "Boolean", "value": true },
          { "type": "literal", "valueType": "Boolean", "value": false },
          { "type": "literal", "valueType": "Number", "value": 0 }
        ]
      }
    ]
  }
}
```

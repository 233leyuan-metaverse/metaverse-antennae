---
name: touchDetector
nameZh: 触发区域
abilityNames: [touchDetector]
keywords: 触发,触碰,进入区域,离开区域,触发器,检测区域,碰撞,touchdetector,传送门,陷阱,检查点,自动门
validContext: [sceneObject]
depends: [basic]
dependsReason: "factionDetectTypes 按阵营过滤进入对象，阵营 ID 来自 BasicAbility.faction；不设阵营则触发器对所有对象生效或行为不可预测"
description: |
  touchDetector 能力：触发区域检测，进入/离开事件，碰撞触发，阵营过滤。
  适用: 传送门、陷阱触发、检查点、自动门、区域警报、剧情触发、收集物拾取、范围伤害光环。
  常见组合: preciseEdit(瞬移传送) + damage(伤害区) + effect(区域特效) + interactive(互动) + buffEdit(范围Buff光环)。
  ⚠️ validContext=sceneObject: 属性只对有具体 gameObjectId 的活体场景对象有效，预设节点编辑会话不适用。
---

# TouchDetector 触发区域系统

能力名: `touchDetector`
组件: `TouchDetectorComponent`(ownerComponent:0)

## 关键约束 ⭐ (源自前端 TouchDetectorComponent.ts 验证)

1. **触发器必须关闭自身阻碍** ⚠️: 物体作为触发器使用时，**必须同步设置 `model.collisionEnabled = false`**，关闭碰撞阻挡，让角色/玩家可以穿过，否则触发区域会阻碍移动。
2. **先挂载再设属性**: 修改 `touchDetector.*` 前必须 `scene_set_ability` 挂载 touchDetector
3. **⚠️ 阵营查询强制**: 设置 `factionDetectTypes` 前**必须调用【阵营系统查询工具】**获取阵营列表，语义匹配 `campName_lang` 后填入序号，**禁止凭经验猜测**
4. **阵营单选**: `factionDetectTypes` 仅接受单个序号字符串，不支持多选或数组
5. **阵营特殊值**: `"-1"` = 所有阵营(不含无阵营)，`"-2"` = 所有阵营(含无阵营)，默认 `"-1"`
6. **enable 控制**: `touchDetector.enable=false` 时不触发任何进入/离开事件，默认 `true`
7. **属性状态以Contract 声明为准**: 属性路径、可编辑/可运行态修改状态、枚举值与事件路径见 `touchDetector/reference.md`，正文不重复维护属性表。
8. **球形尺寸**: `sphereRadius` / `sphereDiameter` 是组件实现细节，不是 AI Contract 声明路径；配置球形触发区时写 `touchDetector.transform` 或运行态写 `touchDetector.scale`。
9. **⚠️ transform.scale 是倍数，不是世界坐标尺寸**: `touchDetector.transform` 的 scale 分量（`_Transform` value 第三段）是**相对于模型自身尺寸的缩放倍数**，`1,1,1` = 与模型等大，`2,2,2` = 各轴放大一倍。**禁止填入世界坐标数值**（如 `600,300,600`），典型合理范围为 `1~5`，超过 `10` 视为错误。
10. **⚠️ 贴地伤害区（熔岩/毒雾/陷阱）**: `touchDetector.transform` 本地 position 应接近 `(0,0,0)`，**禁止 z 大偏移（如 50）**；须与模型贴地范围对齐。模型若为竖板 mesh，须先 `transform.rotation` 躺平（常见 `rotation.x=90`），再 scale 宽/深；**禁止** `rotation=0` 且仅 `scale.y=0.3` 当「薄层熔岩池」。

## 可绑定事件（供 blockly 使用）

| 事件路径 | 触发时机 | GetValueFromArgs index |
|---------|---------|----------------------|
| `touchDetector.onEnter` | 物体进入区域时 | 0=自身, 1=进入对象 |
| `touchDetector.onLeave` | 物体离开区域时 | 0=自身, 1=离开对象 |

> 参数槽明细: `touchDetector/reference.md` → `## 事件（Blockly 参数槽）`（`0:ownerEntity`，`1:triggerEntity`）。
> ArgumentSlot 定义: `Void("")`(index 0), `Entity("自身")`(index 1), `Entity("进入/离开对象")`(index 2)。
> 新资源清理：创建机关/触发区预设时，`touchDetector/reference.md` 的 onEnter/onLeave 只作为候选事件表；必须按 `prefabNodeEdit` 通用协议 inspect 实际 `InstructionList` 后清空并验证，禁止只凭路径猜测完成。

运行态响应逻辑统一用 `blockly-dsl` 生成积木 DSL。常见用法:
- 进入 → **瞬移传送**（见下方「传送门」专节）、触发陷阱、开门、播放特效
- 离开 → 关门、停止音效、解除状态

## 传送门 ⭐（瞬移，不是走过去）

**语义**：玩家进入触发区后**立刻改坐标**，不寻路、不 `CharacterMoveToInstruction`（那是「走到某点」，中间没路会卡住，不是传送）。

| 路线 | 何时用 | 做法 |
|------|--------|------|
| **A. 官方资产（首选）** | 标准传送门外观+音效+特效 | `scene_create_object(asset_id=710545)`，只改预置 `EntityPropertyInstruction` 目标坐标（见 asset-presets skill） |
| **B. Blockly 自建** | 自定义外观+touchDetector.onEnter | `sideapi_blockly_compile`：`property.set` → `preciseEdit.positionRef`，`owner=triggerEntity`（进入者），值为目标 Vector |
| **C. sideapi_blockly_compile 自建** | 不用 Blockly、纯 JSON 绑 onEnter | `EntityPropertyInstruction`：`target`=进入者(GetValueFromArgs index=1)，`_pathList=["preciseEdit","position"]`，`_targetValue`=目标坐标 |

**禁止**：臆造 `SetEntityPositionInstruction`；禁止用 `CharacterMoveToInstruction` 当传送门；禁止 `EntityPropertyInstruction` 写在 Blockly DSL 里（走 property.set 或 sideapi_blockly_compile）。

**前置**：进入者须能改位置（玩家/角色通常已有 preciseEdit）；`model.collisionEnabled=false`；`factionDetectTypes` 含玩家阵营。

## 形状选择

- **Cube**: 最常用，区域/房间/通道，边界清晰（默认形状）
- **Sphere**: 点状区域，检查点/爆炸范围，均匀辐射
- **Capsule**: 通道/走廊，线性区域
- **Cone**: 视野/扇形，方向性强

## 缩放参考

> ⚠️ 以下 scale 均为**相对于模型自身尺寸的倍数**（multiplier），不是世界坐标单位。`1` = 与模型等大，`2` = 各轴放大一倍。

| 场景 | 建议 scale（倍数） |
|------|-----------|
| 贴身触发（拾取、互动按钮） | 1 ~ 1.2 |
| 安全感知（自动门、检查点、出口门框） | 1.2 ~ 2 |
| 大范围感应（警报、区域事件） | 2 ~ 5 |

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| 传送门 | **优先** asset-presets(710545)；自建 → touchDetector + preciseEdit（Blockly positionRef 或 EntityPropertyInstruction） |
| 陷阱伤害区 | touchDetector + damage + combat |
| 机关/陷阱/伤害区场景直建（无资源语义） | touchDetector + damage/buffEdit/blockly-dsl → case **`create_mechanism_in_scene`** |
| 角色/NPC/怪物场景直建（无资源语义） | character/combat/basic → case **`create_character_in_scene`** |
| 可复用预设资源（含刷怪器引用） | touchDetector + buffEdit/damage/blockly-dsl → case **`create_mechanism_preset`** |
| 自动门 | touchDetector + basemove |
| 区域特效 | touchDetector + effect |
| 检查点/收集物 | touchDetector + interactive |
| 区域警报 | touchDetector + effect + audio |

> JSON 指令示例: `touchDetector/examples.md`

## V2 运行约束

- Add/prove touchDetector before writing touchDetector.* properties.
- Use shape as a string enum: Cube/方盒, Sphere/球体, Capsule/胶囊, or Cone/锥体. Do not send numeric shape values.
- Use factionDetectTypes as one string value: allCombatFactions -> -1, allIncludingNoFaction -> -2, or one inspect-backed faction id.
- For pass-through trigger zones, pair with model.collisionEnabled=false when the object has model collision and the intent is not a solid blocker.
- touchDetector.transform.scale and touchDetector.scale are relative multipliers; values above 10 are suspicious for normal trigger zones.

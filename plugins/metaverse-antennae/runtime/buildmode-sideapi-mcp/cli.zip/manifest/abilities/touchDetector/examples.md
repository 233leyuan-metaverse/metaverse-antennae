# touchDetector — JSON 指令示例

> 配合 `touchDetector/body.md` 与 `touchDetector/reference.md` 使用。示例中的 GUID 和阵营序号必须替换为查询结果。

---

## EditTime 示例

### 创建触发区域并配置范围
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_create_object`, `scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 运行时显示触发边界
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## Runtime 示例（blockly DSL）

> 目标对象需已挂载 `touchDetector`。事件参数槽见 `touchDetector/reference.md`。

### 进入触发区域时禁用自身
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "trigger_zone_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_disableOnEnter_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "touchDetector.onEnter",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "owner", "type": "Entity" },
        { "index": 1, "argId": "triggerEntity", "name": "entered", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "disable_detector_1",
        "type": "property.set",
        "abilityId": "touchDetector.enable",
        "operator": "=",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "value": { "type": "literal", "valueType": "Boolean", "value": false }
      }
    ]
  }
}
```

### 进入触发区域时瞬移进入者
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "portal_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_teleportOnEnter_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "touchDetector.onEnter",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "owner", "type": "Entity" },
        { "index": 1, "argId": "triggerEntity", "name": "entered", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "teleport_entered_1",
        "type": "property.set",
        "abilityId": "preciseEdit.positionRef",
        "operator": "=",
        "owner": { "type": "event.arg", "argId": "triggerEntity" },
        "value": { "type": "literal", "valueType": "Vector", "value": [5000, 0, 200] }
      }
    ]
  }
}
```

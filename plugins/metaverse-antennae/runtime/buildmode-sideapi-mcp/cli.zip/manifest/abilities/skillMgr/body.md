---
name: skillMgr
nameZh: 技能管理
abilityNames: [SkillMgrAbility]
keywords: 技能槽,技能列表,添加技能,skillmgr,技能配置,SkillMgrAbility,技能管理,删除技能,修改技能,NPC技能,怪物技能,技能释放,buff,击退,无敌
depends: []
description: |
  SkillMgrAbility 是挂载到对象上的能力组件：管理对象的技能槽，从已有技能预设库中装备/卸下技能，并支持技能自动释放与技能事件绑定。
  只引用已有技能预设，不负责创建、删除或修改技能预设库中的技能。
  适用: NPC/怪物技能装备、技能槽配置、Buff/击退/伤害/无敌等运行时指令。
  常见组合: character(角色AI) + combat(战斗属性) + weapon(武器配合技能) + basic(阵营)。
---

# SkillMgr 技能能力组件

能力组件: `SkillMgrAbility`
组件: `SkillMgrComponent`(ownerComponent:0)
支持挂载: Character + Model + CustomModel

## 关键约束

1. **先挂载再设属性**: 修改 `SkillMgrAbility.*` 前必须 `scene_set_ability` 挂载
2. **职责仅限对象技能槽**: SkillMgr 只能为对象装备、卸下、配置和释放已有技能预设；不得创建、删除或修改技能预设库中的技能
3. **必须使用已有技能预设**: 严禁自行通过属性/事件拼接技能功能。唯一合法路径：`getAllSkillList` 工具查询 → 匹配 uuid → 装备到对象的技能槽
4. **新增技能槽统一入口**: 使用 `scene_add_skill_slot(target, settings)`；`settings.abilityAsset` 必须是真实技能资源 ID
5. **索引由服务发现**: Application Service 读取当前槽位状态并回传新索引，AI 不猜索引
6. **技能槽配置仅编辑态修改**: `SkillMgrAbility.builderSkillSlotConfig.{index}.*` 的运行态状态以 `reference.md` 为准，当前均不可运行态 `property.set`
7. **技能事件只做绑定入口**: 事件路径使用 `SkillMgrAbility.builderSkillSlotConfig.{index}.onSkillActivated` / `onSkillCdCompleted`，响应逻辑交给 `blockly-dsl`

## 属性速查

> 完整属性表见 `skillMgr/reference.md` 各能力节 `### 属性`。

## 可绑定事件（供 blockly 使用）

> 事件路径与参数槽: `skillMgr/reference.md` → `## 事件（Blockly 参数槽）`。

## 关联运行时指令

> 技能管理运行态指令: `blockly-dsl/reference.md` →「积木所支持指令列表」→ `### 指令·战斗技能BUFF与生命`。

## 使用流程

| 场景 | 模式 | 说明 |
|------|------|------|
| 添加技能槽并配置自动释放 | EditTime | 查询真实技能 UUID 后调用 `scene_add_skill_slot(target, settings)` |
| 技能事件绑定 | blockly-dsl | `event.eventPath` 绑定 `SkillMgrAbility.builderSkillSlotConfig.{index}.onSkillActivated` / `onSkillCdCompleted` |
| 运行时释放/装备/卸下已有技能 | blockly-dsl | 用 `ActivateAbilityInstruction` / `CancelAbilityInstruction` / `GiveAbilityInstruction` / `RemoveAbilityInstruction`；不改变技能预设库 |
| 运行时 Buff/伤害/击退 | blockly-dsl | Buff 归 `buffEdit`，伤害归 `combat`，击退归 `weapon` |

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| NPC 自动释放技能 | skillMgr + character + basic(阵营) |
| Boss 多技能 | skillMgr + character + combat + weapon + basic |
| 技能触发 Buff | skillMgr + buffEdit |
| 击杀后释放技能 | skillMgr + combat(onDeath事件) |

> 属性/技能槽配置见`skillMgr/reference.md`；运行态释放/给予/移除技能等示例见 `blockly-dsl/examples.md`。

## V2 运行约束

- Use the public builderSkillSlotConfig path in agent-facing plans.
- Do not write the whole builderSkillSlotConfig or _builderSkillSlotConfig array directly.
- Write only indexes proven by inspectSlotState currentCount/indexes.
- For abilityAsset, cite a skillAsset:* ref from inspectSkillAssets/getAllSkillList; do not invent UUIDs.
- 技能资源创建/复制/保存属于独立的 `skill_create` / `skill_copy` / `skill_save` 工具。

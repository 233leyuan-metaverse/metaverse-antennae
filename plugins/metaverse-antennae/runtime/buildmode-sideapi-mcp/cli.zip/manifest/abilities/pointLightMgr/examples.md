# PointLightMgr — JSON 指令示例

> 配合 `pointLightMgr/body.md` 使用。示例中的 `gameObjectId` 为占位符，实际使用时替换为目标对象 ID。

---

## EditTime 示例（编辑态直接赋值）

### 添加点光源
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 修改点光源强度
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

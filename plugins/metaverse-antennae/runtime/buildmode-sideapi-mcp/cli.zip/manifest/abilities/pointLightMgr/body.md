---
name: PointLightMgr
nameZh: 点光源
abilityNames: [PointLightMgrAbility]
keywords: 添加点光源、删除点光源、修改点光源  关灯、开灯、点灯、发亮的灯光等等,PointLightMgr,PointLightMgrAbility
depends: []
description: |
  PointLightMgrAbility 能力：管理对象的点光源（添加/修改/删除点光源）。
  适用: 室内打开、关闭灯光，会发光的装饰品，道具等等。
  常见组合: model(模型) + character(角色)。
---

# PointLightMgr 点光源管理器

能力名: `PointLightMgrAbility`
组件: `PointLightMgrComponent`(ownerComponent:0)
支持挂载: Character + Model + Gear + CustomModel

## 关键约束

1. **统一语义入口**: 新增并配置点光源使用 `scene_add_point_light(target, settings)`；服务负责能力、槽位和回读
2. **点光源索引从 0 开始**: 工具从 readback 发现新索引，AI 不猜索引
3. **属性仅编辑态配置**: `PointLightMgrAbility.pointLightConfigs` 的 `showInCommand=false`，运行态不要用指令修改点光源配置
4. **最多 3 个点光源**: 超过上限会被组件拒绝

## 属性速查

> 完整属性表见 `pointLightMgr/reference.md` 各能力节 `### 属性`。

## V2 运行约束

- pointLightConfigs 在 Ability 内 showInCommand=false，列表与子属性均为编辑态，不可运行态指令修改。
- {index} 替换为真实点光源下标；_pointLightConfigs 是组件内部读回字段，不作为写属性路径。

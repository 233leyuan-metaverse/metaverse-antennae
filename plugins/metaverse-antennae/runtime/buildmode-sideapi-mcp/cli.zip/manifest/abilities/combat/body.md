---
name: combat
nameZh: 战斗能力
abilityNames: [health]
keywords: 生命,血量,hp,health,死亡,受伤,复活,掉落,击杀,无敌,回血,血条,飘字,加血,扣血
validContext: [sceneObject]
depends: [basic]
dependsReason: "health 伤害结算依赖阵营；未设置 BasicAbility.faction 时，伤害系统可能跳过扣血"
description: |
  health：生命值、血条、受伤/死亡/复活事件、运行态加血扣血。
  适用：设置初始 HP/MaxHP、显示头顶血条、受伤反馈、死亡掉落、复活恢复。
  不适用：攻击、防御、蓝量、经验等 RPG 属性；攻击力请走 weapon 的 damage。
---

# combat 战斗属性

能力：`health`
组件：`HealthAttributeComponent`（ownerComponent: 0）+ `HeadUIComponent`（ownerComponent: 1）+ `AbilitySystemComponent`

## 必守规则

1. 先 `scene_set_ability` 挂载 `health`，再写 `health.*`。
2. 初始血量必须编辑态写两条，顺序固定：
   - 先 `health.dynamicPropertyInfo.maxHp`
   - 再 `health.dynamicPropertyInfo.hp`
3. `health.dynamicPropertyInfo.hp` 必须小于等于 `health.dynamicPropertyInfo.maxHp`；只写 maxHp 不写 hp 时，运行时当前血量仍可能保持默认值。
4. `health.hp` / `health.maxHP` 是运行态属性，不要用 `scene_configure_ability` 做编辑态初始化。
5. `hpVisibleMode` / `hpBarSize` / `damageFloatEffect` 在 Ability 描述里 `showInCommand=true, showInProperty=false`，按运行态 Blockly 属性处理。
6. `health` 不承载 RPG 攻防或多资源属性：`attack` / `defense` / `maxMP` / `manaPoint` 等不要写到 `health.*`。攻击力走 `HotWeaponItemAbility.damage` 或 `MeleeWeaponItemAbility.damage`。
7. 事件只使用 `health.onBeenHurt` / `health.onDeath` / `health.onReborn`，不要猜 `onHurt` / `onDead` / `onRevive`。

## 属性分层

| 场景 | 使用路径 / 指令 |
|------|----------------|
| 初始化最大生命 | `scene_configure_ability` 写 `health.dynamicPropertyInfo.maxHp` |
| 初始化当前生命 | `scene_configure_ability` 写 `health.dynamicPropertyInfo.hp` |
| 运行态设置生命 | Blockly `property.set health.hp` 或 `OverrideAttributeInstruction` |
| 运行态增减生命 | `ModifyAttributeInstruction` 或 `AF_health_addHp` / `AF_health_removeHp` |
| 运行态设置 MaxHP | Blockly `property.set health.maxHP` 或 `OverrideAttributeInstruction` |
| 血条显示 | Blockly `property.set health.hpVisibleMode` |
| 血条大小 | Blockly `property.set health.hpBarSize` |
| 飘字显示 | Blockly `property.set health.damageFloatEffect` |
| 无敌 | `InvincibleEntity` 或运行态 `health.invincibleDuration` |
| 复活 / 立即死亡 | `RespawnEntity` / `KillEntity` |

完整属性、枚举、函数和事件参数见 `combat/reference.md`。

## 初始化模板

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

## 运行态事件

| 事件 | 用途 | 参数 |
|------|------|------|
| `health.onBeenHurt` | 受伤反馈、反击、受击音效 | `self`, `attacker` |
| `health.onDeath` | 死亡掉落、击杀奖励、销毁自身 | `self`, `killer` |
| `health.onReborn` | 复活后恢复状态 | `self` |

事件脚本统一用 `blockly-dsl`，示例见 `combat/examples.md`。

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| 可攻击怪物 | `combat` + `basic(阵营)` + `character` + `weapon` |
| Boss 死亡掉落 | `combat(onDeath)` + `blockly-dsl` + `prefabNodeEdit` / `item` |
| 触发区伤害 | `combat` + `touchDetector` + `blockly-dsl(ApplyDamageInstruction)` |
| 生命药剂 | `combat` + `item` + `blockly-dsl(AF_health_addHp 或 ModifyAttributeInstruction)` |
| 头顶血条 | `combat(hpVisibleMode/hpBarSize)` + `basic(名称/阵营)` |

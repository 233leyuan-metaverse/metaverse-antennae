# combat — JSON 示例

示例中的 `gameObjectId`、资源 GUID 和 workspace 随机串都是占位符，实际使用时必须替换为真实值。

## 编辑态：挂 health 并初始化血量

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

先写 `maxHp`，再写 `hp`；`hp` 不要大于 `maxHp`。

## 编辑态：初始化恢复与无敌

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

## 运行态：显示血条

```json
{
  "nodeId": "show_hp_bar_1",
  "type": "property.set",
  "abilityId": "health.hpVisibleMode",
  "owner": { "type": "entity.scene", "gameObjectId": "enemy_01" },
  "operator": "=",
  "value": { "type": "literal", "valueType": "String", "value": "Always" }
}
```

血条大小同样用 `property.set health.hpBarSize`，例如值 `100`。

## 运行态：回血

```json
{
  "nodeId": "add_hp_1",
  "type": "ability.call",
  "abilityId": "instruction.__80079/__80567/AF_health_addHp",
  "owner": { "type": "entity.scene", "gameObjectId": "player_01" },
  "args": [
    { "type": "literal", "valueType": "Number", "value": 50 }
  ]
}
```

也可以用 `ModifyAttributeInstruction` 增减 `HealthAttributeComponent.hp`。

## 运行态：造成伤害

```json
{
  "nodeId": "apply_damage_1",
  "type": "ability.call",
  "abilityId": "instruction.__80001/__80015/ApplyDamageInstruction",
  "owner": { "type": "event.arg", "argId": "attackerEntity" },
  "args": [
    { "type": "event.arg", "argId": "targetEntity" },
    { "type": "literal", "valueType": "Number", "value": 100 },
    { "type": "literal", "valueType": "Number", "value": 0 },
    { "type": "literal", "valueType": "Number", "value": 1 },
    { "type": "event.arg", "argId": "attackerEntity" }
  ]
}
```

`targetEntity` 需要有 `health` / `AbilitySystemComponent`。直接扣血可用 `AF_health_removeHp`，需要触发完整伤害链时用 `ApplyDamageInstruction`。

## 事件：死亡时掉落并销毁自身

```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "enemy_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_health_onDeath_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "health.onDeath",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "killerEntity", "name": "killer", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "spawn_drop_1",
        "type": "ability.call",
        "abilityId": "instruction.__80059/__80059/SpawnEntityInstruction",
        "owner": { "type": "system" },
        "args": [
          { "type": "asset.ref", "assetId": "掉落物资源GUID" },
          {
            "type": "property.get",
            "abilityId": "preciseEdit.positionRef",
            "owner": { "type": "event.arg", "argId": "ownerEntity" }
          },
          { "type": "literal", "valueType": "Rotation", "value": [0, 0, 0] },
          { "type": "literal", "valueType": "Vector", "value": [1, 1, 1] }
        ]
      },
      {
        "nodeId": "destroy_self_1",
        "type": "ability.call",
        "abilityId": "instruction.__80059/__80059/DestroyEntity",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "args": []
      }
    ]
  }
}
```

击杀奖励发给 `killerEntity`，不要发给死亡的 `ownerEntity`。

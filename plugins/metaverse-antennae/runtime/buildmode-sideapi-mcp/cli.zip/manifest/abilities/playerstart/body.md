---
name: playerstart
nameZh: 玩家控制器
abilityNames: [playerStart]
keywords: 玩家控制器,出生点,出生,玩家,用户角色,player,相机,视角,第一人称,第三人称,横板,camera,playerstart,视场角,fov,语音,游戏开始,玩家离开,准备离开,onGameStart,onPlayerPrepareExit,背包能力,InventoryAbility
depends: []
description: |
  玩家控制器能力（旧称"出生点"）：挂载 `playerStart` 的对象就是玩家控制器。
  适用: 定位玩家控制器、配置玩家相机模板、语音捕获、游戏开始/语音/离开事件。
  禁止添加背包能力 `InventoryAbility`（运行态自动注入；用户坚持也禁止；禁止替代方案）。
  常见组合: combat(玩家血量) + weapon(玩家武器) + ui(HUD) + character(角色外观)。
---

# PlayerStart 玩家控制器

能力名: `playerStart`
组件: `PlayerStartComponent`(0) + `DescriptComponent`(1) + `CameraComponent`(2) + `UserCustomPropertyComponent`(3)

## 核心概念

**玩家控制器 = 挂载了 `playerStart` 能力的场景对象**，在场景中也显示为"出生点"。
"出生点"、"玩家"、"玩家角色"、"用户角色"、"player" 等语义通常都指这个对象或运行态继承出来的玩家角色。

查找玩家控制器时，调用 `getAllBasicInfo`，优先找已带 `playerStart` 能力、`assetId` 以 `$000` 开头、或 `entityName` 为"出生点"的对象。不要新建普通模型来充当玩家控制器。

该对象上的部分能力会在运行时继承给玩家角色。例如给玩家配置武器、血量、外观时，通常是在玩家控制器对象上挂对应能力并写对应能力属性。

**禁止添加背包能力**：`InventoryAbility` 由引擎在玩家进入运行态时自动注入。禁止 `scene_set_ability(abilityName="InventoryAbility")`。用户坚持要添加也禁止。禁止任何替代方案（自造 userData、挂其它 Ability 等）。

## 关键约束

1. **先挂载再设属性**：写 `playerStart.*` 前必须先用 `scene_set_ability` 挂载 `playerStart`。
2. **只能挂在 NPC / 出生点资源上**：`playerStart` 不适合挂普通几何体或基础模型。
3. **相机模板优先**：先设置 `playerStart.cameraPreset`，只有 `Custom` 模式才配置 `playerStart.cameraPresetRule.*`。
4. **相机细项仅编辑态**：`playerStart.cameraPresetRule.*` 的 `showInCommand=false`，运行态相机调整走 `blockly-dsl` 的 `Camera*` 指令。
5. **运行态改玩家属性要用事件玩家**：Blockly 中需要玩家实体时，用事件参数 `event.arg playerEntity`，不要写死编辑态 `gameObjectId`。
6. **语音事件前置条件**：使用 `playerStart.audioCaptureEvent` 前先开启 `playerStart.audioCapture`。
7. **禁止添加背包能力**：见上文；坚持禁止；禁止替代方案。

## 属性、事件与函数

> 完整属性表见 `playerstart/reference.md` 各能力节 `### 属性`。
> Builder Functions: `playerstart/reference.md` → `## Functions (全部 Runtime, showInCommand=true)`。
> 事件路径与参数槽: `playerstart/reference.md` → `## 事件（Blockly 参数槽）`。
> 玩家域 Blockly 指令（`AF_playerStart_getUserId`、`AF_playerStart_getUserConsumptionAmount`）: `blockly-dsl/reference.md` →「积木所支持指令列表」→ `### 指令·通用`。
> 玩家相机控制（`Camera*` 系列）: 同文件 `### 指令·相机运镜滤镜`。

## EditTime vs Runtime 决策

| 场景 | 模式 | 说明 |
|------|------|------|
| 给玩家控制器对象配置能力/属性 | EditTime | 用已有出生点的 gameObjectId，不要新建对象 |
| 设外观来源 | EditTime | `playerStart.sourceFrom` |
| 设视角模板 | EditTime / Runtime | `playerStart.cameraPreset` 可编辑、可指令 |
| 配置 Custom 相机参数 | EditTime | `playerStart.cameraPresetRule.*` |
| 运行时调整相机 | Runtime Blockly | 调 `CameraSwitchInstruction` / `CameraFovInstruction` / `CameraSpringArmLengthInstruction` 等 |
| 语音分贝响应 | Runtime Blockly | 绑定 `playerStart.audioCaptureEvent`，读取 `volumeValue` |

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| 第三人称 RPG | playerstart + combat + weapon + character |
| 第一人称射击 | playerstart + weapon(热武器) + combat |
| 横板跑酷 | playerstart + touchDetector + interactive |
| 多人语音游戏 | playerstart(audioCapture) + ui |
| 运镜演出 | playerstart + interactive(触发运镜) |

> JSON 指令示例: `playerstart/examples.md`

## V2 运行约束

- cameraPresetRule.* 仅在 cameraPreset=Custom 时生效，且为编辑态；运行态相机调整用 blockly-dsl 的 Camera* 指令。

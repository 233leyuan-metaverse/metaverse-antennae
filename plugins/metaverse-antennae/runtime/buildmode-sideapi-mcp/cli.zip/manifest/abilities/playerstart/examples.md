# playerstart — JSON 指令示例

> 示例中的 `gameObjectId` 是占位符，实际使用时替换为 `getAllBasicInfo` 查到的玩家控制器对象 ID。玩家控制器通常是已有出生点；不要新建普通模型充当玩家。

## EditTime 最小片段

### 设置第三人称相机
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 设置 Custom 相机参数
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 开启语音捕获
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 给玩家装备武器
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

## Runtime Blockly 片段

### 游戏开始时切换第三人称
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "已有出生点的gameObjectId" },
  "dsl": {
    "workspace": { "name": "Blockly_PlayerStart_OnGameStart_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "playerStart.onGameStart",
      "arguments": [
        { "index": 0, "argId": "playerEntity", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "type": "property.set",
        "owner": { "type": "event.arg", "argId": "playerEntity" },
        "abilityId": "playerStart.cameraPreset",
        "value": "ThirdPerson"
      }
    ]
  }
}
```

### 语音分贝事件响应
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "已有出生点的gameObjectId" },
  "dsl": {
    "workspace": { "name": "Blockly_PlayerStart_AudioCapture_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "playerStart.audioCaptureEvent",
      "arguments": [
        { "index": 0, "argId": "playerEntity", "name": "player", "type": "Entity" },
        { "index": 1, "argId": "volumeValue", "name": "volume", "type": "Number" }
      ]
    },
    "statements": [
      {
        "type": "ability.call",
        "owner": { "type": "event.arg", "argId": "playerEntity" },
        "abilityId": "instruction.__80119/__80120/AF_playerStart_getUserId",
        "args": []
      }
    ]
  }
}
```

### 获取玩家该游戏消费
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "已有出生点的gameObjectId" },
  "dsl": {
    "workspace": { "name": "Blockly_PlayerStart_GetUserConsumption_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "playerStart.onGameStart",
      "arguments": [
        { "index": 0, "argId": "playerEntity", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "type": "ability.call",
        "owner": { "type": "event.arg", "argId": "playerEntity" },
        "abilityId": "instruction.__80119/__80120/AF_playerStart_getUserConsumptionAmount",
        "args": []
      }
    ]
  }
}
```

---
# customData — JSON 指令示例

> 配合 customData/SKILL.md 主文件使用。GUID 为占位符，实际使用时需替换。

---

## 完整流程示例（必须按此顺序，三步缺一不可）

> 场景：给模型对象添加 `flash_count` 数字属性，并在运行时将其设为 0。

### Step 2a — 挂载 CustomAbility 能力载体
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### Step 2b — 创建自定义属性字段
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

> ⚠️ Step 2a 和 Step 2b 使用对应 V2 数据工具顺序完成并逐步 readback；运行态读写走 `blockly-dsl`，与编辑态初始化分开。

### Step 3 — 运行态读写（积木 blockly DSL）

<!-- 2026-07-02 14:52:00 调整；原因：对象自定义数据特殊属性接口由 blockly-dsl 维护，触发事件签名来自对应事件所属 skill。 -->
> Step 2a/2b 的 EditTime 创建完成后，运行态读写对象自定义数据一律用 `property.get`（读）/ `property.set`（写），`abilityId = "property.__more/CustomAbility/{属性名}"`，**owner 是拥有该属性的物体**，**不再**用 `SetCustomPropInstruction`。DSL 结构与规则见 `blockly-dsl/body.md`。
> **`{属性名}`（下例中的 `flash_count`）为占位，须照抄项目真实字段（`inspectSceneObjectDetail` 中 `CustomAbility.properties[].path`），不可臆造；且该属性必须已由 builder 在该对象上创建，blockly 不能自建属性。**

#### 对象创建时重置计数（写对象自定义数据 = 0）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "085681E6" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_reset_flash_count_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "BasicAbility.onCreateEvent",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "reset_flash_count_1",
        "type": "property.set",
        "abilityId": "property.__more/CustomAbility/flash_count",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "operator": "=",
        "value": { "type": "literal", "valueType": "Number", "value": 0 }
      }
    ]
  }
}
```
> `flash_count` 为占位，须照抄项目真实字段，不可臆造。`owner` 是拥有该属性的物体（本事件的 `self`，即 `085681E6`）。

#### 被碰撞时计数 +1 并判断（读 + 写对象自定义数据）
```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "085681E6" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_flash_count_add_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "model.onTouch",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "hitEntity", "name": "other", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "flash_count_add_1",
        "type": "property.set",
        "abilityId": "property.__more/CustomAbility/flash_count",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "operator": "+=",
        "value": { "type": "literal", "valueType": "Number", "value": 1 }
      },
      {
        "nodeId": "check_flash_count_1",
        "type": "control.if",
        "condition": {
          "type": "compare",
          "operator": ">=",
          "left": {
            "type": "property.get",
            "abilityId": "property.__more/CustomAbility/flash_count",
            "owner": { "type": "event.arg", "argId": "ownerEntity" }
          },
          "right": { "type": "literal", "valueType": "Number", "value": 3 }
        },
        "then": [
          {
            "nodeId": "flash_count_full_tip_1",
            "type": "ability.call",
            "abilityId": "instruction.__80074/__80075/TipsInstruction",
            "owner": { "type": "system" },
            "args": [
              { "type": "event.arg", "argId": "hitEntity" },
              { "type": "literal", "valueType": "String", "value": "闪光已集满！" }
            ]
          }
        ]
      }
    ]
  }
}
```
> `flash_count` 为占位，须照抄项目真实字段，不可臆造。读写两端 `abilityId`/`owner` 完全一致，仅 `type` 不同（`property.get` / `property.set`）；对象自定义数据的 `owner` 恒为拥有该属性的物体（`self`），不是玩家。

---

## EditTime 示例（编辑态）

### 对象数据 — 添加一般类型属性
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 对象数据 — 添加特殊类型（枚举）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 对象数据 — 添加数组（无嵌套）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 对象数据 — 添加多级嵌套数组（Array→Array→Map→Array→NumberInput）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 对象数据 — 添加字典（无嵌套）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 对象数据 — 添加多级嵌套字典（Map→Array→Map→一般类型）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 对象数据 — 删除属性
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 对象数据 — 修改属性值
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## 自定义事件模板示例

> 完整流程：`scene_set_ability` 挂 CustomAbility → `custom_event_manage` 创建事件模板并绑定对象 → readback；不得拼底层批次。

### Step 1 — 挂载 CustomAbility 能力载体（若对象已有可跳过）
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### Step 2 — 创建自定义事件模板（无参数）
> 旧底层 payload 示例已移除。对应 V2 调用：`custom_event_manage`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### Step 2 — 创建事件模板并通过 Changed 追加参数（两步）

先创建模板：
> 旧底层 payload 示例已移除。对应 V2 调用：`custom_event_manage`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

再用 `custom_event_manage(action="update", settings={"paramList": ...})` 追加参数：
> 旧底层 payload 示例已移除。对应 V2 调用：`custom_event_manage`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### Step 3 — 将事件绑定到对象
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

### 删除事件模板参数（DeleteParam）
> 旧底层 payload 示例已移除。对应 V2 调用：`custom_event_manage`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 修改事件模板名称/描述
> 旧底层 payload 示例已移除。对应 V2 调用：`custom_event_manage`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 移除对象的事件绑定
> 旧底层 payload 示例已移除。对应 V2 调用：`scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

### 删除事件模板
> 旧底层 payload 示例已移除。对应 V2 调用：`custom_event_manage`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

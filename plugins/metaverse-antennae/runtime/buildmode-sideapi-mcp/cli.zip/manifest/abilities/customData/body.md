---
name: customData
nameZh: 对象自定义数据
abilityNames: [CustomAbility, data]
keywords: customdata,自定义属性,属性定义,对象数据,对象属性,自定义事件,广播事件,场景对象,模型属性,角色属性,出生点属性,property.set,property.get,自定义事件模板,custom_event_manage,AICustomEventscene_configure_ability,事件模板,绑定事件,给对象添加事件
depends: []
description: |
  对象自定义数据：场景内各对象（模型/角色/出生点等）各自独立拥有的自定义属性(CustomAbility) + 广播事件系统。每个对象的自定义数据互不影响，不持久化存储，属于编辑态属性配置。
  例如：出生点A和出生点B可以有完全不同的自定义数据，从不同出生点出生的玩家继承到的属性因此不同。
  适用: 添加/删除/修改场景对象的自定义属性、创建/删除/修改自定义事件模板、给对象绑定/解绑自定义事件、广播自定义事件、运行时修改对象属性。
  排除: 运行时玩家的统一配置字段（玩家变量、认领状态、金币数、击杀数、排行榜等跨会话记录）不属于此范围，必须改用 userData；全游戏/全房间共享一份的全局变量（全局开关/全服公告/世界进度）必须改用 gameData；内置货币(金币/派对币)是现成能力；等级/经验用 LevelAbility。
  常见组合: combat(战斗属性) + ui(数据显示) + interactive(触发修改)。
---

# CustomData 对象自定义数据系统

能力名: `CustomAbility`
组件: `CustomEventComponent`(ownerComponent:0) + `CustomPropertyComponent`(ownerComponent:1)

## 关键约束 ⭐

1. **⚠️ 运行态前置门控（在积木里 `property.set` / `property.get` 读写对象自定义属性前，三步走不可跳过）**：
   - **Step 1 — 查能力与属性**: 调用 `sideapi_inspect(operation="inspectSceneObjectDetail", request_json={"gameObjectIds":["<gameObjectId>"]})`，检查 `data.objects[].abilities[].name` 列表中是否含 `"CustomAbility"`，以及该能力的 `properties` 中是否已有目标属性路径
   - **Step 2 — 不存在则先 EditTime 创建（两步缺一不可）**：
     - **Step 2a** — 若 `abilities[].name` 中没有 `"CustomAbility"`：必须先输出 `scene_set_ability`（`abilityName:"CustomAbility"`）挂载能力载体
     - **Step 2b** — 若目标属性不在 `properties` 中：输出 `object_data_manage(action="create")` 添加具体属性字段
     - ❌ **禁止跳过 Step 2a 直接输出 Step 2b**——缺少载体时属性创建和后续读写全部失效
     - ❌ **禁止假设 `CustomAbility` 已存在**——`abilities[].name` 里没有就是不存在
   - **Step 3 — 运行态读写后置**: 积木 `property.set` / `property.get`（`target`=场景对象）只能在 EditTime 创建步骤全部完成之后使用
   - **⚠️ 在 Buff 生命周期（`onBuffBegin` / `OnBuffPeriod` / `onBuffEnd`）中使用时**：先独立调用 `scene_set_ability` 和 `object_data_manage` 完成对象数据初始化并 readback，再调用 `sideapi_blockly_compile` 绑定生命周期钩子；两阶段不得颠倒。
2. **目标不可混用**: 对象自定义属性运行态在积木用 `property.set`/`property.get`（`target`=场景对象）；运行时玩家配置字段不属于此范围
   - ❌ 玩家数据不属于本 skill；应使用 `user_data_manage`
   - ❌ 禁止在本 skill 下输出 `AIGameCustomscene_configure_ability`；该类型属于 `gameData`（全游戏共享字段，2026-08-03 接入）
   - ❌ 禁止用 `customPropertyName` 表示玩家数据字段；玩家数据必须用 `uuid` / `displayName`
   - ✅ 任务出现“玩家变量 / 玩家属性 / 认领状态 / has_xxx / UserPropertyInstruction / UserCustomPropertyTypeGet*”时，停止使用本 skill，改加载 `userData`
   - ✅ 任务出现“游戏数据 / 全局变量 / 全服共享 / 全局开关 / 全服公告”（全场一份的值）时，停止使用本 skill，改加载 `gameData`
3. **等级/经验排除**: 用 `LevelAbility` 内置能力
4. **输出顺序（严格）**: ① `scene_set_ability`（CustomAbility）→ ② `object_data_manage(action="create")`→ ③ 运行态积木 `property.set`/`property.get`

## 属性速查

> 对象自定义属性无固定 abilityRegistry 表；创建/改字段见 `customData/reference.md` → `## EditTime 指令 schema` 与 `## 对象数据操作码 (EAICustomPropertyOperationType)`。

## EditTime 指令 schema

> 事件模板 / 对象绑定 / 自定义属性 Tool Schema 与字段表: `customData/reference.md` → `## EditTime 指令 schema`。
> JSON 示例: `customData/examples.md`。

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| 对象自定义属性+触发修改 | customData + interactive/touchDetector |
| 游戏状态管理（对象侧） | customData + interactive |
| 给对象挂自定义事件（可监听/广播） | customData（事件模板 + 绑定） |

> JSON 指令示例: `customData/examples.md`

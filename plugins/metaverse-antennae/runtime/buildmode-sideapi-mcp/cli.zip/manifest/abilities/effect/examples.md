# effect — JSON 指令示例

> 配合 `effect/body.md` 与 `effect/reference.md` 使用。PlayEffect 的 assetId：**先** `search_asset(kind=effect)`；失败时用 case 模板或 `inspectAssetCatalog(kind=effect)` 浏览。禁止 `kind=model` 结果填 PlayEffect。

---

## EffectAbility：编辑态初始化特效对象

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

---

## effectObj：编辑态添加并配置特效挂件

> 旧底层 payload 示例已移除。对应 V2 调用：`scene_set_ability`, `scene_configure_ability`。
> 参数只按当前工具 JSON Schema 生成，并在写入后执行 readback。

> `{index}` 从 0 开始；新增前读取已有挂件数量或槽位状态，新槽位写入对应 index。

---

## Runtime：运行态开关特效对象

> 运行态只改 `EffectAbility.playState`；`owner` 必须是已挂载 `EffectAbility` 的特效对象实体。

```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "effect_object_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_toggleEffect_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "Interactive.showButtonClickDelegate",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "self", "type": "Entity" },
        { "index": 1, "argId": "interactPlayer", "name": "player", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "set_playstate_play_1",
        "type": "property.set",
        "abilityId": "EffectAbility.playState",
        "operator": "=",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "value": { "type": "literal", "valueType": "String", "value": "Play" }
      }
    ]
  }
}
```

> 停止时把 `value` 改为 `"Stop"`。

## Runtime：进入触发区时播放一次性特效

<!-- 2026-07-17 18:00:00 slotType SSOT：本节 PlayEffect 示例内 enum.value 即 canonical 默认模板；规则见上方 effect/body.md § PlayEffectOnGameObjectInstruction -->

```json
{
  "version": "blockly-dsl-v1",
  "target": { "type": "scene", "gameObjectId": "trigger_01" },
  "replaceExisting": false,
  "dsl": {
    "version": "blockly-dsl-v1",
    "workspace": { "name": "Blockly_onEnterEffect_<rand8hex>_upgrade" },
    "event": {
      "eventPath": "touchDetector.onEnter",
      "arguments": [
        { "index": 0, "argId": "ownerEntity", "name": "owner", "type": "Entity" },
        { "index": 1, "argId": "triggerEntity", "name": "entered", "type": "Entity" }
      ]
    },
    "statements": [
      {
        "nodeId": "play_enter_effect_1",
        "type": "ability.call",
        "abilityId": "instruction.__80059/__687/PlayEffectOnGameObjectInstruction",
        "owner": { "type": "event.arg", "argId": "ownerEntity" },
        "args": [
          { "type": "enum.value", "value": "0" },
          { "type": "asset.ref", "assetId": "特效资源GUID" },
          { "type": "literal", "valueType": "Number", "value": 2 },
          { "type": "literal", "valueType": "Vector", "value": [0, 0, 0] },
          { "type": "literal", "valueType": "Rotation", "value": [0, 0, 0] },
          { "type": "literal", "valueType": "Vector", "value": [1, 1, 1] }
        ]
      }
    ]
  }
}
```

> 2026-07-17 18:10:00 说明：`assetId` 须为真实 guid（禁止把流程说明写进 JSON 字段）：先 `search_asset(kind=effect)`；`found=true` 用返回 guid；`found=false` 用 case 模板（熔岩见 `117231`，`buffEdit/examples.md`）或报 structured gap。路由 SSOT：`docs/design/search-asset-kind-routing.md`。
>
> 上例对应编辑器真实生成的六参数基础积木。仅当特效资源暴露动态槽位时，才在末尾依次追加透明度、颜色、颜色 01；不要主动补齐。

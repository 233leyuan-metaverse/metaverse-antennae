---
name: effect
nameZh: 特效能力
abilityNames: [EffectAbility, effectObj]
keywords: 特效,粒子,光效,挂载特效,视觉效果,火焰,光环,烟雾,播放特效,停止特效,挂件,pendant
depends: []
description: |
  EffectAbility 能力：对象本身是特效类型时使用，管理场景中特效对象自身的属性（粒子/光效播放控制、颜色/透明度）。
  effectObj 能力：挂件系统，可将特效或自定义外观挂载到对象上（多槽位），适用于"给对象挂一个特效"或"修改挂在对象上的特效属性"。
  语义区分：操作场景特效对象本身 → EffectAbility；给某对象挂特效/改挂件属性 → effectObj。
  适用: 火焰陷阱、光环装饰、烟雾发生器、角色挂件(翅膀/光环/武器装饰)、氛围特效。
  常见组合: touchDetector(区域特效) + combat(战斗特效) + interactive(触发特效)。
---

# Effect 特效系统

## 使用选择

| 意图描述 | 使用能力 |
|---------|---------|
| 场景中有一个特效对象，修改它的颜色/透明度/播放状态 | `EffectAbility` |
| 对象本身是特效类型，需要控制其播放/停止 | `EffectAbility` |
| 给某个对象（角色/道具/场景物件）挂上一个特效 | `effectObj` |
| 修改挂在对象上的特效的颜色/透明度/持续时间 | `effectObj` |
| 角色身上挂载翅膀、光环、武器装饰等挂件 | `effectObj` |

> 核心原则：`EffectAbility` 代表对象本身是特效；`effectObj` 代表对象携带的挂件（挂件可以是特效，也可以是自定义外观模型）。

---

## 关键约束

| 场景 | 入口 | 约束 |
|------|------|------|
| 初始化特效对象 | EditTime | 先 `scene_set_ability` 挂载 `EffectAbility`，再写 `EffectAbility.effectAssetId` / `EffectAbility.playState` 等属性 |
| 运行时开关特效对象 | `blockly-dsl` | 只建议用 `property.set` 修改 `EffectAbility.playState`，值为 `"Play"` 或 `"Stop"` |
| 添加对象挂件特效 | EditTime | `scene_add_effect_slot(target, settings)`，能力、槽位和字段由服务一次完成 |
| 运行时一次性特效 | `blockly-dsl` | 使用 `PlayEffectOnGameObjectInstruction`，不要把它当成 `EffectAbility` 持久属性 |

## 属性与事件

属性路径、枚举和可修改状态以 `effect/reference.md` 为准。运行态事件路径来自触发源 skill，例如 `interactive` 或 `touchDetector`；effect 域本身不提供事件路径。

## PlayEffectOnGameObjectInstruction（运行态 Blockly）

运行态在指定 **Entity** 上播放一次性特效（非持久挂件，非 `EffectAbility` 属性）。设计 SSOT 亦见 `docs/design/play-effect-slottype-default.md`。

### 参数顺序（`ability.call` 的 `args`）

| 序号 | 参数 | DSL 类型 | 说明 |
|:--:|------|----------|------|
| — | `_entity` | `owner` | 播特效的目标实体（如 `event.arg.ownerEntity`、进入者、使用者） |
| 0 | `slotType` | `enum.value` | **`HumanoidSlotType` 枚举值**（见下节） |
| 1 | `_effectId` | `asset.ref` | 须 `search_asset(kind=effect)` 或 case 模板 guid |
| 2 | `_duration` | `literal` Number | 秒 |
| 3 | `_worldPosition` | `literal` Vector | 位置偏移 |
| 4 | `_rotation` | `literal` Rotation | 旋转偏移 |
| 5 | `_scale` | `literal` Vector | 缩放 |
| 6–8 | `_transparency` / `_arg_color` / `_arg_color01` | Number / Color / Color | **可选尾参数**；仅资源积木暴露对应动态槽位时按顺序追加 |

`args[0..5]` 是固定基础参数；合法长度为 **6–9**。不得为未暴露的动态槽位补占位值，也不存在 `arg3`。

### slotType 说明

- **类型**：`mw.HumanoidSlotType` 枚举；Blockly DSL 写 `{ "type": "enum.value", "value": "<枚举值字符串>" }`。
- **默认值**：**`"0"`**（`HumanoidSlotType.Hair`）。未指定插槽时一律用 `"0"`。
- **指定其它插槽**：查下表枚举速查，或对照引擎 `HumanoidSlotType` 定义。
- **SSOT**：`PlayEffectOnGameObjectInstruction` 的 `slotType` **默认值与枚举速查仅在本节维护**；其它 skill / `blockly-dsl` / case 只索引本节，**不重复写默认值数字**。

### slotType 枚举速查（指定插槽时查阅）

| value | 枚举名 | 含义 |
|:-----:|--------|------|
| `"0"` | Hair | **DSL 默认** |
| `"1"` | Head | 头部 |
| `"15"` | LeftHand | 左手 |
| `"16"` | RightHand | 右手 |
| `"23"` | Root | 根节点 |

> `_effectId` 检索规则见下文「常见前置条件」。完整 JSON 见 `effect/examples.md`。

## 常见前置条件

- 特效 assetId 须来自 **`search_asset(kind=effect)`** 或 case/skill 模板；示例 GUID 只是占位。`inspectAssetCatalog(kind=effect)` 可作浏览备选。
- **禁止** `search_asset(kind=model)` 的 guid 用于 `PlayEffectOnGameObjectInstruction`（见 `docs/design/search-asset-kind-routing.md`）。
- `EffectAbility.effectAssetId`、颜色和透明度是编辑态配置，不要在运行态 `property.set` 中修改。
- `effectObj.effectInfos.{index}.*` 是挂件槽位子属性，运行态不可修改；新增挂件统一调用 `scene_add_effect_slot`。
- 挂件 index 从 0 开始；新增前应读取已有挂件数量或槽位状态，避免覆盖旧挂件。

## 常见组合

| 场景 | 需要的 skills |
|------|-------------|
| 火焰/毒气陷阱 | effect + touchDetector + damage |
| Boss 战斗特效 | effect + combat + character |
| 场景氛围装饰 | effect (单独使用) |
| 角色翅膀/光环挂件 | effect(effectObj) + character |
| 传送门光柱 | effect + touchDetector + character |

> JSON 指令示例：`effect/examples.md`

## V2 运行约束

- Use EffectAbility only when the target object itself is an effect object.
- For a one-shot effect on another object, use PlayEffectOnGameObjectInstruction in a runtime event instead of persistent EffectAbility.
- Use playState friendly values playing/播放 -> Play and stopped/停止 -> Stop.
- Use effectAssetId from fresh resource/asset inspect evidence rather than inventing ids.
- Use abilityName effectObj exactly for object-carried effects.
- Do not write the whole effectInfos array directly from an agent plan.
- For a new attachment, call scene_add_effect_slot with Contract-declared settings and verify the returned slot index.
- Use layState friendly values playing/播放 -> 0 and stopped/停止 -> 1.
- Use common slotType labels such as standard, back, leftHand, rightHand, halo, or root instead of bare numbers when possible.

# 向量语义检索方案设计

> 替代现有 `case_retrieval.py` 中基于单字分词 + token 重叠的检索方式，改为向量语义匹配，解决中文同义词/近义词无法匹配的核心痛点。

## 1. 动机

现有 `_score()` 按单字切分中文（`[一-鿿]`），"记分牌"与"计分板"仅"分"字交叠，无法识别同义表达。同时 `_route_*` 预路由规则靠手工正则不断堆叠，不可持续。本方案用向量语义检索替代 token 重叠打分，保留可选的规则加权层。

## 2. 架构概览

```
用户自然语言 → lookup_case(query, kind, state)
                  ↓
           VectorRetriever.search(query, kind)
                  ↓  ① embed(query) → query_vec
                  ↓  ② FAISS 余弦相似度 Top-K
                  ↓  ③ 可选: keywords ×2 加权
                  ↓  ④ 可选: 规则路由修正 (±25)
                  ↓  ⑤ 截断 primary_limit
                  ↓  ⑥ 依赖链预展开（同现有逻辑）
                  ↓
           返回 {"case_context": ..., "matched_cases": [...], "hit_mode": "vector", ...}
```

## 3. 核心类: `VectorRetriever`

### 3.1 生命周期

```python
class VectorRetriever:
    """单例，加载时建索引，常驻内存。"""

    def __init__(self, cases_dir: str, model_name: str = DEFAULT_MODEL):
        self.cases: list[CasePack] = []       # 全部 case 元数据
        self.index: faiss.IndexFlatIP = None  # 内积索引 (≈ 余弦)
        self.model: SentenceTransformer = None
        self._load_cases(cases_dir)
        self._build_index()

    def _load_cases(self, dir: str): ...
    def _build_index(self): ...
    def search(self, query: str, kind: str = "", top_k: int = 5) -> SearchResult: ...
```

- 模块级懒加载单例，首次调用 `lookup_case()` 时初始化，后续复用。
- `_build_index()` 对所有 case 的检索文本做一次 embed → L2 normalize → 写入 FAISS `IndexFlatIP`。

### 3.2 检索文本构建 `_search_text(p) -> str`

保持与现有 `_search_text` 相同的字段拼接策略，但增加**结构化前缀**提升语义区分度：

```python
def _search_text(self, p: CasePack) -> str:
    # 各字段加前缀标签，帮助 embedding 模型理解字段角色
    parts = [
        f"[名称]{p.nameZh}",
        f"[概述]{p.summary}",
        f"[适用场景]{p.whenToUse}",
    ]
    if p.keywords:
        parts.append(f"[关键词]{' '.join(p.keywords)}")
    return " ".join(parts)
```

> 设计权衡：前缀标签是否会干扰语义？中文 embedding 模型（如 bge、text2vec）对自然语言标注有一定鲁棒性；不加标签则各字段混在一起失去结构信号。推荐保留标签。

### 3.3 Embedding 模型选型

| 方案 | 模型 | 维度 | 延迟 (CPU) | 优势 |
|------|------|------|------------|------|
| A（推荐） | `BAAI/bge-small-zh-v1.5` | 512 | ~5ms/条 | 中文 SOTA、轻量、MIT 协议、离线 |
| B | `shibing624/text2vec-base-chinese` | 768 | ~8ms/条 | 中文语义匹配专项优化、离线 |
| C | OpenAI `text-embedding-3-small` | 512 | ~50ms/条 | 语义最强但依赖网络 + 成本 |

**推荐方案 A**：35 个 case + 单次查询，embed 总量极小（init ~18ms，query ~5ms），离线无成本。

依赖安装：

```
pip install sentence-transformers faiss-cpu
```

首次加载会自动下载模型（~100MB），后续从缓存加载。

### 3.4 检索流程 `search(query, kind, top_k)`

```
输入: query="我想做一个计分板", kind="gameplay", top_k=5

1. embed(query) → query_vec (512-dim, L2 normalized)

2. kind 过滤:
   - 如果 kind 非空，在 FAISS 侧用 IDSelector 只搜对应 kind 的子集
   - 实现: 维护 kind → row_indices 映射，构建子索引或用 numpy mask

3. FAISS 检索:
   - index.search(query_vec, top_k) → (scores, indices)
   - 内积等价于余弦相似度 (已 normalize)

4. 可选加分层 (见 §3.5)

5. 返回 SearchResult:
   - primary: list[CasePack]    # top_k 内得分最高的
   - scores: list[float]        # 对应得分
   - hit_mode: "vector" | "vector_keyword" | "vector_rule"
```

### 3.5 可选加分层 (保留规则修正)

向量检索本身已经覆盖语义匹配，但两类场景仍有规则加分的价值：

**a) Keywords 加分（×1.5 ~ ×2.0）**

Keywords 是作者精选命中词，信号价值高。在向量得分基础上，如果 query 与 case.keywords 有精确子串匹配，给该 case 额外 +0.1 ~ +0.15（向量得分归一化到 [0,1] 后）：

```python
def _keyword_bonus(self, query: str, case: CasePack) -> float:
    """精确子串匹配加分，大小写不敏感"""
    bonus = 0.0
    for kw in case.keywords:
        if kw.lower() in query.lower():
            bonus += 0.03  # 每个命中关键词 +0.03
    return min(bonus, 0.15)  # 上限 0.15
```

**b) 路由规则加分（±25 映射为 ±0.25）**

现有 `_route_scene_placement` / `_route_preset_patch` 的规则可以保留为可选插拔层，在向量得分基础上 ±0.25：

```python
def _route_bonus(self, query: str, case_id: str) -> float:
    """规则修正值，映射到 [−0.25, +0.25]"""
    # 保留现有正则规则，但加分值从 ±25 线性映射到 ±0.25
    bonus = _route_scene_placement(query).get(case_id, 0)
    bonus += _route_preset_patch(query).get(case_id, 0)
    return bonus / 100.0  # ±25 → ±0.25
```

> 设计权衡：向量语义理解理论上能覆盖路由规则的大部分场景（如 query 含"武器"自然匹配到 weapon case）。初期可关闭规则层，仅在线上验证后发现特定 badcase 时再开启。规则层作为"补丁"而非"主力"。

### 3.6 Kind 过滤实现

```python
def search(self, query: str, kind: str = "", top_k: int = 5) -> SearchResult:
    query_vec = self._embed(query)

    if kind:
        # 只搜指定 kind 的 case
        mask = np.array([c.kind == kind for c in self.cases])
        if not mask.any():
            return SearchResult([], [], "vector", "no matching kind")
        # 方法1: 子集 IDSelector
        target_ids = np.where(mask)[0].astype(np.int64)
        selector = faiss.IDSelectorArray(target_ids)
        params = faiss.SearchParametersIVF(sel=selector)  # 仅 IVF 索引支持
        # 方法2 (IndexFlat 更简单): 全量搜再 mask
        scores, indices = self.index.search(query_vec, top_k * 3)  # 过度检索
        # mask 掉非目标 kind，取 top_k
        ...

    else:
        scores, indices = self.index.search(query_vec, top_k)
    ...
```

推荐方案：IndexFlat 全量搜再后过滤。35 个 case 的规模，全量内积开销可忽略不计，无需 IVF 的复杂度。

## 4. 接口兼容性

### 4.1 入口函数签名不变

```python
# vector_case_retrieval.py (新文件)

def lookup_case(query: str, kind: str = "", state=None) -> dict:
    """
    语义向量检索 case。

    参数:
        query: 用户自然语言输入，如 "我想做一个计分板"
        kind:  粗筛分类，"" 表示不过滤， "gameplay"/"ui" 等
        state: 保留参数，用于日志/观测，不参与检索逻辑

    返回:
        {
            "case_context": str,       # Markdown 格式的 case 配方正文
            "matched_cases": list[str], # 命中的 case id 列表
            "hit_mode": str,            # "vector" | "vector_keyword" | "vector_rule"
            "scores": list[float],      # [可选] 各 case 的相似度得分，便于调试
            "notes": list[str],         # 检索元信息
        }
    """
    retriever = _get_retriever()  # 懒加载单例
    result = retriever.search(query, kind)

    return {
        "case_context": format_cases_for_injection(result),
        "matched_cases": [p.id for p in result.primary],
        "hit_mode": result.hit_mode,
        "scores": result.scores,
        "notes": _build_notes(query, result),
    }
```

### 4.2 `format_cases_for_injection` 渲染

保持与现有逻辑一致——把 `primary` case 的 `raw` 字段（完整 JSON）渲染为 Markdown steps 骨架，`related_cases` 依赖摘要同理。这部分直接复用。

### 4.3 依赖链预展开

完全沿用现有逻辑：仅展开主包 `related_cases` 中 `feeds_into` / `consumes_output_of` 关系，最多 1 层，总量上限 5 个。这属于后处理，与检索方式无关。

## 5. 文件结构

```
src/apis/cases/
├── case_retrieval.py          # 现有实现（保留，降级兜底）
├── vector_case_retrieval.py   # 新增：向量检索实现
│   ├── VectorRetriever        # 核心检索类
│   ├── lookup_case()          # 入口函数（兼容旧签名）
│   ├── retrieve_cases()       # 核心检索（兼容旧调用方）
│   └── format_cases_for_injection()  # 渲染（复用）
├── case_loader.py             # [可选] CasePack 加载逻辑独立出来
├── case_retrieval.md          # 现有文档（保留）
├── vector_retrieval_design.md # 本文档
└── *.json                     # 35 个 case 文件
```

## 6. 切换策略

### 6.1 灰度开关

在 `agent.py` 的 `executor_tools()` 中通过环境变量或配置决定使用哪个实现：

```python
USE_VECTOR_RETRIEVAL = os.getenv("USE_VECTOR_RETRIEVAL", "0") == "1"

if USE_VECTOR_RETRIEVAL:
    from apis.cases.vector_case_retrieval import lookup_case
else:
    from apis.cases.case_retrieval import lookup_case
```

### 6.2 回退策略

如果向量模型加载失败（如网络不可达、文件损坏），自动降级到 token 重叠方案：

```python
def _get_retriever() -> VectorRetriever:
    global _retriever
    if _retriever is None:
        try:
            _retriever = VectorRetriever(CASES_DIR)
        except Exception as e:
            logger.warning(f"向量检索初始化失败，回退 token 方案: {e}")
            raise FallbackToTokenRetrieval(e)
    return _retriever
```

## 7. 效果预期

| 场景 | 现有 token 方案 | 向量方案 |
|------|----------------|---------|
| "记分板" vs case "交互记分" | 仅"分"匹配，得分低 | 语义相似，高分匹配 |
| "做一个商店" vs case "多商店商品购买" | 靠"商店"匹配 | "做"↔"创建" + "商店"语义对齐 |
| "怪物死后掉落道具" vs case "fanren_inventory_items" | 需预路由强干预 | 语义直接匹配 |
| 35 个 case | 单字切分勉强可用 | 向量检索精准 |

## 8. 性能预估

| 阶段 | 耗时 | 说明 |
|------|------|------|
| 模型加载（首次） | ~2-5s | 下载 + 加载 bge-small-zh，仅一次 |
| 索引构建（首次） | ~0.2s | 35 × 512-dim embed + FAISS index |
| 单次查询 | ~5ms | 1 × embed + FAISS search |
| 内存占用 | ~150MB | 模型 ~100MB + FAISS ~1MB + overhead |

## 9. 待定问题

1. **`state` 参数**：当前文档中未说明 `state` 的具体用途。如果仅用于日志/观测，向量方案无需修改；如果参与了检索逻辑，需进一步对齐。

2. **规则层是否保留**：建议首期关闭 `_route_bonus`，用纯向量检索跑一段时间，收集 badcase 后再决定是否需要规则补丁。

3. **Keywords 加分权重**：`×2` 权重在 token 方案中至关重要（拉开与泛词的差距），但在向量方案中关键词已通过 `_search_text` 参与 embedding，额外加分是否必要需实测验证。

4. **Case 增量更新**：当新增/修改 case JSON 后是否需要重启服务来重建索引？首期建议重启重建，后续可加文件监听热更新。

5. **依赖处理**：`related_cases` 展开是后处理逻辑，向量检索阶段只负责 primary case 匹配，依赖链从 JSON 的 `related_cases` 字段直接读取，无需 embedding。

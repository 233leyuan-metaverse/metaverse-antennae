# 向量语义检索方案 V2

> 用远程 embedding + ES 向量检索替代现有单字分词 + token 重叠的 case 匹配方式。

## 1. 背景

现有 `case_retrieval.py` 的 `lookup_case(query, kind, state)` 核心流程：query → 单字切分 → token 与每个 case 的 search_text 做交集 → 加权打分 → 排序截断。

**痛点**：
- 中文单字切分丢失词组语义，"记分"与"计分"仅"分"交叠
- 同义词/近义词无法匹配
- `_route_*` 预路由规则靠手工正则堆叠，不可持续

## 2. 设计目标

1. 用向量语义相似度替代 token 重叠打分
2. 接口签名 `lookup_case(query, kind, state)` 不变
3. 现有调用方（`agent.py executor_tools()`）无需改动
4. 有降级兜底能力
5. kind 过滤、依赖链展开、Markdown 渲染等周边逻辑保持不变

## 3. 组件选型

| 组件 | 选型 | 说明 |
|------|------|------|
| Embedding 模型 | `doubao-embedding-vision-250615` | 远程 API，2048 维 |
| 向量存储 | Elasticsearch | `dense_vector` + kNN，同步存元数据 |
| Embedding 客户端 | 自封装 `DoubaoEmbeddingClient` | HTTP + Bearer Token，支持重试 |

## 4. Embedding 客户端

封装一个 `DoubaoEmbeddingClient`，提供同步 (`embed_sync`) 和异步 (`embed`) 两个批量 embedding 方法。配置项从环境变量注入（API 地址 + 认证 Token），单次批量上限 32 条，异常时指数退避重试 3 次。

调用流程：POST 请求携带 `{model, input: [...]}` + Bearer Token，响应为 `{data: [{embedding: [2048 floats]}, ...]}`。

性能预算：

| 阶段 | 耗时 | 备注 |
|------|------|------|
| 单条 query embed | ~100-200ms | 远程网络延迟 |
| 批量 35 条 embed | ~500-1000ms | 索引构建时，仅一次 |
| 同 query 缓存命中 | <1ms | LRU 缓存，避免重复调用 |

建议对 query embedding 加 LRU 缓存（容量 256），相同 query 直接复用。

## 5. ES 索引

### 5.1 Mapping

- `id` (keyword)：case 唯一标识
- `name_zh` (text)：中文名，辅助全文检索和调试
- `kind` (keyword)：gameplay/ui，kNN pre-filter 字段
- `scope` (keyword)：feature/system，备用
- `keywords` (keyword 数组)：作者精选命中词，用于外层精确子串加分
- `summary` (text)：一句话描述，也是 embedding 的输入源
- `when_to_use` (text)：适用场景，辅助检索
- `steps` (object, enabled:false)：引导骨架，不索引仅存储
- `related` (keyword 数组)：related_cases 的 id 列表，依赖链展开用
- `raw_json` (text, index:false)：完整 JSON，渲染 Markdown 时用
- `summary_embedding` (dense_vector, dims=2048, similarity=cosine)：summary 的向量，kNN 搜索目标字段

### 5.2 embed 输入

直接使用 case 的 `summary` 字段，不做多字段拼接。`summary` 是高质量一句话描述（如"玩家走到场景物体前点交互按钮，分数+1，并在 HUD 显示当前分数。"），35 个 case 规模下语义足够区分。keywords 的信号通过外层精确子串加分补偿，不混入 embedding。

## 6. 核心检索类 `VectorRetriever`

### 6.1 职责

- 持有 ES 客户端、索引名、embedding 客户端三个依赖
- 启动时执行 `warmup()`：从 ES 全量拉取所有 case 的 id + keywords 到内存缓存（`_kw_cache`），供后续精确子串加分使用
- 对外暴露 `search(query, kind, top_k)` 异步方法

### 6.2 search() 流程

**Step 1 — embed 查询**：调用豆包 API 将 query 转为 2048 维向量。

**Step 2 — ES kNN 检索**：在 `summary_embedding` 字段上执行 kNN 余弦相似度查询，k 值取 `top_k + 3`（过度检索，为重排序留空间），num_candidates=50。如果 kind 非空则带上 `term filter`，只搜对应分类的文档。

**Step 3 — 重排序**：对 ES 返回的 hits 计算最终得分：

```
final_score = ES 余弦相似度 (0~1) + keyword_bonus(query, keywords)
```

**Step 4 — 截断返回**：按 final_score 降序取 top_k，构建 `SearchResult`（包含 primary case 列表、得分、hit_mode）。

### 6.3 Keywords 精确子串加分

query 与 case 的 keywords 做大小写不敏感的精确子串匹配，单关键词命中 +0.03，累计上限 +0.15。加这个是利用作者精选的高信号词，精确命中值得额外加权，但上限防止过度影响向量排序。首期开启，后期可 feature flag 控制。

### 6.4 Kind 过滤

kind 非空时在 kNN 查询中附加 `{"term": {"kind": "xxx"}}` 的 filter，在符合条件的文档子集上做最近邻搜索。kind 为空时去掉 filter，全量 kNN。

## 7. 入口函数

新增 `vector_case_retrieval.py`，提供两个入口：

- `async lookup_case(query, kind, state)`：异步版本，核心逻辑——获取 `VectorRetriever` 单例 → 调用 `search()` → 结果交给 `format_cases_for_injection()` 渲染 Markdown
- `lookup_case_sync(query, kind, state)`：同步包装，内部 `asyncio.run` 调用异步版本，兼容现有同步调用链

返回值结构不变：

| 字段 | 类型 | 说明 |
|------|------|------|
| `case_context` | str | Markdown 格式的 case 配方正文 |
| `matched_cases` | list[str] | 命中的 case id 列表 |
| `hit_mode` | str | `"vector"` |
| `notes` | list[str] | 检索元信息 |

## 8. 索引构建

### 8.1 全量构建

提供一次性的 `build_es_index.py` 脚本，流程：连接 ES → 读取 `cases/*.json` → 提取所有 `summary` 字段 → 批量调用豆包 embedding → 创建 ES 索引（mapping 按 §5.1）→ bulk 写入所有文档（含 `summary_embedding` 向量和 `raw_json` 全量文本）。

### 8.2 单条更新

case 内容变更时，对该条 re-embed `summary` + ES upsert，无需全量重建。35 个 case 规模下全量重建也足够轻量。

## 9. 依赖链展开

与检索方式无关，完全复用现有逻辑。检索返回 primary case 后，从 `related_cases` 中提取 `feeds_into` / `consumes_output_of` 关系的依赖，仅展开 1 层，摘要数上限 4 个，主包 + 依赖总量上限 5 个。

## 10. 降级 & 灰度

### 10.1 灰度切换

通过环境变量 `CASE_RETRIEVAL_MODE` 控制：值为 `vector` 时走新方案，否则保持现有 token 方案。

### 10.2 异常降级

向量检索路径中任一环节失败时（embedding API 异常、ES 连接超时 > 2s、ES 返回空结果、API 连续 3 次失败），自动降级到现有 `case_retrieval.py` 的 `lookup_case`，对调用方透明。

## 11. 文件结构

```
src/apis/cases/
├── case_retrieval.py               # 现有 token 方案（保留）
├── case_retrieval.md               # 现有文档
├── vector_case_retrieval.py        # 新增：VectorRetriever + lookup_case
├── embedding_client.py             # 新增：DoubaoEmbeddingClient
├── build_es_index.py               # 新增：索引构建脚本
├── vector_retrieval_design.md      # V1 文档
├── vector_retrieval_design_v2.md   # 本文档
└── *.json                          # 35 个 case 数据文件
```

## 12. 调用时序

```
agent.py executor_tools()
  │
  └─ lookup_case(query="我想做一个计分板", kind="", state)
       │
       ├─ VectorRetriever.search()
       │    ├─ DoubaoEmbeddingClient.embed(["我想做一个计分板"])
       │    │    └─ POST doubao API → [2048-dim vector]          ~150ms
       │    │
       │    ├─ ES.search(knn query)                              ~5ms
       │    │    └─ hits[0]: click_to_score (0.92)
       │    │       hits[1]: item_upgrade_by_use (0.61)
       │    │       ...
       │    │
       │    ├─ keyword_bonus("我想做一个计分板", keywords)
       │    │    └─ "计分" +0.03, "分数" +0.03
       │    │    └─ final: click_to_score = 0.92 + 0.06 = 0.98
       │    │
       │    └─ return SearchResult(primary=[click_to_score], ...)
       │
       ├─ format_cases_for_injection(result)
       │    └─ 渲染 Markdown steps 骨架
       │
       └─ return {"case_context": "...", "matched_cases": ["click_to_score"], ...}
```

## 13. 待定

| # | 问题 | 影响 |
|---|------|------|
| 1 | `state` 参数是否参与检索逻辑？ | 若不参与，仅透传即可 |
| 2 | ES 是否已有集群可复用？ | 决定部署方案 |
| 3 | embedding 是否需要本地 LRU 缓存？ | 降低重复 query 的 API 调用 |
| 4 | route 规则层首期是否保留？ | 建议纯向量先跑，badcase 驱动迭代 |
| 5 | 索引更新频率？case 变更是否需实时生效？ | 决定 upsert vs 全量重建 |

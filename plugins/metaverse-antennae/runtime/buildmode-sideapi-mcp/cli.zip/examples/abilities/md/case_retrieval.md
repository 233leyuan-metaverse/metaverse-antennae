# case_retrieval 检索流程

> 来源：`src/apis/case_retrieval.py`，轨 B（architect 用），2026-06-16 创建。

## 1. 架构定位

Case 层是**语义召回**——把用户的自然语言玩法需求映射到 case 配方（"这类玩法怎么做"），不同于 skill 层的精确 `commandType` 倒排（"这条指令语法是什么"）。

```
用户自然语言 → lookup_case（语义召回，token 重叠打分）
                  ↓ 返回 case recipe（steps 引导骨架）
           lookup_skill（Blockly/工作流语法）
                  ↓ 返回技能示例
           Contract semantic tool（写入编辑器）
```

Case 内容只进 LLM 上下文的**动态区**（ToolMessage），不进稳定前缀（prompt cache），避免缓存膨胀。

## 2. 执行流程（以"我想要创建一个记分牌"为例）

### 2.1 LLM 触发

LLM（executor agent）根据 system prompt 里的规则判定这是一个玩法目标（gameplay goal），调用：

```
lookup_case(query="我想要创建一个记分牌")
```

该函数注册在 `agent.py` 的 `executor_tools()` 中，对所有 executor 子 agent 可见。

### 2.2 入口：`lookup_case(query, kind, state)`

```python
# case_retrieval.py:560
def lookup_case(query, kind="", state=None) -> dict:
    result = retrieve_cases(query, kind=kind_arg)
    # 写日志、观测重复调用（不改行为）
    return {
        "case_context": format_cases_for_injection(result),
        "matched_cases": [p.id for p in result.primary],
        "hit_mode": result.hit_mode,
        "notes": [...],
    }
```

### 2.3 核心检索：`retrieve_cases(query, kind, primary_limit)`

```python
# case_retrieval.py:420
def retrieve_cases(query, kind=None, primary_limit=1):
```

#### 2.3.1 加载 case 库 `_load_all()`

读取 `src/apis/cases/*.json`，每个 JSON 解析为 `CasePack` 对象：

| 字段 | 用途 |
|------|------|
| `id` | 唯一标识 |
| `nameZh` | 中文名 |
| `kind` | 粗筛分类（gameplay/ui） |
| `keywords` | 作者精选命中词，命中权重 ×2 |
| `summary` | 一句话描述 |
| `whenToUse` | 使用场景说明 |
| `steps` | 引导骨架（goal/domain/operationHint） |
| `related_cases` | 依赖关系链 |
| `raw` | 完整 JSON，渲染主包时用 |

#### 2.3.2 Token 切分

```python
_TOKEN_RE = re.compile(r"[a-z0-9]+|[一-鿿]")
```

英文按连续字母数字切分，中文按**单字**切分。`"我想要创建一个记分牌"` → `{"我","想","要","创","建","一","个","记","分","牌"}`。

> **局限**：单字切分丢失了词组语义，"记分"和"计分"在单字层面仅 `"分"` 能交叠，"记"/"计"互不匹配。当前 case 总量 34 个勉强可用，量大后需替换为向量检索（代码已预留 `_search_text` seam）。

#### 2.3.3 预路由 `_route_scene_placement(query)`

在 token 打分**之前**，按用户原话的正则匹配给特定 case 加减分，用于修正纯 token 重叠的误召回。

| 检测类别 | 触发条件 | 效果 |
|----------|----------|------|
| 武器/道具 + 创建意图词 | 含武器词 + "创建/做一把…" | create_weapon_resource +25 |
| 道具 + 创建意图词 | 含道具词 + 创建意图 | create_item_resource +25 |
| NPC + 武器 + 创建 | NPC + 武器词 | create_armed_npc +25 |
| NPC + 场景直建（无武器） | NPC 词 + 无资源语义 | create_character_in_scene +25, create_mechanism_in_scene -30 |
| 机关场景放置 | 放置词 + 机关/陷阱类 | create_mechanism_in_scene +25 |
| 角色资源 | 角色/NPC + 资源/预设 | create_character_resource +25 |
| 非放置意图压制 | UI/音频/环境词 + 场景词 | 全部场景放置 case -30 |

#### 2.3.4 预路由 `_route_preset_patch(query)`

检测"修改已有预设"语义（非新建），给 `modify_preset_blockly_patch` +25，同时压低 `fanren_combat_monster_spawner`、`create_mechanism_preset` -30。

#### 2.3.5 Token 重叠打分 `_score()`

```python
def _score(query_tokens, case_pack):
    text_tokens = _tokens(summary + whenToUse + " ".join(keywords) + nameZh + id)
    kw_tokens = _tokens(" ".join(keywords))
    base = len(query_tokens & text_tokens)        # 与全文重叠数
    kw_bonus = len(query_tokens & kw_tokens) * 2  # 与 keywords 重叠数 ×2
    return base + kw_bonus + route_bonus
```

**keywords 权重 ×2** 是核心区分度——keywords 是作者精选的命中词，比泛词（如"创建""一个"，几乎所有 case 文本都有）更有信号价值。

#### 2.3.6 排序截断

```
scored.sort(key=lambda t: (-t[0], t[1].id))  # 分降序，同分按 id 稳定
primary = [p for _, p in scored[:primary_limit]]  # 默认取 Top 1
```

#### 2.3.7 依赖链预展开（§5.4）

只展开主包 `related_cases` 中 `relation` 为以下之一的依赖：

- `feeds_into` — 上游给下游喂数据
- `consumes_output_of` — 下游消费上游产出

约束：
- 仅展开 **1 层**（不传递）
- 依赖总量 ≤ `MAX_DEP_SUMMARIES`（4 个）
- 主包 + 依赖摘要总量 ≤ `TOTAL_CASE_CAP`（5 个）
- 只带摘要不带全量
- 不暴露给 agent "顺链"工具（防 agent 狂看停不下来）

### 2.4 渲染：`format_cases_for_injection(result)`

把检索结果渲染成 LLM 可读的 Markdown 文本：

```markdown
## case: click_to_score（交互记分） scope=feature
intent: 交互物体加分并在界面显示分数
game_loop: 玩家走到计分物体前点交互 → 分数+1 → HUD 刷新显示分数
...
steps（引导骨架，executor 据此每步查 skill；勿当语法）:
  1. [userData] 创建承载分数的玩家自定义数据字段
  2. [templates] 用 Contract 语义工具创建一个可交互的计分物体
  3. [interactive] 用 Contract 语义工具配置交互能力并启用
  4. [blockly-dsl] 编写 Blockly 脚本：交互事件里给玩家分数字段 +1 (hint: sideapi_blockly_compile)
  5. [ui] 把分数字段数据绑定到 HUD 文本控件
```

如有命中 `_CASE_PLACEMENT_HINTS`，还会追加该 case 的动态路由提示。

### 2.5 LLM 按 steps 执行

LLM 拿到 case 配方后，逐 step 选择 Contract 语义工具；只有 Blockly/工作流步骤才调用 `lookup_skill` 获取语法，再交给对应工具写入编辑器。

## 3. 检索文本来源 `_search_text()`

```python
def _search_text(p):
    return " ".join([p.summary, p.whenToUse, " ".join(p.keywords), p.nameZh, p.id])
```

5 个字段拼接，其中 keywords 贡献了主要区分度（×2 权重）。

## 4. 已知局限

| 问题 | 说明 | 缓解 |
|------|------|------|
| 中文单字切分 | "记分"和"计分"单字层面仅"分"交叠 | 当前 case 量少（34）够用；预路由 ±25/±30 强干预 |
| 泛词污染 | "创建""一个"几乎所有 case 文本都有 | keywords ×2 权重拉开差距 |
| 无同义/近义匹配 | 纯 token 重叠，无语义理解 | 代码预留 `_search_text` seam，后续接向量检索替换 `_score()` |
| 无排序模型 | 仅按 token 分数排序 | _route 预路由补偿关键场景 |

## 5. 关键常量

| 常量 | 值 | 说明 |
|------|----|------|
| `DEFAULT_PRIMARY_LIMIT` | 1 | 默认返回主 case 数 |
| `MAX_PRIMARY_LIMIT` | 3 | 主 case 上限 |
| `MAX_DEP_SUMMARIES` | 4 | 依赖摘要数上限 |
| `TOTAL_CASE_CAP` | 5 | 主包+依赖总量硬上限 |
| `DEP_DEPTH` | 1 | 依赖展开层数 |
| `_ROUTE_BONUS_STRONG` | 25 | 强预路由加分 |
| `_ROUTE_BONUS_MEDIUM` | 15 | 中等预路由加分 |
| `_ROUTE_PENALTY_STRONG` | -30 | 强预路由惩罚 |

"use strict";

// Canonical runtime form for Puerts. This file is JavaScript, not TypeScript.
const UE = require("ue");
const puerts = require("puerts");

const API_VERSION = "1.7.0";
const pendingComponentAdds = new WeakMap();

function ok(value) {
    return { ok: true, value };
}

function error(operationId, code, message) {
    return {
        ok: false,
        error: {
            operationId,
            code,
            message,
        },
    };
}

function messageFromError(value) {
    if (value && typeof value.message === "string") {
        return value.message;
    }
    return String(value);
}

function callSafely(operationId, callback) {
    try {
        return callback();
    } catch (caught) {
        return error(operationId, "native_call_failed", messageFromError(caught));
    }
}

function isUObjectValid(value) {
    try {
        return value !== null && value !== undefined && UE.KismetSystemLibrary.IsValid(value);
    } catch (_caught) {
        return false;
    }
}

function requireUObject(operationId, value, parameterName) {
    if (!isUObjectValid(value)) {
        return error(operationId, "invalid_uobject", `${parameterName} is null, destroyed, or pending kill`);
    }
    return ok(value);
}

function requireNativeValue(operationId, value, parameterName) {
    if (value === null || value === undefined) {
        return error(operationId, "missing_native_value", `${parameterName} must be an existing native UE value`);
    }
    return ok(value);
}

function requireFiniteVector(operationId, value, parameterName) {
    const nativeValue = requireNativeValue(operationId, value, parameterName);
    if (!nativeValue.ok) {
        return nativeValue;
    }
    try {
        if (!Number.isFinite(value.X) || !Number.isFinite(value.Y) || !Number.isFinite(value.Z)) {
            return error(operationId, "invalid_vector", `${parameterName} must contain finite X, Y, and Z values`);
        }
    } catch (caught) {
        return error(operationId, "invalid_vector", `${parameterName}: ${messageFromError(caught)}`);
    }
    return ok(value);
}

function requireFiniteRotator(operationId, value, parameterName) {
    const nativeValue = requireNativeValue(operationId, value, parameterName);
    if (!nativeValue.ok) {
        return nativeValue;
    }
    try {
        if (!Number.isFinite(value.Pitch) || !Number.isFinite(value.Yaw) || !Number.isFinite(value.Roll)) {
            return error(operationId, "invalid_rotator", `${parameterName} must contain finite Pitch, Yaw, and Roll values`);
        }
    } catch (caught) {
        return error(operationId, "invalid_rotator", `${parameterName}: ${messageFromError(caught)}`);
    }
    return ok(value);
}

function requireFiniteLinearColor(operationId, value, parameterName) {
    const nativeValue = requireNativeValue(operationId, value, parameterName);
    if (!nativeValue.ok) {
        return nativeValue;
    }
    try {
        if (
            !Number.isFinite(value.R) ||
            !Number.isFinite(value.G) ||
            !Number.isFinite(value.B) ||
            !Number.isFinite(value.A)
        ) {
            return error(operationId, "invalid_linear_color", `${parameterName} must contain finite R, G, B, and A values`);
        }
    } catch (caught) {
        return error(operationId, "invalid_linear_color", `${parameterName}: ${messageFromError(caught)}`);
    }
    return ok(value);
}

function requireServerWorld(operationId, worldContextObject) {
    const validContext = requireUObject(operationId, worldContextObject, "worldContextObject");
    if (!validContext.ok) {
        return validContext;
    }
    return callSafely(operationId, () => {
        const gameMode = UE.GameplayStatics.GetGameMode(worldContextObject);
        if (!isUObjectValid(gameMode)) {
            return error(
                operationId,
                "server_authority_required",
                "A live GameMode is required; execute this lifecycle operation on the server after the world is ready",
            );
        }
        return ok({ worldContextObject, gameMode });
    });
}

function cleanupDeferredActor(actor) {
    try {
        if (isUObjectValid(actor) && actor.HasAuthority()) {
            actor.K2_DestroyActor();
        }
    } catch (_caught) {
        // Best-effort rollback for a partially configured deferred spawn.
    }
}

function resolveServerWorldContext(worldContextObject) {
    const operationId = "world.resolve-server-authority";
    if (worldContextObject !== null && worldContextObject !== undefined) {
        return requireServerWorld(operationId, worldContextObject);
    }
    return callSafely(operationId, () => {
        const mwWorld = UE.MetaWorldStatics.GetMWWorld();
        if (!isUObjectValid(mwWorld)) {
            return error(operationId, "mw_world_unavailable", "MetaWorld has not created a live MWWorld yet");
        }
        if (!isUObjectValid(mwWorld.World)) {
            return error(operationId, "ue_world_unavailable", "MWWorld.World is not ready");
        }
        const serverWorld = requireServerWorld(operationId, mwWorld.World);
        if (!serverWorld.ok) {
            return serverWorld;
        }
        return ok({
            worldContextObject: serverWorld.value.worldContextObject,
            gameMode: serverWorld.value.gameMode,
            mwWorld,
        });
    });
}

function makeTransform(location, rotation, scale) {
    const operationId = "math.make-transform";
    const validLocation = requireFiniteVector(operationId, location, "location");
    if (!validLocation.ok) {
        return validLocation;
    }
    const validRotation = requireFiniteRotator(operationId, rotation, "rotation");
    if (!validRotation.ok) {
        return validRotation;
    }
    const validScale = requireFiniteVector(operationId, scale, "scale");
    if (!validScale.ok) {
        return validScale;
    }
    if (scale.X <= 0 || scale.Y <= 0 || scale.Z <= 0) {
        return error(operationId, "invalid_scale", "scale components must all be greater than zero");
    }
    return callSafely(
        operationId,
        () => ok(UE.KismetMathLibrary.MakeTransform(location, rotation, scale)),
    );
}

function spawnCharacterAuthority(worldContextObject, spawnTransform, options) {
    const operationId = "character.spawn.authority";
    const serverWorld = requireServerWorld(operationId, worldContextObject);
    if (!serverWorld.ok) {
        return serverWorld;
    }
    const validTransform = requireNativeValue(operationId, spawnTransform, "spawnTransform");
    if (!validTransform.ok) {
        return validTransform;
    }

    let deferredCharacter = null;
    const spawnResult = callSafely(operationId, () => {
        const characterClass = options && options.characterClass
            ? options.characterClass
            : UE.MWSysCharacter.StaticClass();
        if (!isUObjectValid(characterClass)) {
            return error(operationId, "invalid_character_class", "characterClass must be a live UE.Class");
        }
        if (!UE.KismetMathLibrary.ClassIsChildOf(characterClass, UE.MWSysCharacter.StaticClass())) {
            return error(operationId, "unsupported_character_class", "characterClass must derive from UE.MWSysCharacter");
        }

        let character = UE.GameplayStatics.BeginDeferredActorSpawnFromClass(
            worldContextObject,
            characterClass,
            spawnTransform,
            UE.ESpawnActorCollisionHandlingMethod.AlwaysSpawn,
            null,
        );
        if (!isUObjectValid(character)) {
            return error(operationId, "spawn_failed", "BeginDeferredActorSpawnFromClass returned no Character");
        }
        deferredCharacter = character;
        if (!isActorOfType(character, UE.MWSysCharacter)) {
            cleanupDeferredActor(character);
            return error(operationId, "spawned_wrong_type", "Deferred spawn did not create UE.MWSysCharacter");
        }

        character.SetReplicates(true);
        character = UE.GameplayStatics.FinishSpawningActor(character, spawnTransform);
        if (!isUObjectValid(character) || !character.HasAuthority()) {
            cleanupDeferredActor(character);
            return error(operationId, "spawn_finish_failed", "Finished Character is invalid or is not server authority");
        }
        return ok(character);
    });
    if (!spawnResult.ok) {
        cleanupDeferredActor(deferredCharacter);
    }
    return spawnResult;
}

function createServerTriggerBoxAuthority(worldContextObject, spawnTransform, extent) {
    const operationId = "trigger.box.create.server-authority";
    const serverWorld = requireServerWorld(operationId, worldContextObject);
    if (!serverWorld.ok) {
        return serverWorld;
    }
    const validTransform = requireNativeValue(operationId, spawnTransform, "spawnTransform");
    if (!validTransform.ok) {
        return validTransform;
    }
    const validExtent = requireFiniteVector(operationId, extent, "extent");
    if (!validExtent.ok) {
        return validExtent;
    }
    if (extent.X <= 0 || extent.Y <= 0 || extent.Z <= 0) {
        return error(operationId, "invalid_extent", "extent components must all be greater than zero");
    }

    let deferredTrigger = null;
    const spawnResult = callSafely(operationId, () => {
        let triggerActor = UE.GameplayStatics.BeginDeferredActorSpawnFromClass(
            worldContextObject,
            UE.TriggerBox.StaticClass(),
            spawnTransform,
            UE.ESpawnActorCollisionHandlingMethod.AlwaysSpawn,
            null,
        );
        if (!isUObjectValid(triggerActor)) {
            return error(operationId, "spawn_failed", "BeginDeferredActorSpawnFromClass returned no TriggerBox");
        }
        deferredTrigger = triggerActor;
        if (!isActorOfType(triggerActor, UE.TriggerBox)) {
            cleanupDeferredActor(triggerActor);
            return error(operationId, "spawned_wrong_type", "Deferred spawn did not create UE.TriggerBox");
        }

        // The trigger exists only on the authority. Clients receive Character movement,
        // not a second client-side gameplay decision path.
        triggerActor.SetReplicates(false);
        const collision = triggerActor.CollisionComponent;
        if (!isUObjectValid(collision) || !collision.IsA(UE.BoxComponent.StaticClass())) {
            cleanupDeferredActor(triggerActor);
            return error(operationId, "box_component_unavailable", "TriggerBox.CollisionComponent is not a live BoxComponent");
        }

        collision.SetCollisionEnabled(UE.ECollisionEnabled.QueryOnly);
        collision.SetCollisionResponseToAllChannels(UE.ECollisionResponse.ECR_Ignore);
        collision.SetCollisionResponseToChannel(
            UE.ECollisionChannel.ECC_Pawn,
            UE.ECollisionResponse.ECR_Overlap,
        );
        collision.SetGenerateOverlapEvents(true);
        collision.SetBoxExtent(extent, false);

        triggerActor = UE.GameplayStatics.FinishSpawningActor(triggerActor, spawnTransform);
        if (!isUObjectValid(triggerActor) || !triggerActor.HasAuthority()) {
            cleanupDeferredActor(triggerActor);
            return error(operationId, "spawn_finish_failed", "Finished TriggerBox is invalid or is not server authority");
        }
        return ok({ actor: triggerActor, collision });
    });
    if (!spawnResult.ok) {
        cleanupDeferredActor(deferredTrigger);
    }
    return spawnResult;
}

function configureServerOnlyBoxTriggerComponent(component, extent) {
    const operationId = "component.box.configure-server-only-pawn-trigger";
    const validComponent = requireUObject(operationId, component, "component");
    if (!validComponent.ok) {
        return validComponent;
    }
    const validExtent = requireFiniteVector(operationId, extent, "extent");
    if (!validExtent.ok) {
        return validExtent;
    }
    if (extent.X <= 0 || extent.Y <= 0 || extent.Z <= 0) {
        return error(operationId, "invalid_extent", "extent components must all be greater than zero");
    }
    return callSafely(operationId, () => {
        if (!component.IsA(UE.BoxComponent.StaticClass())) {
            return error(operationId, "box_component_required", "component must be a live UE.BoxComponent");
        }
        const owner = component.GetOwner();
        const networkIntent = requireComponentNetworkIntent(
            operationId,
            owner,
            component,
            { networkIntent: "server_only" },
        );
        if (!networkIntent.ok) {
            return networkIntent;
        }
        component.SetCollisionEnabled(UE.ECollisionEnabled.QueryOnly);
        component.SetCollisionResponseToAllChannels(UE.ECollisionResponse.ECR_Ignore);
        component.SetCollisionResponseToChannel(
            UE.ECollisionChannel.ECC_Pawn,
            UE.ECollisionResponse.ECR_Overlap,
        );
        component.SetGenerateOverlapEvents(true);
        component.SetBoxExtent(extent, false);
        return ok(component);
    });
}

function bindServerActorBeginOverlap(actor, callback, options) {
    const operationId = "trigger.actor-begin-overlap.bind.server-authority";
    const validActor = requireUObject(operationId, actor, "actor");
    if (!validActor.ok) {
        return validActor;
    }
    if (typeof callback !== "function") {
        return error(operationId, "invalid_callback", "callback must be a function");
    }

    return callSafely(operationId, () => {
        if (!actor.HasAuthority()) {
            return error(operationId, "server_authority_required", "Bind the authoritative gameplay overlap only on the server");
        }
        const delegate = actor.OnActorBeginOverlap;
        if (!delegate || typeof delegate.Add !== "function" || typeof delegate.Remove !== "function") {
            return error(operationId, "delegate_unavailable", "Actor.OnActorBeginOverlap does not expose Add and Remove");
        }

        let disposed = false;
        const listener = (overlappedActor, otherActor) => {
            if (disposed) {
                return;
            }
            try {
                callback(overlappedActor, otherActor);
            } catch (caught) {
                if (options && typeof options.onCallbackError === "function") {
                    try {
                        options.onCallbackError(caught, overlappedActor, otherActor);
                    } catch (_nestedCaught) {
                        // Never propagate JS diagnostic failures into the native delegate.
                    }
                }
            }
        };
        delegate.Add(listener);

        function dispose() {
            if (disposed) {
                return ok(false);
            }
            disposed = true;
            const removeResult = callSafely(operationId, () => {
                if (isUObjectValid(actor)) {
                    actor.OnActorBeginOverlap.Remove(listener);
                }
                return ok(true);
            });
            if (!removeResult.ok) {
                disposed = false;
            }
            return removeResult;
        }

        return ok(Object.freeze({ dispose, listener }));
    });
}

function requireMWComponentHitSource(operationId, component) {
    const validComponent = requireUObject(operationId, component, "component");
    if (!validComponent.ok) {
        return validComponent;
    }
    return callSafely(operationId, () => {
        if (typeof component.GetOwner !== "function") {
            return error(operationId, "component_owner_unavailable", "component must expose GetOwner");
        }
        const owner = component.GetOwner();
        const validOwner = requireUObject(operationId, owner, "component owner");
        if (!validOwner.ok) {
            return validOwner;
        }

        let sourceKind = null;
        if (
            typeof owner.GetStaticMeshComponent === "function" &&
            owner.GetStaticMeshComponent() === component &&
            typeof component.SetMaterialColor === "function"
        ) {
            sourceKind = "mw_static_mesh_actor_component";
        } else if (
            typeof owner.GetBTAComponent === "function" &&
            owner.CapsuleComponent === component
        ) {
            sourceKind = "mw_bta_collision_component";
        }
        if (sourceKind === null) {
            return error(
                operationId,
                "unsupported_mw_hit_source",
                "OnComponentBeginHit/EndHit are wired only for MWStaticMeshActor.GetStaticMeshComponent() or MWSysBTAStaticMeshActor.CapsuleComponent",
            );
        }
        if (
            typeof component.GetGenerateOverlapEvents !== "function" ||
            component.GetGenerateOverlapEvents() !== true ||
            typeof component.K2_IsQueryCollisionEnabled !== "function" ||
            component.K2_IsQueryCollisionEnabled() !== true
        ) {
            return error(
                operationId,
                "mw_hit_source_not_ready",
                "Configure query collision and overlap generation through the owning MW/editor lifecycle before binding",
            );
        }

        const beginDelegate = component.OnComponentBeginHit;
        const endDelegate = component.OnComponentEndHit;
        if (
            !beginDelegate ||
            typeof beginDelegate.Add !== "function" ||
            typeof beginDelegate.Remove !== "function" ||
            !endDelegate ||
            typeof endDelegate.Add !== "function" ||
            typeof endDelegate.Remove !== "function"
        ) {
            return error(operationId, "delegate_unavailable", "Both MW Component hit delegates must expose Add and Remove");
        }
        return ok({ component, owner, sourceKind, beginDelegate, endDelegate });
    });
}

function bindMWComponentHitPair(operationId, component, onPressed, onReleased, options, requireAuthority) {
    if (typeof onPressed !== "function" || typeof onReleased !== "function") {
        return error(operationId, "invalid_callback", "onPressed and onReleased must both be functions");
    }
    if (!requireAuthority && (!options || options.localEventOnly !== true)) {
        return error(operationId, "local_event_intent_required", "Local binding requires options.localEventOnly=true");
    }
    if (options && options.acceptContact !== undefined && typeof options.acceptContact !== "function") {
        return error(operationId, "invalid_contact_filter", "options.acceptContact must be a function when provided");
    }

    const sourceResult = requireMWComponentHitSource(operationId, component);
    if (!sourceResult.ok) {
        return sourceResult;
    }
    const source = sourceResult.value;
    if (requireAuthority && !source.owner.HasAuthority()) {
        return error(operationId, "server_authority_required", "Bind authoritative Component contact state only on the server");
    }

    return callSafely(operationId, () => {
        const contacts = new Map();
        let totalContactCount = 0;
        let beginBound = false;
        let endBound = false;
        let disposed = false;

        function reportCallbackError(caught, payload) {
            if (options && typeof options.onCallbackError === "function") {
                try {
                    options.onCallbackError(caught, payload);
                } catch (_nestedCaught) {
                    // Never propagate JS diagnostic failures into the native delegate.
                }
            }
        }

        function makePayload(phase, hitComponent, otherActor, otherComponent, otherBodyIndex, hitResult) {
            return {
                phase,
                sourceKind: source.sourceKind,
                hitComponent,
                otherActor,
                otherComponent,
                otherBodyIndex,
                hitResult: hitResult || null,
                contactCount: totalContactCount,
            };
        }

        function addContact(otherActor, otherComponent, otherBodyIndex) {
            let byComponent = contacts.get(otherActor);
            if (!byComponent) {
                byComponent = new Map();
                contacts.set(otherActor, byComponent);
            }
            let bodyIndices = byComponent.get(otherComponent);
            if (!bodyIndices) {
                bodyIndices = new Set();
                byComponent.set(otherComponent, bodyIndices);
            }
            if (bodyIndices.has(otherBodyIndex)) {
                return false;
            }
            bodyIndices.add(otherBodyIndex);
            totalContactCount += 1;
            return totalContactCount === 1;
        }

        function removeContact(otherActor, otherComponent, otherBodyIndex) {
            const byComponent = contacts.get(otherActor);
            if (!byComponent) {
                return false;
            }
            const bodyIndices = byComponent.get(otherComponent);
            if (!bodyIndices || !bodyIndices.delete(otherBodyIndex)) {
                return false;
            }
            totalContactCount -= 1;
            if (bodyIndices.size === 0) {
                byComponent.delete(otherComponent);
            }
            if (byComponent.size === 0) {
                contacts.delete(otherActor);
            }
            return totalContactCount === 0;
        }

        const beginListener = (hitComponent, otherActor, otherComponent, otherBodyIndex, hitResult) => {
            if (disposed) {
                return;
            }
            const candidate = makePayload(
                "begin",
                hitComponent,
                otherActor,
                otherComponent,
                otherBodyIndex,
                hitResult,
            );
            if (options && typeof options.acceptContact === "function") {
                try {
                    if (options.acceptContact(candidate) !== true) {
                        return;
                    }
                } catch (caught) {
                    reportCallbackError(caught, candidate);
                    return;
                }
            }
            if (!addContact(otherActor, otherComponent, otherBodyIndex)) {
                return;
            }
            const payload = makePayload(
                "pressed",
                hitComponent,
                otherActor,
                otherComponent,
                otherBodyIndex,
                hitResult,
            );
            try {
                onPressed(payload);
            } catch (caught) {
                reportCallbackError(caught, payload);
            }
        };

        const endListener = (hitComponent, otherActor, otherComponent, otherBodyIndex) => {
            if (disposed || !removeContact(otherActor, otherComponent, otherBodyIndex)) {
                return;
            }
            const payload = makePayload(
                "released",
                hitComponent,
                otherActor,
                otherComponent,
                otherBodyIndex,
                null,
            );
            try {
                onReleased(payload);
            } catch (caught) {
                reportCallbackError(caught, payload);
            }
        };

        source.beginDelegate.Add(beginListener);
        beginBound = true;
        try {
            source.endDelegate.Add(endListener);
            endBound = true;
        } catch (caught) {
            try {
                source.beginDelegate.Remove(beginListener);
                beginBound = false;
            } catch (_rollbackCaught) {
                // The structured binding error remains the primary failure.
            }
            throw caught;
        }

        function dispose() {
            if (disposed) {
                return ok(false);
            }
            const failures = [];
            if (!isUObjectValid(source.component)) {
                beginBound = false;
                endBound = false;
            } else {
                if (beginBound) {
                    try {
                        source.component.OnComponentBeginHit.Remove(beginListener);
                        beginBound = false;
                    } catch (caught) {
                        failures.push(messageFromError(caught));
                    }
                }
                if (endBound) {
                    try {
                        source.component.OnComponentEndHit.Remove(endListener);
                        endBound = false;
                    } catch (caught) {
                        failures.push(messageFromError(caught));
                    }
                }
            }
            disposed = !beginBound && !endBound;
            if (disposed) {
                contacts.clear();
                totalContactCount = 0;
            }
            if (failures.length > 0) {
                return error(operationId, "delegate_remove_failed", failures.join("; "));
            }
            return ok(true);
        }

        return ok(Object.freeze({
            dispose,
            getContactCount: () => totalContactCount,
            beginListener,
            endListener,
        }));
    });
}

function bindServerMWComponentHitPair(component, onPressed, onReleased, options) {
    return bindMWComponentHitPair(
        "component.mw-hit-pair.bind.server-authority",
        component,
        onPressed,
        onReleased,
        options,
        true,
    );
}

function resolveMWStaticMeshComponentFromEntity(entity) {
    const operationId = "component.resolve-mw-static-mesh-from-entity";
    if (!entity || typeof entity.gameObjectId !== "string" || entity.gameObjectId.trim().length === 0) {
        return error(
            operationId,
            "user_component_entity_required",
            "entity must be the UserComponent host IEntity with a non-empty gameObjectId",
        );
    }

    return callSafely(operationId, () => {
        const mwNamespace = typeof mw === "object" && mw !== null ? mw : null;
        if (
            !mwNamespace ||
            !mwNamespace.GameObject ||
            typeof mwNamespace.GameObject.findGameObjectById !== "function"
        ) {
            return error(
                operationId,
                "mw_game_object_lookup_unavailable",
                "mw.GameObject.findGameObjectById is unavailable in this UserComponent runtime",
            );
        }

        const gameObject = mwNamespace.GameObject.findGameObjectById(entity.gameObjectId.trim());
        if (!gameObject) {
            return error(operationId, "host_game_object_not_found", "No mw.GameObject exists for entity.gameObjectId");
        }

        if (typeof mwNamespace.Model !== "function" || !(gameObject instanceof mwNamespace.Model)) {
            return error(
                operationId,
                "explicit_model_required",
                "The UserComponent host must be explicitly proven as mw.Model before any Actor bridge",
            );
        }
        if (
            !UE.MWInstanceManager ||
            typeof UE.MWInstanceManager.IsInstance !== "function"
        ) {
            return error(
                operationId,
                "instance_detector_unavailable",
                "UE.MWInstanceManager.IsInstance is unavailable; use the public mw.Model API",
            );
        }
        if (UE.MWInstanceManager.IsInstance(entity.gameObjectId.trim())) {
            return error(
                operationId,
                "instance_route_required",
                "The Model is currently an Instance; choose an instance_direct route from instance-routing-catalog.json or use the public mw.Model API",
            );
        }

        // This is the only catalogued read of the internal GameObject.actor getter.
        const actor = gameObject.actor;
        const validActor = requireUObject(operationId, actor, "host actor");
        if (!validActor.ok) {
            return validActor;
        }
        if (typeof actor.IsA !== "function") {
            return error(
                operationId,
                "actor_type_check_unavailable",
                "Host Actor does not expose the reviewed IsA validation method",
            );
        }
        if (isActorOfType(actor, UE.MWInstanceStaticMeshActor)) {
            return error(
                operationId,
                "instance_representation_forbidden",
                "The Entity resolves to MWInstanceStaticMeshActor; this operation never converts Instance representation",
            );
        }
        if (!isActorOfType(actor, UE.MWStaticMeshActor) || typeof actor.GetStaticMeshComponent !== "function") {
            return error(
                operationId,
                "mw_static_mesh_actor_required",
                "The Entity must resolve to a UE.MWStaticMeshActor",
            );
        }

        const component = actor.GetStaticMeshComponent();
        const validComponent = requireUObject(operationId, component, "MWStaticMeshComponent");
        if (!validComponent.ok) {
            return validComponent;
        }
        if (typeof component.GetOwner !== "function" || component.GetOwner() !== actor) {
            return error(
                operationId,
                "component_owner_mismatch",
                "GetStaticMeshComponent must return a live component owned by the resolved Actor",
            );
        }
        if (component.Mobility !== UE.EComponentMobility.Movable) {
            return error(
                operationId,
                "movable_component_required",
                "MWStaticMeshComponent must already be Movable; this template never changes Mobility",
            );
        }
        return ok(component);
    });
}

function bindLocalMWComponentHitPair(component, onPressed, onReleased, options) {
    return bindMWComponentHitPair(
        "component.mw-hit-pair.bind.client-local",
        component,
        onPressed,
        onReleased,
        options,
        false,
    );
}

function setMovableSceneComponentRelativeLocationLocal(component, relativeLocation, guid, options) {
    const operationId = "component.set-relative-location.local-visual";
    const validComponent = requireUObject(operationId, component, "component");
    if (!validComponent.ok) {
        return validComponent;
    }
    const validLocation = requireFiniteVector(operationId, relativeLocation, "relativeLocation");
    if (!validLocation.ok) {
        return validLocation;
    }
    if (typeof guid !== "string" || guid.length === 0) {
        return error(operationId, "invalid_guid", "guid must be a non-empty string");
    }
    if (!options || options.localVisualOnly !== true) {
        return error(operationId, "local_visual_intent_required", "Local visual movement requires options.localVisualOnly=true");
    }

    return callSafely(operationId, () => {
        if (typeof component.GetOwner !== "function" || typeof component.MWSetRelativeLocation !== "function") {
            return error(operationId, "scene_component_required", "component must be an owned UE.SceneComponent");
        }
        const owner = component.GetOwner();
        const validOwner = requireUObject(operationId, owner, "component owner");
        if (!validOwner.ok) {
            return validOwner;
        }
        if (component.Mobility !== UE.EComponentMobility.Movable) {
            return error(operationId, "movable_component_required", "Component must already be Movable; this template never changes Mobility");
        }
        const rootComponent = typeof owner.K2_GetRootComponent === "function" ? owner.K2_GetRootComponent() : null;
        if (rootComponent !== component) {
            return error(
                operationId,
                "root_component_required",
                "MWSetRelativeLocation is catalogued here only for the owning Actor root component",
            );
        }
        if (owner.bReplicateMovement === true) {
            return error(
                operationId,
                "replicated_root_component_conflict",
                "Do not apply a client-local relative move to the root of an Actor using RepMovement",
            );
        }
        component.MWSetRelativeLocation(relativeLocation, guid);
        return ok({ component, guid });
    });
}

function destroyActorAuthority(actor) {
    const operationId = "actor.destroy.authority";
    const validActor = requireUObject(operationId, actor, "actor");
    if (!validActor.ok) {
        return validActor;
    }
    return callSafely(operationId, () => {
        if (!actor.HasAuthority()) {
            return error(operationId, "server_authority_required", "Only authority may destroy this Actor");
        }
        actor.K2_DestroyActor();
        return ok(true);
    });
}

function requireActorComponentClass(operationId, componentClass, requireConstructible, options) {
    if (!isUObjectValid(componentClass)) {
        return error(operationId, "invalid_component_class", "componentClass must be a live UE.Class");
    }
    return callSafely(operationId, () => {
        if (
            typeof UE.KismetSystemLibrary.IsValidClass === "function" &&
            !UE.KismetSystemLibrary.IsValidClass(componentClass)
        ) {
            return error(operationId, "invalid_component_class", "componentClass failed the UE class validity check");
        }
        const actorComponentClass = UE.ActorComponent.StaticClass();
        if (!UE.KismetMathLibrary.ClassIsChildOf(componentClass, actorComponentClass)) {
            return error(
                operationId,
                "unsupported_component_class",
                "componentClass must derive from UE.ActorComponent",
            );
        }
        if (requireConstructible) {
            const boxComponentClass = UE.BoxComponent.StaticClass();
            const exactBoxClass =
                UE.KismetMathLibrary.ClassIsChildOf(componentClass, boxComponentClass) &&
                UE.KismetMathLibrary.ClassIsChildOf(boxComponentClass, componentClass);
            const boxPolicyMatches = Boolean(
                options &&
                options.componentClassPolicyId === "box-component-runtime-v1" &&
                exactBoxClass &&
                ["local_only", "server_only"].includes(options.networkIntent),
            );
            if (!boxPolicyMatches) {
                return error(
                    operationId,
                    "component_class_policy_required",
                    "componentClass and networkIntent must match an explicit operation-catalog component_class_policies entry",
                );
            }
        }
        return ok(componentClass);
    });
}

function requireComponentNetworkIntent(operationId, actor, component, options) {
    const intent = options && options.networkIntent;
    if (![
        "local_only",
        "server_only",
        "replicated_subobject",
    ].includes(intent)) {
        return error(
            operationId,
            "component_network_intent_required",
            "networkIntent must be local_only, server_only, or replicated_subobject",
        );
    }

    if (intent === "local_only") {
        if (component && component.bReplicates === true) {
            return error(
                operationId,
                "replicated_component_local_mutation_forbidden",
                "A replicated component cannot be destroyed through the local_only path",
            );
        }
        return ok({ intent, replicated: false });
    }

    const serverWorld = requireServerWorld(operationId, actor);
    if (!serverWorld.ok) {
        return serverWorld;
    }
    if (typeof actor.HasAuthority !== "function" || !actor.HasAuthority()) {
        return error(operationId, "actor_authority_required", "Component lifecycle mutation requires Actor authority");
    }
    if (intent === "server_only") {
        if (component && component.bReplicates === true) {
            return error(
                operationId,
                "component_network_intent_mismatch",
                "server_only cannot destroy a replicated component",
            );
        }
        return ok({ intent, replicated: false });
    }

    if (actor.bReplicates !== true) {
        return error(
            operationId,
            "replicated_owner_required",
            "replicated_subobject requires an owning Actor with bReplicates=true",
        );
    }
    if (!options || options.confirmedDynamicSubobjectReplication !== true) {
        return error(
            operationId,
            "dynamic_subobject_replication_confirmation_required",
            "Confirm the current target's dynamic component creation, deletion, late-join, and reconnect path",
        );
    }
    if (component && component.bReplicates !== true) {
        return error(
            operationId,
            "component_network_intent_mismatch",
            "replicated_subobject requires component.bReplicates=true",
        );
    }
    return ok({ intent, replicated: true });
}

function cleanupUnfinishedComponent(component, actor) {
    try {
        if (isUObjectValid(component) && isUObjectValid(actor)) {
            component.K2_DestroyComponent(actor);
        }
    } catch (_caught) {
        // Best-effort rollback for AddComponentByClass before FinishAddComponent.
    }
}

function getActorComponentByClass(actor, componentClass) {
    const operationId = "actor.component.get-first-by-class";
    const validActor = requireUObject(operationId, actor, "actor");
    if (!validActor.ok) {
        return validActor;
    }
    const validClass = requireActorComponentClass(operationId, componentClass, false, null);
    if (!validClass.ok) {
        return validClass;
    }
    return callSafely(operationId, () => {
        const component = actor.GetComponentByClass(componentClass);
        return ok(isUObjectValid(component) ? component : null);
    });
}

function getActorComponentsByClass(actor, componentClass) {
    const operationId = "actor.component.get-all-by-class";
    const validActor = requireUObject(operationId, actor, "actor");
    if (!validActor.ok) {
        return validActor;
    }
    const validClass = requireActorComponentClass(operationId, componentClass, false, null);
    if (!validClass.ok) {
        return validClass;
    }
    return callSafely(operationId, () => {
        const nativeComponents = actor.K2_GetComponentsByClass(componentClass);
        if (nativeComponents === null || nativeComponents === undefined) {
            return ok(Object.freeze([]));
        }
        if (typeof nativeComponents.length !== "number") {
            return error(operationId, "unexpected_component_array", "K2_GetComponentsByClass did not return an array-like value");
        }
        const components = [];
        for (let index = 0; index < nativeComponents.length; index++) {
            if (isUObjectValid(nativeComponents[index])) {
                components.push(nativeComponents[index]);
            }
        }
        return ok(Object.freeze(components));
    });
}

function beginAddActorComponentByClass(actor, componentClass, relativeTransform, options) {
    const operationId = "actor.component.begin-add-by-class";
    const validActor = requireUObject(operationId, actor, "actor");
    if (!validActor.ok) {
        return validActor;
    }
    const validClass = requireActorComponentClass(operationId, componentClass, true, options);
    if (!validClass.ok) {
        return validClass;
    }
    const validTransform = requireNativeValue(operationId, relativeTransform, "relativeTransform");
    if (!validTransform.ok) {
        return validTransform;
    }
    if (!options || typeof options.manualAttachment !== "boolean") {
        return error(operationId, "manual_attachment_required", "manualAttachment must be explicitly true or false");
    }
    const networkIntent = requireComponentNetworkIntent(operationId, actor, null, options);
    if (!networkIntent.ok) {
        return networkIntent;
    }

    let component = null;
    const addResult = callSafely(operationId, () => {
        component = actor.AddComponentByClass(
            componentClass,
            options.manualAttachment,
            relativeTransform,
            true,
        );
        if (!isUObjectValid(component)) {
            return error(operationId, "component_add_failed", "AddComponentByClass returned no component");
        }
        const owner = component.GetOwner();
        if (!isUObjectValid(owner) || owner !== actor) {
            return error(operationId, "component_owner_mismatch", "Created component is not owned by the requested Actor");
        }
        component.SetIsReplicated(networkIntent.value.replicated);
        const handle = Object.freeze({
            actor,
            component,
            networkIntent: networkIntent.value.intent,
        });
        pendingComponentAdds.set(handle, {
            actor,
            component,
            manualAttachment: options.manualAttachment,
            relativeTransform,
            networkIntent: networkIntent.value.intent,
        });
        return ok(handle);
    });
    if (!addResult.ok) {
        cleanupUnfinishedComponent(component, actor);
    }
    return addResult;
}

function finishAddedActorComponent(handle) {
    const operationId = "actor.component.finish-add";
    const state = handle && pendingComponentAdds.get(handle);
    if (!state) {
        return error(operationId, "invalid_component_add_handle", "Handle is missing, forged, finished, or aborted");
    }
    const validActor = requireUObject(operationId, state.actor, "handle.actor");
    if (!validActor.ok) {
        return validActor;
    }
    const validComponent = requireUObject(operationId, state.component, "handle.component");
    if (!validComponent.ok) {
        return validComponent;
    }

    const finishResult = callSafely(operationId, () => {
        state.actor.FinishAddComponent(
            state.component,
            state.manualAttachment,
            state.relativeTransform,
        );
        if (!isUObjectValid(state.component) || state.component.GetOwner() !== state.actor) {
            return error(operationId, "component_finish_failed", "Finished component is invalid or lost its owner");
        }
        if (state.networkIntent === "replicated_subobject") {
            state.actor.FlushNetDormancy();
            state.actor.CancelAdaptiveReplication(false, true, state.component);
            state.actor.ForceNetUpdate();
        }
        pendingComponentAdds.delete(handle);
        return ok(state.component);
    });
    return finishResult;
}

function abortAddedActorComponent(handle) {
    const operationId = "actor.component.abort-add";
    const state = handle && pendingComponentAdds.get(handle);
    if (!state) {
        return error(operationId, "invalid_component_add_handle", "Handle is missing, forged, finished, or aborted");
    }
    const abortResult = callSafely(operationId, () => {
        cleanupUnfinishedComponent(state.component, state.actor);
        pendingComponentAdds.delete(handle);
        return ok(true);
    });
    return abortResult;
}

function addActorComponentByClass(actor, componentClass, relativeTransform, options) {
    const operationId = "actor.component.add-by-class";
    const beginResult = beginAddActorComponentByClass(actor, componentClass, relativeTransform, options);
    if (!beginResult.ok) {
        return beginResult;
    }
    const finishResult = finishAddedActorComponent(beginResult.value);
    if (!finishResult.ok) {
        abortAddedActorComponent(beginResult.value);
        return error(operationId, finishResult.error.code, finishResult.error.message);
    }
    return finishResult;
}

function destroyActorComponent(component, options) {
    const operationId = "actor.component.destroy";
    const validComponent = requireUObject(operationId, component, "component");
    if (!validComponent.ok) {
        return validComponent;
    }
    return callSafely(operationId, () => {
        if (component.IsBeingDestroyed()) {
            return ok(false);
        }
        const actor = component.GetOwner();
        const validActor = requireUObject(operationId, actor, "component.owner");
        if (!validActor.ok) {
            return validActor;
        }
        const networkIntent = requireComponentNetworkIntent(operationId, actor, component, options);
        if (!networkIntent.ok) {
            return networkIntent;
        }
        const rootPolicy = options && options.rootPolicy ? options.rootPolicy : "reject_if_root";
        if (!["reject_if_root", "allow_rootless_actor"].includes(rootPolicy)) {
            return error(operationId, "invalid_root_policy", "rootPolicy must be reject_if_root or allow_rootless_actor");
        }
        const rootComponent = actor.K2_GetRootComponent();
        if (rootComponent === component && rootPolicy !== "allow_rootless_actor") {
            return error(
                operationId,
                "root_component_destroy_forbidden",
                "Destroying the root leaves the Actor rootless; opt in explicitly or destroy the Actor lifecycle instead",
            );
        }
        if (networkIntent.value.replicated) {
            actor.FlushNetDormancy();
            actor.CancelAdaptiveReplication(false, true, component);
        }
        component.K2_DestroyComponent(actor);
        if (networkIntent.value.replicated) {
            actor.ForceNetUpdate();
        }
        return ok(true);
    });
}

function isActorOfType(actor, ueType) {
    return Boolean(
        ueType &&
        typeof ueType.StaticClass === "function" &&
        actor.IsA(ueType.StaticClass()),
    );
}

function isAuthorityOrAutonomous(actor) {
    return actor.HasAuthority() || actor.GetLocalRole() === UE.ENetRole.ROLE_AutonomousProxy;
}

function requireTransientEventIntent(operationId, options) {
    if (!options || options.transientEvent !== true) {
        return error(
            operationId,
            "persistent_state_requires_replication",
            "Set options.transientEvent=true only for a lossy event that does not require late-join or reconnect recovery",
        );
    }
    return ok(true);
}

function getActorLocation(actor) {
    const operationId = "actor.get-location";
    const validActor = requireUObject(operationId, actor, "actor");
    if (!validActor.ok) {
        return validActor;
    }
    return callSafely(operationId, () => ok(actor.K2_GetActorLocation()));
}

function getActorRotation(actor) {
    const operationId = "actor.get-rotation";
    const validActor = requireUObject(operationId, actor, "actor");
    if (!validActor.ok) {
        return validActor;
    }
    return callSafely(operationId, () => ok(actor.K2_GetActorRotation()));
}

function transformLocation(transform, location) {
    const operationId = "math.transform-location";
    const validTransform = requireNativeValue(operationId, transform, "transform");
    if (!validTransform.ok) {
        return validTransform;
    }
    const validLocation = requireNativeValue(operationId, location, "location");
    if (!validLocation.ok) {
        return validLocation;
    }
    return callSafely(operationId, () => ok(UE.KismetMathLibrary.TransformLocation(transform, location)));
}

function findLookAtRotation(start, target) {
    const operationId = "math.find-look-at-rotation";
    const validStart = requireNativeValue(operationId, start, "start");
    if (!validStart.ok) {
        return validStart;
    }
    const validTarget = requireNativeValue(operationId, target, "target");
    if (!validTarget.ok) {
        return validTarget;
    }
    return callSafely(operationId, () => ok(UE.KismetMathLibrary.FindLookAtRotation(start, target)));
}

function setIndependentActorLocationAuthority(actor, location, options) {
    const operationId = "actor.set-location.independent-authority";
    const validActor = requireUObject(operationId, actor, "actor");
    if (!validActor.ok) {
        return validActor;
    }
    const validLocation = requireNativeValue(operationId, location, "location");
    if (!validLocation.ok) {
        return validLocation;
    }
    if (!options || options.confirmedNoMwTopology !== true) {
        return error(
            operationId,
            "mw_topology_not_proven",
            "The caller must prove there is no MW parent, slot, prefab, persistence, wrapper-cache, or custom replication dependency",
        );
    }
    return callSafely(operationId, () => {
        if (!actor.HasAuthority()) {
            return error(operationId, "authority_required", "Only server authority may mutate replicated Actor location");
        }
        if (actor.bReplicates !== true || actor.bReplicateMovement !== true) {
            return error(
                operationId,
                "rep_movement_required",
                "Generic Actor location requires bReplicates and bReplicateMovement for recoverable network state",
            );
        }
        if (isActorOfType(actor, UE.MWSysCharacter)) {
            return error(operationId, "character_requires_domain_api", "Use setCharacterLocation for MWSysCharacter");
        }
        if (isActorOfType(actor, UE.MWInstanceStaticMeshActor)) {
            return error(operationId, "shared_instance_group_actor", "Never move the shared Instance Group Actor as one logical object");
        }
        const hitResult = new UE.HitResult();
        const hitResultRef = puerts.$ref(hitResult);
        const moved = actor.K2_SetActorLocation(
            location,
            options.sweep === true,
            hitResultRef,
            options.teleport !== false,
        );
        return ok({ moved, hitResult: puerts.$unref(hitResultRef) });
    });
}

function addPawnMovementInput(pawn, worldDirection, scaleValue, force) {
    const operationId = "pawn.add-movement-input";
    const validPawn = requireUObject(operationId, pawn, "pawn");
    if (!validPawn.ok) {
        return validPawn;
    }
    const validDirection = requireNativeValue(operationId, worldDirection, "worldDirection");
    if (!validDirection.ok) {
        return validDirection;
    }
    const resolvedScale = scaleValue === undefined ? 1 : scaleValue;
    if (!Number.isFinite(resolvedScale)) {
        return error(operationId, "invalid_scale", "scaleValue must be finite");
    }
    return callSafely(operationId, () => {
        if (!isAuthorityOrAutonomous(pawn)) {
            return error(operationId, "invalid_network_role", "Pawn must be server authority or owning AutonomousProxy");
        }
        pawn.AddMovementInput(worldDirection, resolvedScale, force === true);
        return ok(true);
    });
}

function setCharacterLocation(character, location, sweep, teleport, options) {
    const operationId = "character.set-location.external";
    const validCharacter = requireUObject(operationId, character, "character");
    if (!validCharacter.ok) {
        return validCharacter;
    }
    const validLocation = requireNativeValue(operationId, location, "location");
    if (!validLocation.ok) {
        return validLocation;
    }
    return callSafely(operationId, () => {
        const isAuthority = character.HasAuthority();
        const isConfiguredAutonomous =
            character.GetLocalRole() === UE.ENetRole.ROLE_AutonomousProxy &&
            options &&
            options.confirmedAutonomousProxyProtocolEnabled === true;
        if (!isAuthority && !isConfiguredAutonomous) {
            return error(
                operationId,
                "invalid_network_role",
                "Use server authority, or explicitly prove the owning AutonomousProxy location protocol is enabled",
            );
        }
        character.SetLocation(location, sweep === true, teleport !== false);
        return ok(true);
    });
}

function getViewportSize(worldContextObject) {
    const operationId = "ui.get-viewport-size";
    const validContext = requireUObject(operationId, worldContextObject, "worldContextObject");
    if (!validContext.ok) {
        return validContext;
    }
    return callSafely(operationId, () => ok(UE.WidgetLayoutLibrary.GetViewportSize(worldContextObject)));
}

function getText(textBlock) {
    const operationId = "ui.text.get";
    const validTextBlock = requireUObject(operationId, textBlock, "textBlock");
    if (!validTextBlock.ok) {
        return validTextBlock;
    }
    return callSafely(operationId, () => ok(textBlock.GetTextByString()));
}

function setTextLocal(textBlock, text, options) {
    const operationId = "ui.text.set-local";
    const validTextBlock = requireUObject(operationId, textBlock, "textBlock");
    if (!validTextBlock.ok) {
        return validTextBlock;
    }
    if (!options || options.confirmedCacheIndependent !== true) {
        return error(
            operationId,
            "widget_cache_not_independent",
            "Use mw.TextBlock.text unless no MW cache, auto-size delegate, lifecycle callback, or shared state observes this write",
        );
    }
    return callSafely(operationId, () => {
        textBlock.SetTextByString(String(text));
        return ok(true);
    });
}

function getInstanceInfo(guid) {
    const operationId = "instance.get-info";
    if (typeof guid !== "string" || guid.length === 0) {
        return error(operationId, "invalid_guid", "guid must be a non-empty string");
    }
    return callSafely(operationId, () => {
        if (!UE.MWInstanceManager.IsInstance(guid)) {
            return error(operationId, "not_instance", "guid is not currently represented as an Instance");
        }
        const info = UE.MWInstanceManager.GetInstanceInfo(guid);
        if (!isUObjectValid(info)) {
            return error(operationId, "instance_info_unavailable", "MWInstanceInfo is unavailable for this call");
        }
        return ok(info);
    });
}

function getInstanceContext(operationId, guid, requireAuthority, requireRenderReady) {
    const infoResult = getInstanceInfo(guid);
    if (!infoResult.ok) {
        return error(operationId, infoResult.error.code, infoResult.error.message);
    }

    return callSafely(operationId, () => {
        const info = infoResult.value;
        const groupActor = info.GetInstanceActor();
        if (!isUObjectValid(groupActor)) {
            return error(operationId, "instance_group_unavailable", "The shared Instance Group Actor is unavailable");
        }
        if (requireAuthority && !groupActor.HasAuthority()) {
            return error(operationId, "authority_required", "Instance push-model state may only be changed by server authority");
        }
        if (requireAuthority && info.NetStatus !== UE.ENetStatus.ServerAndClient) {
            return error(
                operationId,
                "server_and_client_instance_required",
                "Replicated Instance writes require UE.ENetStatus.ServerAndClient",
            );
        }

        let component = null;
        if (requireRenderReady) {
            component = groupActor.GetInstancedStaticMeshComponent();
            if (!isUObjectValid(component)) {
                return error(operationId, "instance_render_not_ready", "The shared InstancedStaticMeshComponent is not ready");
            }
        }
        return ok({ info, groupActor, component });
    });
}

function getInstanceParentGuid(guid) {
    const operationId = "instance.get-parent-guid";
    if (typeof guid !== "string" || guid.length === 0) {
        return error(operationId, "invalid_guid", "guid must be a non-empty string");
    }
    return callSafely(operationId, () => ok(UE.MWInstanceManager.GetParentGuid(guid)));
}

function getInstanceSourceTransform(guid, isWorld) {
    const operationId = "instance.get-source-transform";
    const infoResult = getInstanceInfo(guid);
    if (!infoResult.ok) {
        return error(operationId, infoResult.error.code, infoResult.error.message);
    }
    return callSafely(operationId, () => ok(UE.MWInstanceManager.GetSourceTransform(guid, isWorld === true)));
}

function getInstanceMaterialSlotColor(guid, slot) {
    const operationId = "instance.get-material-slot-color";
    if (!Number.isInteger(slot) || slot < 0) {
        return error(operationId, "invalid_material_slot", "slot must be a non-negative integer");
    }
    const context = getInstanceContext(operationId, guid, false, true);
    if (!context.ok) {
        return context;
    }
    return callSafely(operationId, () => {
        if (slot >= context.value.component.GetNumMaterials()) {
            return error(operationId, "invalid_material_slot", "slot is outside the current material range");
        }
        return ok(context.value.info.GetMaterialSlotColor(slot));
    });
}

function setInstanceBooleanAuthority(operationId, guid, value, setter) {
    if (typeof value !== "boolean") {
        return error(operationId, "invalid_boolean", "value must be a boolean");
    }
    const context = getInstanceContext(operationId, guid, true, true);
    if (!context.ok) {
        return context;
    }
    return callSafely(operationId, () => {
        setter(context.value.info, value);
        return ok(true);
    });
}

function setInstanceNumberAuthority(operationId, guid, value, setter) {
    if (!Number.isFinite(value)) {
        return error(operationId, "invalid_number", "value must be finite");
    }
    const context = getInstanceContext(operationId, guid, true, true);
    if (!context.ok) {
        return context;
    }
    return callSafely(operationId, () => {
        setter(context.value.info, value);
        return ok(true);
    });
}

function lineTraceByCollisionGroup(
    worldContextObject,
    collisionGroup,
    start,
    end,
    actorsToIgnore,
    onlyBlock,
    isMulti,
) {
    const operationId = "query.line-trace.collision-group";
    const validContext = requireUObject(operationId, worldContextObject, "worldContextObject");
    if (!validContext.ok) {
        return validContext;
    }
    if (typeof collisionGroup !== "string" || collisionGroup.length === 0) {
        return error(operationId, "invalid_collision_group", "collisionGroup must be a non-empty string");
    }
    const validStart = requireNativeValue(operationId, start, "start");
    if (!validStart.ok) {
        return validStart;
    }
    const validEnd = requireNativeValue(operationId, end, "end");
    if (!validEnd.ok) {
        return validEnd;
    }

    return callSafely(operationId, () => {
        const nativeActors = actorsToIgnore || UE.NewArray(UE.Actor);
        if (typeof nativeActors.Num !== "function" || typeof nativeActors.Add !== "function") {
            return error(operationId, "native_array_required", "actorsToIgnore must be UE.NewArray(UE.Actor) or null");
        }
        const hitResults = UE.NewArray(UE.HitResult);
        const hitResultsRef = puerts.$ref(hitResults);
        const actorsRef = puerts.$ref(nativeActors);
        const hit = UE.MWSysFunctionLibrary.LineTraceByCollisionGroup(
            worldContextObject,
            collisionGroup,
            start,
            end,
            hitResultsRef,
            actorsRef,
            onlyBlock === true,
            isMulti === true,
        );
        return ok({
            hit,
            hitResults: puerts.$unref(hitResultsRef),
        });
    });
}

function playAmbientSound(sound, startTime, options) {
    const operationId = "audio.play-voice.event";
    const validSound = requireUObject(operationId, sound, "sound");
    if (!validSound.ok) {
        return validSound;
    }
    const transientIntent = requireTransientEventIntent(operationId, options);
    if (!transientIntent.ok) {
        return transientIntent;
    }
    if (options.assetReadyOrAsyncAccepted !== true) {
        return error(operationId, "asset_readiness_not_accepted", "Confirm asset readiness or explicitly accept the native asynchronous fallback");
    }
    const resolvedStartTime = startTime === undefined ? 0 : startTime;
    if (!Number.isFinite(resolvedStartTime) || resolvedStartTime < 0) {
        return error(operationId, "invalid_start_time", "startTime must be a finite non-negative number");
    }
    return callSafely(operationId, () => {
        sound.PlayVoice(resolvedStartTime);
        return ok(true);
    });
}

function stopAmbientSound(sound, options) {
    const operationId = "audio.stop-voice.event";
    const validSound = requireUObject(operationId, sound, "sound");
    if (!validSound.ok) {
        return validSound;
    }
    const transientIntent = requireTransientEventIntent(operationId, options);
    if (!transientIntent.ok) {
        return transientIntent;
    }
    return callSafely(operationId, () => {
        sound.StopVoice();
        return ok(true);
    });
}

function playParticle(particle, options) {
    const operationId = "particle.play.event";
    const validParticle = requireUObject(operationId, particle, "particle");
    if (!validParticle.ok) {
        return validParticle;
    }
    const transientIntent = requireTransientEventIntent(operationId, options);
    if (!transientIntent.ok) {
        return transientIntent;
    }
    if (options.assetReadyOrAsyncAccepted !== true) {
        return error(operationId, "asset_readiness_not_accepted", "Confirm particle readiness or explicitly accept the native fallback");
    }
    return callSafely(operationId, () => {
        particle.ParticlePlay();
        return ok(true);
    });
}

function stopParticle(particle, options) {
    const operationId = "particle.stop.event";
    const validParticle = requireUObject(operationId, particle, "particle");
    if (!validParticle.ok) {
        return validParticle;
    }
    const transientIntent = requireTransientEventIntent(operationId, options);
    if (!transientIntent.ok) {
        return transientIntent;
    }
    return callSafely(operationId, () => {
        particle.ParticleStop();
        return ok(true);
    });
}

module.exports = Object.freeze({
    apiVersion: API_VERSION,
    isUObjectValid,
    resolveServerWorldContext,
    makeTransform,
    spawnCharacterAuthority,
    createServerTriggerBoxAuthority,
    configureServerOnlyBoxTriggerComponent,
    bindServerActorBeginOverlap,
    resolveMWStaticMeshComponentFromEntity,
    bindServerMWComponentHitPair,
    bindLocalMWComponentHitPair,
    setMovableSceneComponentRelativeLocationLocal,
    destroyActorAuthority,
    getActorComponentByClass,
    getActorComponentsByClass,
    beginAddActorComponentByClass,
    finishAddedActorComponent,
    abortAddedActorComponent,
    addActorComponentByClass,
    destroyActorComponent,
    getActorLocation,
    getActorRotation,
    transformLocation,
    findLookAtRotation,
    setIndependentActorLocationAuthority,
    addPawnMovementInput,
    setCharacterLocation,
    getViewportSize,
    getText,
    setTextLocal,
    getInstanceInfo,
    getInstanceParentGuid,
    getInstanceSourceTransform,
    getInstanceMaterialSlotColor,
    lineTraceByCollisionGroup,
    playAmbientSound,
    stopAmbientSound,
    playParticle,
    stopParticle,
});

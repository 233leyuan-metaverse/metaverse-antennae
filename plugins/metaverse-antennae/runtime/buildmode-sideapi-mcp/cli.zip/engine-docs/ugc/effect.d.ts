// AI Export Declarations (effect) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category effect
   */
  enum EffectPlayState {
    Playing = "Play",
    Stopped = "Stop",
  }

  /**
   * 提供已标注的运行态能力
   * @category effect
   */
  class EffectComponent extends InternalLifeComponent implements ILazyWakeCapable {
    /**
     * 单 `Color` 参数的颜色值。
     * @pitfall 资源不含 `Color` 参数或参数扫描未完成时只保存配置；getter 运行值也可能为空。
     */
    color: mw.LinearColor;
    /**
     * `Color_01` 参数的颜色值。
     * @pitfall 仅在资源没有单 `Color` 且含 `Color_01` 时写入；getter 运行值可能为空。
     */
    color01: mw.LinearColor;
    /**
     * `Color_01` 参数随机范围的低值颜色。
     * @pitfall 仅在对应参数存在且 `colorRandom` 为 true 时参与写入；getter 运行值可能为空。
     */
    color01Min: mw.LinearColor;
    /**
     * `Color_02` 参数的颜色值。
     * @pitfall 仅在资源没有单 `Color` 且含 `Color_02` 时写入；getter 运行值可能为空。
     */
    color02: mw.LinearColor;
    /**
     * `Color_02` 参数随机范围的低值颜色。
     * @pitfall 仅在对应参数存在且 `colorRandom` 为 true 时参与写入；getter 运行值可能为空。
     */
    color02Min: mw.LinearColor;
    /**
     * 单 `Color` 参数随机范围的低值颜色。
     * @pitfall 仅在资源含 `Color` 且 `colorRandom` 为 true 时参与写入；getter 运行值可能为空。
     */
    colorMin: mw.LinearColor;
    /**
     * 是否对已识别的颜色参数使用高低值随机。
     *
     * 资源没有 `Color`、`Color_01` 或 `Color_02` 参数，或参数能力尚未准备完成时，写入只保存配置。
     */
    colorRandom: boolean;
    /**
     * 特效的引擎剔除距离。
     */
    cullDistance: number;
    /**
     * 特效资源 ID；空覆盖值时读取实体当前 GameObject 的资源 ID。
     * @pitfall setter 只更新组件保存的覆盖值，不会替换已经生成的 Effect GameObject 资源。
     */
    effectAssetId: string;
    /**
     * 当前特效播放状态。
     *
     * 写入 `Playing` 会请求循环播放，写入 `Stopped` 会强制停止；标记为槽位子特效的对象由父级管理，
     * 本组件不会自行切换。消费态客户端可能等待 Effect ready 后再执行播放。
     */
    playState: EffectPlayState;
    /**
     * 固定透明度，或随机透明度区间的上界。
     *
     * 编辑器约定范围为 0–1，setter 本身不裁剪输入；资源不含 `Transparency` 参数时只保存配置。
     */
    transparency: number;
    /**
     * 随机透明度区间的下界。
     *
     * 仅在 `transparencyRandom` 为 `true` 时发送给 Effect；编辑器约定范围为 0–1，setter 本身不裁剪输入。
     */
    transparencyMin: number;
    /**
     * 是否对已识别的 `Transparency` 参数使用区间随机。
     *
     * 资源不支持该参数或参数能力尚未准备完成时，写入只保存配置。
     */
    transparencyRandom: boolean;
  }

  /**
   * 管理特效挂件实体
   * @category effect
   */
  class EffectObjectCom extends InternalLifeComponent {
    /**
     * 按插槽内 0 基索引销毁特效挂件。
     * @pitfall pendantIndex 是指定插槽特效挂件列表中的 0 基索引。
     */
    destroyPendantByIndex(slotType: mw.HumanoidSlotType, pendantIndex: number): boolean;
    /**
     * 获取全部特效挂件实体。
     */
    getAllPendantsEntity(): Array<WeakRef<IEntity>>;
    /**
     * 获取指定插槽的特效挂件数量。
     */
    getPendantsCount(slotType: mw.HumanoidSlotType): number;
    /**
     * 获取指定插槽的特效挂件实体。
     */
    getPendantsEntity(slotType: mw.HumanoidSlotType): Array<WeakRef<IEntity>>;
  }

  /**
   * 管理实体插槽挂件
   * @category effect
   */
  class PendantComponent extends InternalLifeComponent {
    /**
     * 将游戏对象挂载到指定插槽。
     */
    attachToSlot(go: mw.GameObject, slotType: mw.HumanoidSlotType): void;
    /**
     * 清空并销毁所有插槽上的附加对象。
     * @pitfall 会销毁当前组件管理的全部挂件实体。
     */
    clearAttachObjects(): void;
    /**
     * 2026-06-18 17:02:00 原因：销毁外观挂件指令新增槽位参数；按指定槽位内 helper 合并顺序删除挂件，避免直接 destroy 后组件内部索引残留。
     * @pitfall pendantIndex 是指定槽位合并列表中的 0 基索引。
     */
    destroyPendantByIndexHelper(slotType: mw.HumanoidSlotType, pendantIndex: number): Promise<boolean>;
    /**
     * 将游戏对象从当前插槽卸下。
     */
    detachFromSlot(go: mw.GameObject): void;
    /**
     * 查找挂件对象所在的插槽。
     */
    findSlotByObject(pendantObj: mw.GameObject): mw.HumanoidSlotType.Hair | mw.HumanoidSlotType.Head | mw.HumanoidSlotType.LeftHead | mw.HumanoidSlotType.RightHead | mw.HumanoidSlotType.Glasses | mw.HumanoidSlotType.Eyes | mw.HumanoidSlotType.FaceOrnamental | mw.HumanoidSlotType.Mouse | mw.HumanoidSlotType.LeftShoulder | mw.HumanoidSlotType.RightShoulder | mw.HumanoidSlotType.LeftGlove | mw.HumanoidSlotType.RightGlove | mw.HumanoidSlotType.BackOrnamental | mw.HumanoidSlotType.LeftBack | mw.HumanoidSlotType.RightBack | mw.HumanoidSlotType.LeftHand | mw.HumanoidSlotType.RightHand | mw.HumanoidSlotType.LeftFoot | mw.HumanoidSlotType.RightFoot | mw.HumanoidSlotType.Buttocks | mw.HumanoidSlotType.Rings | mw.HumanoidSlotType.Nameplate | mw.HumanoidSlotType.ChatFrame | mw.HumanoidSlotType.Root | mw.HumanoidSlotType.LeftLowerArm | mw.HumanoidSlotType.RightLowerArm | mw.HumanoidSlotType.LeftThigh | mw.HumanoidSlotType.RightThigh | mw.HumanoidSlotType.LeftCalf | mw.HumanoidSlotType.RightCalf | mw.HumanoidSlotType.FirstpersonCamera | -1;
    /**
     * 获取所有挂件实体
     */
    getAllPendantsEntity(): Array<WeakRef<IEntity>>;
    /**
     * 获取所有挂件实体数量
     */
    getAllPendantsEntityCountHelper(): number;
    /**
     * 获取所有挂件实体
     */
    getAllPendantsEntityHelper(): Array<WeakRef<IEntity>>;
    /**
     * 获取某个插槽上的挂件数量
     */
    getPendantCount(slotType: mw.HumanoidSlotType): number;
    /**
     * 获取某个插槽上的挂件数量
     */
    getPendantsCountHelper(slotType: mw.HumanoidSlotType): number;
    /**
     * 获取某个插槽上的挂件
     */
    getPendantsEntity(slotType: mw.HumanoidSlotType): Array<WeakRef<IEntity>>;
    /**
     * 获取某个插槽上的挂件
     */
    getPendantsEntityHelper(slotType: mw.HumanoidSlotType): Array<WeakRef<IEntity>>;
    /**
     * 获取插槽的本地化名称。
     */
    getSlotName(slotType: mw.HumanoidSlotType): string;
    /**
     * 获取所有可用插槽。
     */
    getSlotTypes(): Array<mw.HumanoidSlotType>;
  }
}

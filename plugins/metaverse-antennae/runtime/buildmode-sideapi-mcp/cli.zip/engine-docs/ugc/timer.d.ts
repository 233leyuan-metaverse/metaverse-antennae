// AI Export Declarations (timer) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category timer
   */
  class EasyComponent extends InternalLifeComponent {
    "_referenceCount": number;
    readonly "asCharacter": mw.Character;
    readonly "asModel": mw.Model;
    readonly "binder": mw.GameObject;
    readonly "canEverTick": boolean;
    readonly "canPersistentSerializedIgnore": boolean;
    readonly "defaultLoc": mw.Vector;
    readonly "defaultRot": mw.Rotation;
    readonly "defaultScale": mw.Vector;
    getIsAuthority(): boolean;
    getOccupy(context?: any): any;
    readonly "gid": string;
    "id": string;
    readonly "internalBeselect": () => void;
    readonly "internalCloseDetailPanel": () => void;
    readonly "internalComponentAwake": () => void;
    readonly "internalComponentLateUpdate": (dt: number) => void;
    readonly "internalComponentStart": () => void;
    readonly "internalComponentUpdate": (dt: number) => void;
    readonly "internalDeselect": () => void;
    readonly "internalLiveBeselect": () => void;
    readonly "internalLiveDeselect": () => void;
    readonly "internalOnActivate": () => void;
    readonly "internalOnDeactivate": () => void;
    readonly "internalOnDestroy": () => void;
    readonly "internalOnGameModeChanged": (from: string, to: string) => void;
    readonly "internalOpenDetailPanel": () => void;
    "isAuthority": boolean;
    isPersistentSerialized(str: string): boolean;
    "myLoc": mw.Vector;
    "myRot": mw.Rotation;
    "myScale": mw.Vector;
    "myTransform": mw.Transform;
    "name": string;
    notSupportLazyInitInBuild(): boolean;
    readonly "obj": mw.GameObject;
    onDestroyed(): void;
    onEditorActiveUpdate(dt: number): void;
    onEditorSelectedUpdate(dt: number): void;
    onSyncPresetAfterDeserialize(): void;
    "ownership": ComponentOwnership;
    preSyncPreset(): void;
    "stateFlag": number;
    supportLazyInit(): boolean;
    "tickEnable": boolean;
    "useEditorSelectedUpdate": boolean;
    readonly "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, component: InternalComponent) => void;
  }
}

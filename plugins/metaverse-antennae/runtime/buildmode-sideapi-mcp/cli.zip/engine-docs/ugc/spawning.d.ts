// AI Export Declarations (spawning) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category spawning
   */
  class ObjectSpawnerConfig {
    "objectId": string;
    "owner": IEntity;
    "spawnOffset": mw.Vector;
    "spawnRotation": mw.Rotation;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category spawning
   */
  class ObjectSpawnerPositionConfig {
    "objectSpawnerTransformType": ObjectSpawnerTransformType;
    "owner": IEntity;
    "positionDisplayName": string;
    "spawnPosition": mw.Vector;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category spawning
   */
  enum ObjectSpawnerPositionMixType {
    FixedAndRandom = "FixedAndRandom",
    FixedAndSequential = "FixedAndSequential",
    Area = "Area",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category spawning
   */
  enum ObjectSpawnerPositionType {
    Fixed = "Fixed",
    Area = "Area",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category spawning
   */
  enum ObjectSpawnerTransformType {
    World = "World",
    Local = "Local",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category spawning
   */
  enum PointSpawnerPositionMode {
    RandomCycle = "RandomCycle",
    Sequential = "Sequential",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category spawning
   */
  interface SpawnedObjectInfo {
    "configIndex": number;
    "instance": IEntity;
    "isDestroyed": boolean;
    "removalWatchHandler"?: undefined | (() => void);
    "spawnTime": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category spawning
   */
  enum SpawnerCommand {
    StartSpawn = "StartSpawn",
    SpawnImmediately = "SpawnImmediately",
    StopSpawn = "StopSpawn",
    PauseSpawn = "PauseSpawn",
    ResumeSpawn = "ResumeSpawn",
    ResetSpawn = "ResetSpawn",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category spawning
   */
  enum SpawnerState {
    Idle = "Idle",
    Running = "Running",
    Waiting = "Waiting",
    Stopped = "Stopped",
    Paused = "Paused",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category spawning
   */
  enum SpawnMode {
    RandomCycle = "RandomCycle",
    Sequential = "Sequential",
    Group = "Group",
  }

  /**
   * 提供已标注的运行态能力
   * @category spawning
   */
  class ObjectSpawnerComponent extends InternalLifeComponent implements ILazyWakeCapable {
    /**
     * 统计内部列表中尚未标记销毁且仍有实体引用的对象数量。
     */
    readonly aliveObjectCount: number;
    /**
     * 自动重置（无人附近且久未刷新时）。
     * 2026-05-07 12:00:00 原因：补充通俗说明，方便创作者理解面板开关。
     * 开启后：若很久都没有刷出新物体，并且附近一段时间内也没有玩家（或同类可被检测到的角色），刷怪点会像刚放置时一样自动回到初始状态，等人再来会重新按规则刷新；地图里点了暂停刷新时，这段等待不会继续计时。
     */
    autoResetSpawnerWhenNoPlayerNearby: boolean;
    /**
     * 组件激活时是否自动开始刷新。
     * @pitfall 运行中修改不会立即开始或停止，需配合 startSpawning/stopSpawning。
     */
    autoStart: boolean;
    /**
     * 当前服务端刷新状态。
     */
    readonly currentState: SpawnerState;
    /**
     * 请求销毁本刷新器记录的所有已生成物体并清空内部列表。
     * 仅服务端生效；具体销毁事件由实体移除回调继续处理。
     */
    destroyAllSpawnedObjects(): void;
    /**
     * 是否输出刷新器调试日志。
     */
    enableDebugLog: boolean;
    /**
     * 是否复用生成实体的对象池。
     * @pitfall 运行中切换只影响后续生成/回收，不会迁移当前存活对象。
     */
    enablePool: boolean;
    /**
     * 同时存活的生成对象数量上限。
     */
    maxExistObjects: number;
    /**
     * 自上次重置起允许生成的总数量上限，负数表示不限。
     * @pitfall 放宽上限可能自动恢复因达到上限而停止的刷新器。
     */
    maxTotalSpawns: number;
    /**
     * 待生成物体配置列表。
     * @pitfall 返回内部可变数组；运行中修改配置不会自动重置已生成对象或计数。
     */
    readonly objectConfigs: Array<ObjectSpawnerConfig>;
    /**
     * 已登记生成对象被移除并完成状态更新时触发。
     * @pitfall objectInfo 是内部运行时记录；监听者不应改写其中字段。
     */
    readonly onObjectDestroyed: UDelegate<(objectInfo: SpawnedObjectInfo) => void>;
    /**
     * 对象成功生成并登记后触发。
     * @pitfall objectInfo 是内部运行时记录；监听者不应改写其中字段。
     */
    readonly onObjectSpawned: UDelegate<(objectInfo: SpawnedObjectInfo) => void>;
    /**
     * 单个或整组生成流程在生成前发现总生成数量达到限制时触发。
     * 重置后再次达到限制时可再次触发；事件无参数，监听方必须在自身生命周期结束时取消订阅。
     */
    readonly onSpawnLimitReached: UDelegate<() => void>;
    /**
     * 刷新器状态实际发生变化时触发，回调依次提供旧状态和新状态。
     * 状态相同的写入不会触发；重置并再次启动时可重复触发。
     * 该事件没有独立失败或取消载荷。监听方必须在自身生命周期结束时取消订阅。
     */
    readonly onStateChanged: UDelegate<(oldState: SpawnerState, newState: SpawnerState) => void>;
    /**
     * 暂停运行中或等待中的刷新器并暂停生成计时器。
     * 仅服务端生效；其他状态调用不产生变化。
     */
    pauseSpawning(): void;
    /**
     * 固定位置生成配置列表。
     * @pitfall 返回内部可变数组；调用方修改时需同时维护配置 owner 和运行中状态。
     */
    readonly positionConfigs: Array<ObjectSpawnerPositionConfig>;
    /**
     * 固定点位的随机循环或顺序生成模式。
     * @pitfall 直接写入不会同步 `positionType_mix`，通常应优先设置组合位置类型。
     */
    positionMode: PointSpawnerPositionMode;
    /**
     * 实际生成位置类型。
     * @pitfall 直接写入不会同步 `positionType_mix`，通常应优先设置组合位置类型。
     */
    positionType: ObjectSpawnerPositionType;
    /**
     * 面板使用的组合位置类型，写入会同步底层位置类型和固定点顺序模式。
     */
    positionType_mix: ObjectSpawnerPositionMixType;
    /**
     * 根据总生成上限与累计生成数量计算剩余额度。
     */
    readonly remainingSpawns: number;
    /**
     * 重置刷新器。
     * 仅服务端生效；停止计时、销毁已生成对象、清零累计与顺序索引，并把状态切回空闲。
     */
    resetSpawning(): void;
    /**
     * 恢复已暂停的刷新器与生成计时器。
     * 仅服务端生效；非暂停状态调用不产生变化。
     */
    resumeSpawning(): void;
    /**
     * 写入一次性刷新控制命令。
     * @pitfall getter 固定返回 null；该属性应只用于写入命令，不能读取当前命令。
     */
    spawnCommand: SpawnerCommand;
    /**
     * 立即执行一次当前生成计时器流程。
     * 仅服务端且当前状态为运行中时可能生成；没有对象配置或状态不满足时不产生生成结果。
     */
    spawnImmediately(): void;
    /**
     * 生成间隔秒数，运行或等待状态修改时会重启计时器。
     */
    spawnInterval: number;
    /**
     * 对象配置的随机、顺序或整组生成模式。
     */
    spawnMode: SpawnMode;
    /**
     * 开始刷新。
     * 仅服务端生效；没有对象配置时不改变状态。成功进入运行态后启动生成计时器与无人自动重置监视。
     */
    startSpawning(): void;
    /**
     * 停止刷新并清除生成计时器。
     * @pitfall 仅服务端生效；传 false 会保留无人自动重置监视器，业务调用通常使用默认值 true。
     */
    stopSpawning(releaseInactivityWatcher?: boolean): void;
    /**
     * 获取生成计时器进度占位值。
     * 当前实现使用原生调度句柄且未记录开始时间，因此固定返回 `0`。
     */
    readonly timerProgress: number;
    /**
     * 自上次重置以来成功登记的累计生成数量。
     */
    readonly totalSpawnedCount: number;
  }
}

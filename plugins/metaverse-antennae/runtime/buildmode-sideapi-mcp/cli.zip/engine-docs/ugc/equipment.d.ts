// AI Export Declarations (equipment) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   */
  class CustomWidgetSelector {
    "childList": Array<CustomWidgetSelector_Child>;
    "controlAllWidget": boolean;
    "customCanvasGuid": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   */
  class CustomWidgetSelector_Child {
    "canvasGuid": string;
    "customWidgetGuid": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   */
  class EquipmentShowUIAttribute {
    readonly "EquipmentHideUIAttribute": Array<CustomWidgetSelector>;
    readonly "EquipmentShowUIAttribute": Array<CustomWidgetSelector>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   */
  class Fire {
    "cartridges": number;
    "fireRate": number;
    getSpreadDirection(baseDir: mw.Vector, index: number): mw.Vector;
    "range": number;
    "range_m2cm": number;
    "shotAnimation": string;
    "speed": number;
    "spreadAngle": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   */
  enum FireType {
    JustFire = 0,
    AimedFire = 1,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   */
  enum GripMethod {
    RightHand = 0,
    AllHands = 1,
    Shoulder = 2,
    Hip = 3,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   */
  class Projectile {
    "collisionCheckMethod": ProjectileCollisionCheckMethod;
    "projectileHitEffect": string;
    "projectileMeshId": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   */
  class StyleAnimation {
    "equip": string;
    "equipSpeed": number;
    "runSpeed": number;
    "style": string;
    "styleName": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   */
  enum WeaponActivateType {
    None = "None",
    WhenEnemyInRange = "WhenEnemyInRange",
    PlayerControlled = "PlayerControlled",
  }

  /**
   * 查询和使用装备实例
   * @category equipment
   */
  class EquipmentComponent extends ItemTemplateComponent {
    /**
     * 装备的基础挂点、技能和效果配置。
     */
    readonly equipmentBaseAttribute: EquipmentBaseAttribute;
    /**
     * 装备组件销毁时触发。
     */
    readonly onEquipmentDestroy: UDelegate<(entity: IEntity, equipment: EquipmentComponent) => void>;
    /**
     * 当前装备持有者实体。
     */
    readonly ownerEntity: IEntity;
    /**
     * 按当前基础属性重新挂载已装备对象。
     */
    refreshAttachment(): boolean;
    /**
     * 由执行者使用并装备当前物品。
     * @pitfall 使用失败时当前装备实体会被销毁。
     */
    use(executor: IEntity): Promise<boolean>;
  }

  /**
   * 管理实体的武器装备、卸下、查询和运行事件
   * @category equipment
   */
  class EquipmentMgrComponent extends UComponent {
    /**
     * 使用先前保存的权重恢复当前热武器 IK。
     */
    activeIK(weight: number): void;
    /**
     * 暂停当前热武器 IK，并返回之后恢复所需的权重。
     * @pitfall 无武器、非热武器或缺少相关组件时返回 `-1`，不会改变 IK。
     */
    deactivateIK(): number;
    /**
     * 装备一个来自背包流程的武器实体；槽位达到上限时先卸下当前武器。
     * @sideEffect 更新装备槽并注册武器销毁、攻击与击杀监听。
     * @pitfall 非服务端调用命中入口 guard 后静默返回，不会装备武器。
     * @constraint 当前容量上限为 1；继续装备会先卸下 0 号槽位。
     * @returnsNote 成功结果仅为 `true`；错误侧调用没有布尔失败值。
     */
    equip(weaponEntity: IEntity): Promise<undefined | true>;
    /**
     * 0 号槽位中当前装备的武器实体句柄。
     * @pitfall 当前 TypeScript 签名声明为非空 `IEntity`，但无装备时运行值为 `null`。
     * @returnsNote 没有有效 0 号槽位时实际返回 `null`。
     */
    readonly equipmentEntity: IEntity;
    /**
     * 为不经过背包流程的 NPC 或模型装备武器实体。
     * @sideEffect 更新装备槽并注册武器销毁、攻击与击杀监听。
     * @pitfall 非服务端调用命中入口 guard 后静默返回，不会装备武器。
     * @constraint 当前容量上限为 1；继续装备会先卸下 0 号槽位。
     * @returnsNote 成功结果仅为 `true`；错误侧调用没有布尔失败值。
     */
    equipWithoutInventory(weaponEntity: IEntity): Promise<undefined | true>;
    /**
     * 查询指定装备槽中的装备组件。
     * @pitfall 索引越界、武器实体不存在或组件缺失时实际返回 `null`，但当前签名声明为非空。
     */
    getEquipmentComponent(index: number): EquipmentComponent;
    /**
     * 查询指定槽位中的武器实体句柄。
     * @pitfall 当前 TypeScript 签名声明为非空 `IEntity`，但越界时运行值为 `null`。
     * @returnsNote 索引越界时记录日志并返回 `null`。
     */
    getEquipmentEntity(index: number): IEntity;
    /**
     * 当前弹匣内的弹量。写入新值时触发弹量变化事件，相同值不重复触发。
     */
    inMagazine: number;
    /**
     * 检查指定装备槽是否有武器；索引越界时返回 false。
     */
    isEquipped(index: number): boolean;
    /**
     * 按背包物品 GUID 检查是否已装备对应武器。
     */
    isEquippedByGuid(guid: string): boolean;
    /**
     * 是否正在执行装备武器流程。
     */
    readonly isEquipping: boolean;
    /**
     * 当前弹匣弹量变化时广播新的弹量。
     */
    readonly onAmmoChanged: UDelegate<(curNum: number) => void>;
    /**
     * 当前武器攻击到目标时广播所属实体、目标实体与武器实体。
     * @pitfall 武器攻击监听仅在服务端装备路径注册；客户端订阅不会收到该路径的广播。
     */
    readonly onWeaponAttackedTarget: UDelegate<(source: IEntity, target: IEntity, weaponEntity: IEntity) => void>;
    /**
     * 装备或卸下武器时广播所属实体与武器实体。
     * @pitfall 卸下武器时第二个回调参数实际为 `null`，但现有回调签名声明为非空 `IEntity`。
     */
    readonly onWeaponChanged: UDelegate<(source: IEntity, weaponEntity: IEntity) => void>;
    /**
     * 当前武器击杀目标时广播所属实体、目标实体与武器实体。
     * @pitfall 武器击杀监听仅在服务端装备路径注册；客户端订阅不会收到该路径的广播。
     */
    readonly onWeaponKilledTarget: UDelegate<(source: IEntity, target: IEntity, weaponEntity: IEntity) => void>;
    /**
     * 重新应用当前武器挂载，并为热武器恢复 IK 状态。
     * @pitfall 纯客户端调用、无 0 号槽位或缺少武器组件时返回 `false`，不会刷新挂载。
     */
    refreshCurrentWeaponAttachment(): boolean;
    /**
     * 在 Animator 重建后重播当前武器的装备姿态。
     * @pitfall 纯客户端调用、无 0 号槽位或缺少装备组件时返回 `false`，不会刷新姿态。
     */
    refreshCurrentWeaponStance(): boolean;
    /**
     * 卸下指定槽位的武器，并可选择将对应背包物品丢到场景。
     * @sideEffect 移除武器监听、清空槽位，并按参数更新或移除背包物品。
     * @pitfall 非服务端调用静默返回；不会卸下武器，也不会返回 `false`。
     * @pitfall 成功路径没有 `true`，且未等待内部异步卸下帮助方法完成。
     * @returnsNote 仅前置校验失败返回 `false`；成功与错误侧调用均返回 `undefined`。
     */
    unEquip(index: number, dropDown?: boolean, bModifyInventoryKv?: boolean): Promise<undefined | false>;
  }

  /**
   * 提供已标注的运行态能力
   * @category equipment
   */
  class EquipmentSlotComponent extends InternalLifeComponent {
    /**
     * 敌人接近激活模式使用的索敌半径，单位厘米。写入后刷新行为树参数。
     */
    enemyInRadiusNew: number;
    /**
     * 自动攻击时是否朝向敌人。写入后刷新行为树朝向模式。
     */
    isFacingEnemy: boolean;
    /**
     * 暂停或继续敌人接近模式的已注册攻击行为；其他模式或未注册时不执行。
     */
    pauseOrResume(bPause: boolean): void;
    /**
     * 武器槽附加在武器主握点之后的额外挂载偏移。
     * @pitfall 非 `mw.Transform` 输入会记录错误并被忽略；getter 在尚未初始化时可能返回 `null`。
     */
    transformOffset: mw.Transform;
    /**
     * 武器激活方式。写入后刷新服务端行为树状态。
     */
    weaponActivateType: WeaponActivateType;
  }

  /**
   * 提供已标注的运行态能力
   * @category equipment
   */
  class HotWeaponComponent extends WeaponComponent {
    /**
     * 武器挂载使用的人形或非人形槽位。
     */
    attachBoneName: mw.HumanoidSlotType.Hair | mw.HumanoidSlotType.Head | mw.HumanoidSlotType.LeftHead | mw.HumanoidSlotType.RightHead | mw.HumanoidSlotType.Glasses | mw.HumanoidSlotType.Eyes | mw.HumanoidSlotType.FaceOrnamental | mw.HumanoidSlotType.Mouse | mw.HumanoidSlotType.LeftShoulder | mw.HumanoidSlotType.RightShoulder | mw.HumanoidSlotType.LeftGlove | mw.HumanoidSlotType.RightGlove | mw.HumanoidSlotType.BackOrnamental | mw.HumanoidSlotType.LeftBack | mw.HumanoidSlotType.RightBack | mw.HumanoidSlotType.LeftHand | mw.HumanoidSlotType.RightHand | mw.HumanoidSlotType.LeftFoot | mw.HumanoidSlotType.RightFoot | mw.HumanoidSlotType.Buttocks | mw.HumanoidSlotType.Rings | mw.HumanoidSlotType.Nameplate | mw.HumanoidSlotType.ChatFrame | mw.HumanoidSlotType.Root | mw.HumanoidSlotType.LeftLowerArm | mw.HumanoidSlotType.RightLowerArm | mw.HumanoidSlotType.LeftThigh | mw.HumanoidSlotType.RightThigh | mw.HumanoidSlotType.LeftCalf | mw.HumanoidSlotType.RightCalf | mw.HumanoidSlotType.FirstpersonCamera | mw.NonHumanoidSlotType.Root | mw.NonHumanoidSlotType.Chest | mw.NonHumanoidSlotType.UpperSpine | mw.NonHumanoidSlotType.LowerSpine | mw.NonHumanoidSlotType.Neck | mw.NonHumanoidSlotType.Head | mw.NonHumanoidSlotType.FrontalLeftFoot | mw.NonHumanoidSlotType.FrontalRightFoot | mw.NonHumanoidSlotType.RearLeftFoot | mw.NonHumanoidSlotType.RearRightFoot | mw.NonHumanoidSlotType.Tail | mw.NonHumanoidSlotType.RightHand | mw.NonHumanoidSlotType.LeftHand | mw.NonHumanoidSlotType.HumanoidHead | mw.NonHumanoidSlotType.HumanoidChest | mw.NonHumanoidSlotType.DorsalFin | mw.NonHumanoidSlotType.LeftFin | mw.NonHumanoidSlotType.RightFin | mw.NonHumanoidSlotType.RightWing | mw.NonHumanoidSlotType.LeftWing | mw.NonHumanoidSlotType.ExtraRightFoot1 | mw.NonHumanoidSlotType.ExtraRightFoot2 | mw.NonHumanoidSlotType.ExtraRightFoot3 | mw.NonHumanoidSlotType.ExtraRightFoot4 | mw.NonHumanoidSlotType.ExtraLeftFoot1 | mw.NonHumanoidSlotType.ExtraLeftFoot2 | mw.NonHumanoidSlotType.ExtraLeftFoot3 | mw.NonHumanoidSlotType.ExtraLeftFoot4 | mw.NonHumanoidSlotType.Mouth | mw.NonHumanoidSlotType.RightEye | mw.NonHumanoidSlotType.LeftEye | mw.NonHumanoidSlotType.Crest | mw.NonHumanoidSlotType.ExtraRightTail1 | mw.NonHumanoidSlotType.ExtraRightTail2 | mw.NonHumanoidSlotType.ExtraLeftTail1 | mw.NonHumanoidSlotType.ExtraLeftTail2 | mw.NonHumanoidSlotType.RearRightWing | mw.NonHumanoidSlotType.RearLeftWing | mw.NonHumanoidSlotType.HumanoidLeftEye | mw.NonHumanoidSlotType.HumanoidRightEye | mw.NonHumanoidSlotType.HumanoidMouth | mw.NonHumanoidSlotType.HumanoidPelvis | mw.NonHumanoidSlotType.HumanoidSpine | mw.NonHumanoidSlotType.HumanoidNeck | mw.NonHumanoidSlotType.FrontTentacle | mw.NonHumanoidSlotType.RearTentacle | mw.NonHumanoidSlotType.LeftTentacle1 | mw.NonHumanoidSlotType.LeftTentacle2 | mw.NonHumanoidSlotType.LeftTentacle3 | mw.NonHumanoidSlotType.RightTentacle1 | mw.NonHumanoidSlotType.RightTentacle2 | mw.NonHumanoidSlotType.RightTentacle3;
    /**
     * 是否允许拾取后自动使用该武器。
     */
    autoUse: boolean;
    /**
     * 每次射击发出的弹丸数量。
     */
    cartridges: number;
    /**
     * 暴击概率的百分比数值，面板范围为 0 到 100。
     */
    criticalChance: number;
    /**
     * 触发暴击时使用的伤害倍数。
     */
    criticalMultiplier: number;
    /**
     * 每次命中的基础伤害值。
     */
    damage: number;
    /**
     * 武器丢弃后的自动销毁时间，单位秒。
     */
    dropDestroyTime: number;
    /**
     * 是否启用辅助瞄准。
     */
    enableAimAid: boolean;
    /**
     * 装备时的 UI 显隐配置。
     * @pitfall 返回内部可变配置对象，修改集合后需调用方自行保证 UI 状态一致。
     */
    equipmentUIAttribute: EquipmentShowUIAttribute;
    /**
     * 当前射击参数对象。
     * @pitfall 返回内部可变对象；直接写字段可能绕过细粒度 setter 的校验和同步。
     */
    readonly fire: Fire;
    /**
     * 射击频率，使用面板的每分钟发射数数值。
     */
    fireRate: number;
    /**
     * 热武器的射击方式。
     */
    fireType: FireType;
    /**
     * 武器持握方式。
     */
    gripMethod: GripMethod;
    /**
     * 击退过程持续时间，单位秒。
     */
    knockBackDuration: number;
    /**
     * 命中时的击退距离，单位厘米。
     */
    knockBackMagnitude: number;
    /**
     * 按当前模型资源与握持方式重新加载仓库内的武器配置。
     * @pitfall 找不到匹配配置时静默返回，不会修改现有参数。
     */
    loadWeaponConfig(): void;
    /**
     * 弹匣容量；写入时同时把当前弹量重置为该值。
     */
    magazineSize: number;
    /**
     * 武器使用的模型资源 ID；写入后异步下载并应用模型。
     */
    meshID: string;
    /**
     * 枪口开火特效资源 ID。
     */
    muzzleEffect: string;
    /**
     * 武器本地坐标中的枪口位置，用于弹道起点和开火特效原点。
     */
    muzzlePointPosition: mw.Vector;
    /**
     * 武器本地坐标中的枪口旋转，用于弹道和开火特效朝向。
     */
    muzzlePointRotation: mw.Rotation;
    /**
     * 当前枪口点的世界坐标。
     */
    readonly muzzlePosition: mw.Vector;
    /**
     * 当前枪口朝向的世界旋转。
     */
    readonly muzzleRotation: mw.Rotation;
    /**
     * 武器本地坐标中的握持点位置；写入成功后刷新已装备武器的挂载偏移。
     */
    primaryGripPointPosition: mw.Vector;
    /**
     * 武器握持点的本地旋转；写入成功后刷新已装备武器的挂载偏移。
     */
    primaryGripPointRotation: mw.Rotation;
    /**
     * 当前弹丸参数对象。
     * @pitfall 返回内部可变对象；直接写字段可能绕过细粒度 setter 的校验和同步。
     */
    readonly projectile: Projectile;
    /**
     * 兼容保留的弹丸飞行资源 ID。
     * @deprecated 当前射击实现已由实体弹切换为射线，该字段在属性面板隐藏。
     */
    projectileEffect: string;
    /**
     * 弹丸命中特效资源 ID。
     */
    projectileHitEffect: string;
    /**
     * 射击射程，单位厘米。
     */
    range: number;
    /**
     * 换弹动画资源 ID。
     */
    reloadAnimation: string;
    /**
     * 完成一次换弹所需时间，单位秒。
     */
    reloadTime: number;
    /**
     * 射击动画资源 ID。
     */
    shotAnimation: string;
    /**
     * 多弹丸射击的总散射角度，单位度。
     */
    spreadAngle: number;
    /**
     * 后坐力强度的百分比数值。
     */
    strength: number;
  }

  /**
   * 提供已标注的运行态能力
   * @category equipment
   */
  class MeleeWeaponComponent extends WeaponComponent {
    /**
     * 近战武器使用的技能资源 ID。
     */
    abilityAsset: string;
    /**
     * 武器挂载使用的人形或非人形槽位。
     */
    attachBoneName: mw.HumanoidSlotType.Hair | mw.HumanoidSlotType.Head | mw.HumanoidSlotType.LeftHead | mw.HumanoidSlotType.RightHead | mw.HumanoidSlotType.Glasses | mw.HumanoidSlotType.Eyes | mw.HumanoidSlotType.FaceOrnamental | mw.HumanoidSlotType.Mouse | mw.HumanoidSlotType.LeftShoulder | mw.HumanoidSlotType.RightShoulder | mw.HumanoidSlotType.LeftGlove | mw.HumanoidSlotType.RightGlove | mw.HumanoidSlotType.BackOrnamental | mw.HumanoidSlotType.LeftBack | mw.HumanoidSlotType.RightBack | mw.HumanoidSlotType.LeftHand | mw.HumanoidSlotType.RightHand | mw.HumanoidSlotType.LeftFoot | mw.HumanoidSlotType.RightFoot | mw.HumanoidSlotType.Buttocks | mw.HumanoidSlotType.Rings | mw.HumanoidSlotType.Nameplate | mw.HumanoidSlotType.ChatFrame | mw.HumanoidSlotType.Root | mw.HumanoidSlotType.LeftLowerArm | mw.HumanoidSlotType.RightLowerArm | mw.HumanoidSlotType.LeftThigh | mw.HumanoidSlotType.RightThigh | mw.HumanoidSlotType.LeftCalf | mw.HumanoidSlotType.RightCalf | mw.HumanoidSlotType.FirstpersonCamera | mw.NonHumanoidSlotType.Root | mw.NonHumanoidSlotType.Chest | mw.NonHumanoidSlotType.UpperSpine | mw.NonHumanoidSlotType.LowerSpine | mw.NonHumanoidSlotType.Neck | mw.NonHumanoidSlotType.Head | mw.NonHumanoidSlotType.FrontalLeftFoot | mw.NonHumanoidSlotType.FrontalRightFoot | mw.NonHumanoidSlotType.RearLeftFoot | mw.NonHumanoidSlotType.RearRightFoot | mw.NonHumanoidSlotType.Tail | mw.NonHumanoidSlotType.RightHand | mw.NonHumanoidSlotType.LeftHand | mw.NonHumanoidSlotType.HumanoidHead | mw.NonHumanoidSlotType.HumanoidChest | mw.NonHumanoidSlotType.DorsalFin | mw.NonHumanoidSlotType.LeftFin | mw.NonHumanoidSlotType.RightFin | mw.NonHumanoidSlotType.RightWing | mw.NonHumanoidSlotType.LeftWing | mw.NonHumanoidSlotType.ExtraRightFoot1 | mw.NonHumanoidSlotType.ExtraRightFoot2 | mw.NonHumanoidSlotType.ExtraRightFoot3 | mw.NonHumanoidSlotType.ExtraRightFoot4 | mw.NonHumanoidSlotType.ExtraLeftFoot1 | mw.NonHumanoidSlotType.ExtraLeftFoot2 | mw.NonHumanoidSlotType.ExtraLeftFoot3 | mw.NonHumanoidSlotType.ExtraLeftFoot4 | mw.NonHumanoidSlotType.Mouth | mw.NonHumanoidSlotType.RightEye | mw.NonHumanoidSlotType.LeftEye | mw.NonHumanoidSlotType.Crest | mw.NonHumanoidSlotType.ExtraRightTail1 | mw.NonHumanoidSlotType.ExtraRightTail2 | mw.NonHumanoidSlotType.ExtraLeftTail1 | mw.NonHumanoidSlotType.ExtraLeftTail2 | mw.NonHumanoidSlotType.RearRightWing | mw.NonHumanoidSlotType.RearLeftWing | mw.NonHumanoidSlotType.HumanoidLeftEye | mw.NonHumanoidSlotType.HumanoidRightEye | mw.NonHumanoidSlotType.HumanoidMouth | mw.NonHumanoidSlotType.HumanoidPelvis | mw.NonHumanoidSlotType.HumanoidSpine | mw.NonHumanoidSlotType.HumanoidNeck | mw.NonHumanoidSlotType.FrontTentacle | mw.NonHumanoidSlotType.RearTentacle | mw.NonHumanoidSlotType.LeftTentacle1 | mw.NonHumanoidSlotType.LeftTentacle2 | mw.NonHumanoidSlotType.LeftTentacle3 | mw.NonHumanoidSlotType.RightTentacle1 | mw.NonHumanoidSlotType.RightTentacle2 | mw.NonHumanoidSlotType.RightTentacle3;
    /**
     * 当前攻击动画资源 ID。
     */
    readonly attackAnimation: string;
    /**
     * 近战武器的攻击方式；写入时同步选择默认劈砍或戳刺动画。
     */
    attackMethod: AttackMethod;
    /**
     * 近战攻击速度倍率。
     */
    attackSpeed: number;
    /**
     * 是否允许拾取后自动使用该武器。
     */
    autoUse: boolean;
    /**
     * 当前绑定技能的展示名称。
     * @pitfall setter 当前为空且 getter 返回本地化展示名，不可用于资源 ID 往返；配置技能请使用 abilityAsset。
     */
    bindAbility: string;
    /**
     * 暴击概率的百分比数值，面板范围为 0 到 100。
     */
    criticalChance: number;
    /**
     * 触发暴击时使用的伤害倍数。
     */
    criticalMultiplier: number;
    /**
     * 每次命中的基础伤害值。
     */
    damage: number;
    /**
     * 装备时的 UI 显隐配置。
     * @pitfall 返回内部可变配置对象，修改集合后需调用方自行保证 UI 状态一致。
     */
    equipmentUIAttribute: EquipmentShowUIAttribute;
    /**
     * 命中特效资源 ID。
     */
    hitEffect: string;
    /**
     * 查询近战武器是否启用击退；当前实现固定返回 true。
     */
    isKnockBackEnabled(): boolean;
    /**
     * 击退过程持续时间，单位秒。
     */
    knockBackDuration: number;
    /**
     * 命中时的击退距离，单位厘米。
     */
    knockBackMagnitude: number;
    /**
     * 近战武器使用的模型资源 ID；写入后异步下载并应用模型。
     */
    meshID: string;
    /**
     * 2026-06-09 16:10:00 重构（IKF-009）；原因：挂载偏移位置指令由 IKF-008 的 X/Y/Z 三个 NumberInput 回退为单个 editButton（mw.Vector），
     * 指令侧用偏移量值源 GetMountOffsetPosition（保存选中实体世界坐标为基准、存相对偏移、默认 0、可序列化），既恢复观感又规避 IKF-007 世界坐标巨值与 IKF-008① 不保存。
     * 挂载偏移位置——映射 equipmentBaseAttribute.primaryGripPoint.position（本地挂载偏移）；仅可指令、不在面板展示（面板用 EditButton 可视化编辑）。
     */
    primaryGripPointPosition: mw.Vector;
    /**
     * 2026-06-08 19:00:00 新增（IKF-003）；原因：让服务端 AI 能通过指令设置近战挂载偏移旋转，对齐热武器 HWP-016。
     * 挂载偏移旋转——映射 equipmentBaseAttribute.primaryGripPoint.rotation；仅可指令、不在面板展示。
     */
    primaryGripPointRotation: mw.Rotation;
    /**
     * 当前近战打击检测配置。
     * @pitfall 返回内部可变对象，直接修改可能绕过组件 setter 的校验。
     */
    readonly strike: MeleeStrike;
    /**
     * 2026-06-10 16:30:00 新增（MSB-AI-001）；原因：让服务端 AI（E:\AIServer）能通过 path+value 指令设置近战攻击检测盒中心偏移，与握持点 primaryGripPointPosition 同模式（既能面板可视化、又能指令）。
     * 攻击盒中心偏移——映射 _strike.strikeInfo.start（OBB 中心相对攻击者/角色的局部偏移，单位 cm，可负）；仅可指令、不在面板展示（面板用「攻击碰撞器」EditButton 可视化编辑，二者写回同一份 strikeInfo）。
     * @pitfall strikeInfo 缺失时 getter 实际返回空值，但现有公开声明仍为非空 Vector。
     */
    strikeBoxOffset: mw.Vector;
    /**
     * 2026-06-10 16:30:00 新增（MSB-AI-001）；原因：让服务端 AI 能通过 path+value 指令设置近战攻击检测盒三轴半径，调整攻击命中范围。
     * 攻击盒三轴半径——映射 _strike.strikeInfo.size（单位米/半径，须 ≥ 0；运行时 GA_MeleeWeaponAbility.initializeWeapon() 会 ×100 转 cm）；仅可指令、不在面板展示。
     * @pitfall strikeInfo 缺失时 getter 实际返回空值，但现有公开声明仍为非空 Vector；负分量写入时会被夹到 0。
     */
    strikeBoxSize: mw.Vector;
    /**
     * 武器装备与移动时使用的姿态动画配置。
     */
    styleAnimation: StyleAnimation;
    /**
     * 兼容保留的武器自身特效资源 ID。
     * @pitfall setter 当前不写入字段，设置后不会生效；该能力已由挂件组件替代。
     */
    weaponEffect: string;
    /**
     * 兼容武器特效的局部变换。
     * @pitfall setter 参数缺少显式类型，AI 声明按分析结果继续生成；特效字段当前已被屏蔽。
     */
    weaponEffectTransform: mw.Transform;
  }
}

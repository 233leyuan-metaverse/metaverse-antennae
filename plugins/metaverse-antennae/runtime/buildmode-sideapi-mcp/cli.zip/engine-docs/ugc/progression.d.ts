// AI Export Declarations (progression) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * 提供已标注的运行态能力
   * @category progression
   */
  class LevelComponent extends InternalLifeComponent {
    /**
     * 增加正数经验；达到升级阈值时提升等级并按当前实现清零剩余经验。
     */
    addExp(val: number): void;
    /**
     * 当前经验值；写入后立即检查升级阈值。
     */
    exp: number;
    /**
     * 从经验配置表获取最大等级；配置不可用时返回 100。
     */
    getMaxLevel(): number;
    /**
     * 初始等级；写入值超过配置最大等级时会夹紧到最大等级。
     */
    initLevel: number;
    /**
     * 当前等级，只能通过经验或升级操作改变。
     */
    level: number;
    /**
     * 当前等级未达到上限时提升一级。
     */
    levelUp(): void;
    /**
     * 当前等级升级所需经验；配置不可用或已达上限时返回 `Number.MAX_SAFE_INTEGER`。
     */
    readonly maxExp: number;
  }
}

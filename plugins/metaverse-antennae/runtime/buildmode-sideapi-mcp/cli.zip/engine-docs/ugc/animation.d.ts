// AI Export Declarations (animation) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  type AnimationComponentEndEvent = UDelegate<(handler: number, isInterrupted: boolean) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  type AnimationComponentEvent = UDelegate<(handler: number) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  type AnimationHandler = number;

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  interface AnimationLayerOwner {
    addAnimator(animator: Animator, layer: IAnimationLayer): boolean;
    "entity": IEntity;
    isReplicatedAnimatorRemovedByServer(handler: AnimationHandler): boolean;
    notifyLayerBusy(layer: IAnimationLayer): void;
    removeAnimator(animator: Animator, layer: IAnimationLayer): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  enum AnimationLayerType {
    MWState = 0,
    Stance = 1,
    SubStance = 2,
    Gesture = 3,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  class Animator {
    "assetId": string;
    "autoBlendSlot": boolean;
    "blendMode": PlayableWarpMode;
    "disableIK": boolean;
    "duration": number;
    "handler": AnimationHandler;
    readonly "layer": AnimationLayerType;
    "predicatePlayerId": number;
    "priority": number;
    toString(): string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  interface IAnimationLayer {
    "isLowerBusy": boolean;
    "isUpperBusy": boolean;
    removeAnimatorBecauseEnd(animator: Animator): boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  interface Inline_bbfd400f76 {
    "modifierValue"?: undefined | null | string;
    "readiness": "known" | "pending";
  }

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  enum PlayableWarpMode {
    WholeBody = 0,
    Upper = 1,
    Lower = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  enum SecondAssetType {
    Picture = 200,
    StaticMesh = 4000,
    Model = 5000,
    Model1 = 5001,
    Model2 = 5002,
    Model3 = 5003,
    Model4 = 5004,
    Organ = 5005,
    Effect = 5006,
    Effect1 = 5007,
    Effect2 = 5008,
    Role = 5009,
    Tetrapods = 5010,
    Texture = 5015,
    Texture1 = 5016,
    Gear = 5017,
    Sound = 5018,
    Sound1 = 5019,
    Sound2 = 5020,
    Sound3 = 5021,
    Animation = 5022,
    Pose = 502201,
    Animation1 = 5023,
    Material = 5024,
    Vehicles = 5025,
    CustomModel = 5026,
    Equip_Ranged_M = 5012,
    Equip_Melee_M = 5011,
    FourFootAnimation = 13,
    SlimeAnimation = 14,
    WestDragonAnimation = 15,
    EastDragonAnimation = 16,
    Spider1Animation = 17,
    Spider2Animation = 18,
    SnakeWomanAniamtion = 19,
    BabyDragonAnimation = 20,
    AbilityAsset = 1009,
    BuffAsset = 41,
    SpawnPointDesc = 98,
    All = 99,
    Stance = 5027,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  class StanceData {
    "animationAssetId": string;
    "animationSpeed": number;
    "asset_key": mw.StanceParam;
    "defaultAnimation": string;
    "parent": StanceOverrideData;
    "speed_key": mw.StanceParam;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  class StanceOverrideData {
    "Flying_HorizontalMove": StanceData;
    "Flying_Idle": StanceData;
    "Ground_Falling": StanceData;
    "Ground_JumpStart": StanceData;
    "Ground_Land": StanceData;
    "Ground_Rise_To_Falling": StanceData;
    "Ground_RiseLoop": StanceData;
    "Ground_Stand_Idle": StanceData;
    "Ground_Stand_Move": StanceData;
    reset(): void;
    "SecondAssetType": Array<SecondAssetType>;
    setTypes(Types: Array<SecondAssetType>): void;
    "Swimming_Free_Idle": StanceData;
    "Swimming_Free_Move": StanceData;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category animation
   */
  enum StanceOverrideFrom {
    serializable = 0,
    modification = 1,
  }

  /**
   * 提供已标注的运行态能力
   * @category animation
   */
  class StanceComponent extends UComponent {
    /**
     * 记录指定姿态参数的动画资源覆盖。
     *
     * 新基础姿态或非人形角色会立即应用覆盖；传入速度时同时记录并应用对应的 `.Speed` 参数。
     */
    addAnimModifier(state: mw.StanceParam, asset: string, speed?: undefined | number): void;
    /**
     * 更新并异步应用当前姿态覆盖。
     */
    applyOverrideStance(stanceOverrideFrom?: undefined | StanceOverrideFrom | StanceOverrideFrom): void;
    /**
     * 修改指定动画的持续时间。
     */
    changeDuration(handler: AnimationHandler, duration: number): boolean;
    /**
     * 修改指定动画的循环次数。
     */
    changeLoopCount(handler: AnimationHandler, loopCount: number): boolean;
    /**
     * 修改指定动画的播放速度。
     */
    changeSpeed(handler: AnimationHandler, speed: number, replicated?: boolean): boolean;
    /**
     * 当前 Gesture 层主动画的句柄。
     */
    readonly currentAnimationHandler: number;
    /**
     * 获取角色当前状态。
     */
    readonly currentState: mw.CharacterStateType;
    /**
     * 查询指定姿态参数的动画资源覆盖。
     */
    getAnimModifier(state: mw.StanceParam): string;
    /**
     * 读取 FinalStance_V3 中 `Ground_Stand_Idle` modifier 的探测结果。
     *
     * 角色数据或 FinalStance_V3 尚未就绪时返回 `readiness: "pending"`；已就绪时返回
     * `readiness: "known"`，并仅在找到对应项时携带 `modifierValue`。
     * 2026-06-29 原因：外部模块不可访问私有 character / ueCharacter，统一经 StanceComponent 公开 API 读取。
     */
    getFinalStanceV3StandIdleModifierProbe(): Inline_bbfd400f76;
    /**
     * 读取 JSON 基础姿态的速度倍率，缺失时返回 1。
     */
    getJsonBasicStanceSpeedModifier(speedParam: string): number;
    /**
     * 查询覆盖配置中的指定姿态数据。
     */
    getOverrideDataStanceData(key: string): StanceData;
    /**
     * Gesture 层是否有仍在运行的外部/战斗 Gesture 动画。
     * handler 有效且 playable 仍在跑才算 true；仅 handler 残留（playable 已 release）返回 false。
     * 2026-06-28 23:30:00 原因：BUG-22 DS Client 射击 Gesture 结束后 handler 残留导致 Idle 语音永久 blocking。
     */
    isGestureAnimationActivelyPlaying(): boolean;
    /**
     * 角色描述是否按人形动画处理。
     *
     * 描述尚未完成时返回 `true`；完成后返回缓存的人形判定结果。
     */
    readonly isHumanDecription: boolean;
    /**
     * 加载动画资源并创建角色动画对象。
     *
     * 资源尚未加载时先等待下载完成，再调用角色动画加载接口。
     */
    loadAnimation(animationId: string): Promise<mw.Animation>;
    /**
     * 按资源匹配并应用当前姿态。
     */
    matchStance(asset?: undefined | string, callback?: undefined | (() => void)): Promise<void>;
    /**
     * 立即把预览动画器切回姿态蓝图并匹配姿态。
     */
    matchStanceImmediately(): void;
    /**
     * 动画完成、取消或运行模式切换产生终态通知时触发。
     *
     * 回调参数依次为动画句柄和当前发送路径给出的中断标记。等待加载/开播阶段取消及模式切换会发送
     * `true`；自然完成和当前活动实例的停止路径会发送 `false`。非人形或模式级通知可能使用无效句柄。
     * 不同播放实例会重复触发，监听方须按句柄过滤并在自身生命周期结束时取消监听。
     */
    readonly onAnimationEndPlay: UDelegate<(handler: number, isInterrupted: boolean) => void>;
    /**
     * 找到指定可播放实例并准备暂停时触发。
     *
     * 回调参数是目标动画句柄；事件在底层暂停调用前发送，重复暂停请求可能重复触发。
     * 监听方须在自身生命周期结束时取消监听。
     */
    readonly onAnimationPause: UDelegate<(handler: number) => void>;
    /**
     * 找到指定可播放实例并准备恢复时触发。
     *
     * 回调参数是目标动画句柄；事件在底层恢复调用前发送，重复恢复请求可能重复触发。
     * 监听方须在自身生命周期结束时取消监听。
     */
    readonly onAnimationResume: UDelegate<(handler: number) => void>;
    /**
     * 可播放实例真正开始播放时触发。
     *
     * 回调参数是开始播放的动画句柄；不同播放实例会重复触发。监听方须在自身生命周期结束时取消监听。
     */
    readonly onAnimationStartPlay: UDelegate<(handler: number) => void>;
    /**
     * 角色描述完成处理后触发。
     *
     * 事件在描述变更处理和已装备武器姿态刷新完成后发送，不携带参数；角色描述再次完成时可重复触发。
     * 监听方须在自身生命周期结束时取消监听。
     */
    readonly onCharacterDescriptionComplete: UDelegate<() => void>;
    /**
     * 角色状态变化时触发。
     *
     * 回调参数依次为前一状态和当前状态；组件收到角色状态回调时会重复转发。
     * 监听方须在自身生命周期结束时取消监听。
     */
    readonly onStateChanged: UDelegate<(prevState: mw.CharacterStateType, currentState: mw.CharacterStateType) => void>;
    /**
     * 用于通知二级姿态播放对应的动画句柄与资源 ID。
     *
     * 仓库当前仅能确认该事件会随组件销毁而清理；尚未找到广播点，触发时机和重复语义待确认。
     * 监听方须在自身生命周期结束时取消监听。
     */
    readonly onSubStancePlay: UDelegate<(handlerId: number, assetId: string) => void>;
    /**
     * 将姿态参数覆盖直接应用到角色。
     *
     * 角色没有覆盖接口时不执行操作；以 `.Speed` 结尾且速度为非零值时应用速度，否则应用资源 ID。
     */
    overrideStanceData(state: mw.StanceParam, asset: string, speed?: undefined | number): void;
    /**
     * 暂停指定句柄的动画。
     */
    pauseAnimation(handler: AnimationHandler, replicated?: boolean): boolean;
    /**
     * 使用运行时动画层播放动画。
     */
    playAnimation(animator: Animator): AnimationHandler;
    /**
     * 播放动画并等待结束，返回是否自然完成。
     */
    playAnimationAndWaitComplete(animator: Animator): Promise<boolean>;
    /**
     * 移除指定姿态参数的本地动画资源与速度覆盖。
     *
     * 此操作只更新组件缓存，不会立即重新应用角色姿态。
     */
    removeAnimModifier(state: mw.StanceParam): void;
    /**
     * 恢复指定动画句柄。
     */
    resumeAnimation(handler: AnimationHandler, replicated?: boolean): boolean;
    /**
     * 当前姿态资源 ID。
     *
     * 写入空值时归一为空字符串；值变化后同步角色姿态覆盖，并在角色就绪后应用覆盖姿态。
     */
    stanceAssetId: string;
    /**
     * 停止指定动画句柄。
     *
     * 人形角色通过动画层停止，并在服务端同步移除；非人形角色交给当前动画策略处理。
     */
    stopAnimation(handler: AnimationHandler): void;
  }
}

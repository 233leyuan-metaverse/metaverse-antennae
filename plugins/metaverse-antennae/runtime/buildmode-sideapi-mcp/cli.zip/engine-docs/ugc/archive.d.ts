// AI Export Declarations (archive) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * 提供已标注的运行态能力
   * @category archive
   */
  class ArchiveComponent extends InternalLifeComponent {
    /**
     * 在服务端读取并应用当前玩家的最新存档。
     *
     * 没有存档时记录警告并结束；找到存档时更新实体的默认变换和世界变换，并请求客户端修正位置。
     * Promise 在服务端应用流程结束后完成，不表示客户端修正请求已得到确认。
     */
    applyLastArchive(): Promise<void>;
    /**
     * 读取最近存档并更新实体默认变换，返回是否找到有效存档。
     */
    loadLastArchive(): Promise<boolean>;
    /**
     * 保存指定变换作为当前实体的最新存档点。
     *
     * 调用会将实体包围盒的一半高度累加到传入变换的位置，因此会修改 `transform`。默认走持久化路径；
     * `persistent` 为 `false` 时只保存在当前场景的运行态数据中。该方法发起服务端保存后立即返回，不等待异步持久化完成。
     */
    saveArchive(transform: mw.Transform, persistent?: boolean): void;
  }
}

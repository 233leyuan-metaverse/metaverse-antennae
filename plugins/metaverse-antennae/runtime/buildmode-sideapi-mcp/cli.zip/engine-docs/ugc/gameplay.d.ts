// AI Export Declarations (gameplay) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category gameplay
   */
  enum FactionRelation {
    isSameCamp = 0,
    isDiffCamp = 1,
    isUndeCamp = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category gameplay
   */
  type PlayerRankInfo = {
    "avatarUrl"?: undefined | string;
    "isUnrankedSelf"?: undefined | false | true;
    "name": string;
    "rank": number;
    "score": string;
    "userId": string;
  };

  /**
   * 提供已标注的运行态能力
   * @category gameplay
   */
  class FactionComponent extends InternalLifeComponent {
    /**
     * 当前阵营的显示名称；写入已存在的显示名时切换到对应阵营 ID。
     */
    factionDisplayName: string;
    /**
     * 当前实体的阵营 ID；写入后刷新索敌注册和头顶 UI 颜色。
     */
    factionName: string;
    /**
     * 按当前阵营 ID 刷新实体在 TargetQuerySystem 中的注册状态。
     * @pitfall 客户端或未启用 TargetQuerySystem 时调用会静默无操作。
     */
    handleEntityQuery(): void;
    /**
     * 比较两个阵营 ID；任一 ID 为空时返回未知，否则返回相同或不同。
     */
    static isSameCamp(campidA: string, campidB: string): FactionRelation;
  }

  /**
   * 提交、查询和展示已配置排行榜数据
   * @category gameplay
   */
  class LeaderboardComponent extends UComponent {
    /**
     * 隐藏排行榜面板。
     * @sideEffect 隐藏 `LeaderboardPanel`。
     */
    hideLeaderBoard(): void;
    /**
     * 查询指定玩家视角的排行榜数据。
     * @pitfall 排行榜名称不存在时会在访问 `getPlayerData` 时失败，而不是返回空数组。
     */
    reqLeaderboardData(leaderboardName: string, playerId: number): Promise<undefined | null | Array<PlayerRankInfo>>;
    /**
     * 请求并缓存指定排行榜数据；10 秒冷却期间直接返回已有客户端缓存。
     * @pitfall 没有本地玩家时无法读取 `Player.localPlayer.playerId` 完成查询。
     * @constraint 同一排行榜名称在一次请求后 10 秒内不会再次发起服务端查询。
     */
    reqLeaderboardDataClient(leaderboardName: string): Promise<undefined | Array<PlayerRankInfo>>;
    /**
     * 请求指定排行榜数据并显示排行榜面板。
     * @sideEffect 显示 `LeaderboardPanel` 并传入榜单数据和同名配置。
     */
    reqShowLeaderboardClient(leaderboardName: string): Promise<void>;
    /**
     * 向指定排行榜提交玩家数据；排行榜不存在时不执行。
     * @pitfall 排行榜名称不存在时调用静默结束，调用方不会收到失败结果。
     */
    setPlayerValue(leaderboardName: string, info: PlayerRankInfo, forceOverride?: boolean): void;
  }

  /**
   * 管理玩家出生点与账号查询
   * @category gameplay
   */
  class PlayerStartComponent extends InternalLifeComponent {
    /**
     * 当前出生点关联的角色对象。
     */
    readonly character: mw.Character;
    /**
     * 查询当前玩家的累计消费金额。
     */
    getUserConsumptionAmount(): Promise<number>;
    /**
     * 获取当前玩家的用户 ID。
     */
    getUserId(): string;
    /**
     * 是否捕获本地玩家麦克风音量。
     */
    isCaptureAudioPitch: boolean;
    /**
     * 启用或停用当前出生点。
     */
    setEnable(enable: boolean): void;
  }
}

// AI Export Declarations (appearance) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category appearance
   */
  enum SourceFrom {
    mw = 0,
    custom = 1,
  }

  /**
   * 提供已标注的运行态能力
   * @category appearance
   */
  class DescriptComponent extends InternalLifeComponent {
    /**
     * 当前自定义形象资源 ID。
     *
     * 写入不同值会立即启动形象变更流程，并同步 BasicInfo 图标；setter 不等待资源下载或最终形象完成事件。
     * `Default` 和 `Platform` 字符串分别选择默认形象与平台形象路径。
     */
    assetId: string;
    /**
     * 用于通知角色形象描述发生变化。
     *
     * 当前仓库只确认该事件会随组件销毁而清理，尚未找到广播点；实际触发时机和重复语义待确认。
     * 监听方须在自身生命周期结束时取消监听。
     */
    readonly onDescriptionChangeDelegate: UDelegate<() => void>;
    /**
     * Character 完成一次形象描述处理时触发。
     *
     * 事件无回调参数，可能随多次形象变更重复触发；组件随后会刷新相关插槽、装备和显示状态。
     * 监听方须在自身生命周期结束时取消监听。
     */
    readonly onDescriptionCompleteDelegate: UDelegate<() => void>;
    /**
     * 按订阅 ID 注册形象资源变化回调。
     * @pitfall 重复使用同一订阅 ID 会覆盖旧回调；调用方销毁时必须用同一 ID 调用 `unRegisterAssetChange`。
     */
    registerAssetChange(guid: string, callback: (assetId: string) => void): void;
    /**
     * 按当前 `sourceFrom` 与 `assetId` 应用角色形象。
     *
     * 自定义来源会等待角色和资源就绪后设置形象；平台来源根据运行端下载玩家形象或处理非玩家角色。
     * Promise 完成不保证 Character 的形象完成回调已经触发，最终完成应监听 `onDescriptionCompleteDelegate`。
     */
    setDescriptionByAsset(useLocalPlayerCharacter?: boolean): Promise<void>;
    /**
     * 当前形象描述来源。
     *
     * 写入只更新来源选择，不会单独等待或确认形象应用完成；需要应用时再调用 `setDescriptionByAsset`。
     */
    sourceFrom: SourceFrom;
    /**
     * 在客户端发起当前 Character 形象描述同步。
     *
     * 方法调用 `syncDescription(true, true)` 后立即返回，不等待形象完成事件。
     */
    syncDescrition(): void;
    /**
     * 移除指定订阅 ID 的形象资源变化回调。
     */
    unRegisterAssetChange(guid: string): void;
  }
}

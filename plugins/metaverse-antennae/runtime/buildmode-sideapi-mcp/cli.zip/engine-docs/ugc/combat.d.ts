// AI Export Declarations (combat) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category combat
   */
  enum DamageType {
    Instance = 0,
    Duration = 1,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   */
  interface IOldProjectileEffectInfo {
    "bloomEffect"?: undefined | string;
    "bloomSound"?: undefined | string;
    "hitEffect"?: undefined | string;
    "hitSound"?: undefined | string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   */
  interface IProjectileHitCondition {
    check(projectile: ProjectileComponent, hitTarget: IEntity, hitResult: mw.HitResult): boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   */
  type OnProjectileBloom = UDelegate<(projectile: ProjectileComponent) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   */
  type OnProjectileHit = UDelegate<(projectile: ProjectileComponent, hitTarget: IEntity, hitResult: mw.HitResult) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   */
  type ProjectileHandler = number;

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   */
  enum ProjectileLifePolicy {
    Duration = "1 << 0",
    CollisionNum = "1 << 1",
    Distance = "1 << 2",
    DurationAndCollisionNum = "Duration | CollisionNum",
    DurationAndDistance = "Duration | Distance",
    CollisionNumAndDistance = "CollisionNum | Distance",
    DurationAndCollisionNumAndDistance = "Duration | CollisionNum | Distance",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   */
  class ProjectileLifePolicyConfig {
    "collisionEnabled": boolean;
    "collisionNum": number;
    "duration": number;
    "enableCollisionNum": boolean;
    "enableDuration": boolean;
    "enableMaxDistance": boolean;
    "lifePolicy": ProjectileLifePolicy;
    "maxDistance": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   */
  class SummonerComponent extends InternalLifeComponent {
    "_referenceCount": number;
    "abilitySpecHandler": AbilitySpecHandle;
    readonly "binder": mw.GameObject;
    readonly "canEverTick": boolean;
    readonly "canPersistentSerializedIgnore": boolean;
    getIsAuthority(): boolean;
    getOccupy(): number;
    "id": string;
    "instigator": IEntity;
    readonly "internalBeselect": () => void;
    readonly "internalCloseDetailPanel": () => void;
    readonly "internalComponentAwake": () => void;
    readonly "internalComponentLateUpdate": (dt: number) => void;
    readonly "internalComponentStart": () => void;
    readonly "internalComponentUpdate": (dt: number) => void;
    readonly "internalDeselect": () => void;
    readonly "internalLiveBeselect": () => void;
    readonly "internalLiveDeselect": () => void;
    readonly "internalOnActivate": () => void;
    readonly "internalOnDeactivate": () => void;
    readonly "internalOnDestroy": () => void;
    readonly "internalOnGameModeChanged": (from: string, to: string) => void;
    readonly "internalOpenDetailPanel": () => void;
    "isAuthority": boolean;
    isPersistentSerialized(str: string): boolean;
    "name": string;
    notSupportLazyInitInBuild(): boolean;
    onDestroyed(): void;
    onEditorActiveUpdate(dt: number): void;
    onEditorSelectedUpdate(dt: number): void;
    onSyncPresetAfterDeserialize(): void;
    "ownership": ComponentOwnership;
    "passEffectToInstigator": boolean;
    preSyncPreset(): void;
    "sourceObject": IEntity;
    "stateFlag": number;
    supportLazyInit(): boolean;
    "tickEnable": boolean;
    "useEditorSelectedUpdate": boolean;
    readonly "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, component: InternalComponent) => void;
  }

  /**
   * 提供已标注的运行态能力
   * @category combat
   */
  class DamageComponent extends TriggerComponent implements ILazyWakeCapable {
    /**
     * 每次伤害使用的暴击概率。
     *
     * 服务端把当前值传给伤害任务；该组件自身不额外裁剪运行时写入值。
     */
    criticalChance: number;
    /**
     * 每次伤害使用的暴击倍率。
     *
     * 服务端把当前值传给伤害任务；该组件自身不额外裁剪运行时写入值。
     */
    criticalMultiplier: number;
    /**
     * 检测体启动时加载的 GameplayEffect 资源 ID。
     * @pitfall 资源不存在时组件会记录错误且无法造成伤害。
     */
    damageEffectId: string;
    /**
     * 每次命中的基础伤害量。
     *
     * 服务端执行伤害时读取当前值；值为 `0` 时跳过本次伤害应用。
     */
    damageMagnitude: number;
    /**
     * 伤害触发模式。
     *
     * `Instance` 对同一次进入只应用一次伤害；`Duration` 在目标停留期间按 `interval` 重复应用。
     */
    damageType: DamageType;
    /**
     * 持续伤害的最小重复间隔，单位为秒。
     *
     * `Duration` 模式使用场景调度器本地时间与上次伤害时间比较；`Instance` 模式不按该间隔重复伤害。
     */
    interval: number;
    /**
     * 命中时使用的击退强度，编辑器以厘米显示。
     *
     * 服务端每次应用伤害时把当前值作为 `knockBackMag` 传给伤害任务。
     */
    knockBackMagnitude_m2cm: number;
    /**
     * 命中后的击退时间，单位为秒。
     *
     * 服务端每次应用伤害时把当前值作为 `knockBackTime` 传给伤害任务。
     */
    knockBackSpeed: number;
  }

  /**
   * 管理投射物命中、生命周期与移动。
   * @category combat
   */
  class ProjectileComponent extends SummonerComponent {
    /**
     * 对候选命中实体执行合法性检查的策略。
     */
    checkEnemyMethod: IProjectileHitCondition;
    /**
     * 投射物的碰撞检查方式。
     */
    checkMethod: ProjectileCollisionCheckMethod;
    /**
     * 投射物结束前允许的命中次数。
     *
     * 仅当 life policy 启用 CollisionNum 时参与结束判定；每次有效命中后检查当前次数是否达到该值。
     */
    collisionNum: number;
    /**
     * 投射物最大存活时间，单位为秒。
     *
     * 写入会立即刷新底层 ProjectileMovement 的 lifespan；仅当 life policy 启用 Duration 时采用该值，
     * 并在写入底层前裁剪到 0–1000 秒。
     */
    duration: number;
    /**
     * 按当前配置刷新模型碰撞和物理组件状态。
     */
    genCollisionState(): void;
    /**
     * 投射物系统用于查找和同步该投射物的句柄。
     */
    handler: ProjectileHandler;
    /**
     * 命中与生命周期结束时使用的兼容特效和音效配置。
     */
    hitEffectInfo: IOldProjectileEffectInfo;
    /**
     * 当前启用的投射物生命周期结束条件。
     */
    lifePolicy: ProjectileLifePolicy;
    /**
     * 投射物生命周期配置。
     */
    lifePolicyConfig: ProjectileLifePolicyConfig;
    /**
     * 投射物最大累计移动距离。
     *
     * 仅当 life policy 启用 Distance 时参与结束判定；组件每帧累计移动距离并在达到该值时结束投射物。
     */
    maxDistance: number;
    /**
     * 默认命中条件需要排除的阵营名称列表。
     */
    noHitFilterFactionList: Array<string>;
    /**
     * 投射物完成生命周期处理时广播当前投射物。
     */
    readonly onProjectileExplosion: UDelegate<(projectile: ProjectileComponent) => void>;
    /**
     * 投射物通过命中条件检查后广播投射物、目标实体和命中结果。
     */
    readonly onProjectileHit: UDelegate<(projectile: ProjectileComponent, hitTarget: IEntity, hitResult: mw.HitResult) => void>;
    /**
     * 当前投射物使用的底层移动对象。
     */
    readonly projectile: mw.ProjectileMovement;
    /**
     * 是否阻止投射物命中同阵营目标。
     *
     * 默认命中条件会在每次候选命中时读取该值；为 `true` 时过滤与发射者同阵营的目标。
     */
    sameFactionNotHit: boolean;
  }
}

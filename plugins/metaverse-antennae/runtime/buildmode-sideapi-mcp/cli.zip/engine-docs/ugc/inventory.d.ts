// AI Export Declarations (inventory) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category inventory
   */
  enum createItemFailReason {
    success = "success",
    InvalidEntity = "InvalidEntity",
    invalidQuantity = "invalidQuantity",
    inventoryFull = "inventoryFull",
    notEnoughSpace = "notEnoughSpace",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category inventory
   */
  interface Inline_c8fe0c7386 {
    "bRemoveAll"?: undefined | false | true;
    "bShowPopUp"?: undefined | false | true;
    "shopInfo"?: any;
    "uniqueTag"?: undefined | string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category inventory
   */
  enum inventoryCapacityAction {
    setCapacity = 0,
    addCapacity = 1,
    subCapacity = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category inventory
   */
  type InventoryDiscardConfirmSnapshot = {
    "currentDroppedCount": number;
    "remainingDroppedCount": number;
  };

  /**
   * @aiExport
   * @since 1.0
   * @category inventory
   */
  class InventoryItemDefinition {
    "autoUse": boolean;
    "canStack": boolean;
    "canTrade": boolean;
    "characterSlot": mw.HumanoidSlotType;
    "currencyIconGuid": string;
    "currencyIconHidden": boolean;
    "currencyName": string;
    "description": string;
    "destoryable": boolean;
    "dropDestroyTime": number;
    "droppable": boolean;
    "equipmentSlot": EquipmentSlotType;
    "extraData": string;
    "iconID": string;
    initializeByConfig(config: InventoryItemConfig): void;
    "itemType": InventoryItemType;
    "maxStack": number;
    "meshID": string;
    "name": string;
    "prefabAssetId": string;
    "prefabId": string;
    "price": number;
    "sellable": boolean;
    "sellCurrencyName": string;
    "sellPrice": number;
    "uniqueTag": string;
    "useable": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category inventory
   */
  class InventoryItemInstance {
    "definition": InventoryItemDefinition;
    "guid": string;
    "itemBeenEquiped": boolean;
    "prefabAssetId": string;
    "stackCount": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category inventory
   */
  enum inventorySetItemAction {
    setItem = 0,
    addItem = 1,
    subItem = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category inventory
   */
  interface InventorySpotSlotMessage {
    "canTrade"?: undefined | false | true;
    "currencyIconGuid"?: undefined | string;
    "currencyIconHidden"?: undefined | false | true;
    "currencyName"?: undefined | string;
    "destoryable"?: undefined | false | true;
    "dropDestroyTime"?: undefined | number;
    "droppable"?: undefined | false | true;
    "guid"?: undefined | string;
    "index": number;
    "itemType"?: undefined | InventoryItemType | InventoryItemType | InventoryItemType | InventoryItemType | InventoryItemType | InventoryItemType;
    "prefabAssetId"?: undefined | string;
    "prefabId"?: undefined | string;
    "price"?: undefined | number;
    "sellable"?: undefined | false | true;
    "sellCurrencyName"?: undefined | string;
    "sellPrice"?: undefined | number;
    "stackCount"?: undefined | number;
    "useable"?: undefined | false | true;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category inventory
   */
  class PromiseResult<T> {
    isComplete(): Promise<T>;
    readonly "isPending": boolean;
  }

  /**
   * 提供已标注的运行态能力
   * @category inventory
   */
  class InventoryComponent extends UComponent {
    /**
     * 增加指定货币；负数失败，纯客户端修改金币失败。
     * @pitfall 在纯客户端增加金币会返回 false，金币值和事件均不变化。
     */
    addCurrency(currencyType: CurrencyType, amount: number, bShowPopUp?: boolean): boolean;
    /**
     * 按预设资源 ID 加入背包物品，并返回实际加入数量。
     */
    addItemByPresetAssetId(prefabAssetId: string, count: (number) | undefined, bShowPopUp: boolean): Promise<number>;
    /**
     * 按预设资源 ID 向背包加入物品，并返回成功创建的实例 GUID。
     */
    addPresetItem(itemGuid: string, count: number, info?: Inline_c8fe0c7386, vaildCountOut?: Array<number>): Promise<Array<string>>;
    /**
     * 增加指定商店商品的累计购买数量。
     */
    addPurchasedCount(shopItemDataGuid: string, count: number): void;
    /**
     * 检查指定预设物品数量能否完整放入背包。
     */
    canFullyAddPresetItem(itemGuid: string, itemCount: number): Promise<boolean>;
    /**
     * 读取或设置背包容量。
     */
    capacity: number;
    /**
     * 返回当前背包空槽数量，包含零堆叠槽和未占用容量。
     */
    checkInventoryEmptySlot(): number;
    /**
     * 按物品配置和数量检查背包空间，并返回创建失败原因枚举值。
     */
    checkInventorySpace(inItemConfig: InventoryItemConfig, itemCount: number): Promise<any>;
    /**
     * 请求当前玩家客户端关闭背包面板。
     */
    closeInventoryPanel(): void;
    /**
     * 从场景实体读取物品配置并为执行者创建背包物品。
     */
    createItemWithEntity(entity: IEntity, executor: IEntity, itemCount?: number): Promise<undefined | number>;
    /**
     * 在服务端按预设资源执行增加、减少或替换物品操作，并返回有效数量。
     * @pitfall 在纯客户端调用时会记录日志并静默返回，不会创建物品。
     */
    createPresetItem(itemGuid: string, Action: inventorySetItemAction, count?: number, bShowPopUp?: boolean, shopInfo?: any): Promise<number>;
    /**
     * 将全部已注册货币类型清零。
     */
    emptyAllCurrency(): void;
    /**
     * 等待排行榜字段依赖的持久化首值完成加载。
     */
    ensureLeaderboardPropertyReady(propertyName: string): Promise<void>;
    /**
     * 返回当前装备物品所在槽位，未找到时返回 -1。
     */
    readonly equipIndexs: number;
    /**
     * 返回当前装备物品的实例 GUID；未装备时为空字符串。
     */
    readonly equipItemGuid: string;
    /**
     * 查找与指定物品定义身份匹配的全部背包实例。
     */
    findAllItemByDefinition(definition: InventoryItemDefinition): Array<InventoryItemInstance>;
    /**
     * 按实例 GUID 查找背包物品。
     */
    findItemByGuid(guid: string): undefined | InventoryItemInstance;
    /**
     * 查找具有指定 prefab 资源 ID 的全部非空背包实例。
     */
    findItemByPrefabAssetId(prefabAssetId: string): Array<InventoryItemInstance>;
    /**
     * 查找具有指定运行时 prefab ID 的全部非空背包实例。
     */
    findItemByPrefabId(prefabId: string): Array<InventoryItemInstance>;
    /**
     * 查找物品定义具有指定唯一标签的第一个背包实例。
     */
    findItemByUniqueTag(uniqueTag: string): Promise<undefined | InventoryItemInstance>;
    /**
     * 返回当前槽位索引到物品实例的只读映射视图。
     */
    getAllItemSlots(): Readonly<Map<number, InventoryItemInstance>>;
    /**
     * 获取指定货币的当前数量；不存在时返回 0。
     */
    getCurrency(currencyType: CurrencyType): number;
    /**
     * 返回当前玩家掉落物数量、上限和剩余额度快照。
     */
    getDiscardConfirmSnapshot(): InventoryDiscardConfirmSnapshot;
    /**
     * 返回背包当前持久化物品实例数组。
     */
    GetItems(): Array<InventoryItemInstance>;
    /**
     * 汇总背包中指定预设资源 ID 的物品数量。
     */
    getPresetAssetItemCountByAssetId(prefabAssetId: string): Promise<number>;
    /**
     * 兼容旧指令参数，汇总场景或背包中指定预设物品数量。
     * @deprecated 优先使用 getPresetAssetItemCountByAssetId 查询背包预设资源。
     */
    getPresetAssetItemCountNew(checkSceneItem: boolean, prefabAssetIdOrEntity: string | IEntity): Promise<number>;
    /**
     * 汇总指定运行时 prefab ID 的背包物品数量。
     */
    getPresetItemCount(prefabId: string): number;
    /**
     * 返回指定商店商品的累计购买数量。
     */
    getPurchasedCount(shopItemDataGuid: string): number;
    /**
     * 读取或设置玩家金币数，金币数据由 UserCustomPropertyComponent 保存。
     */
    goldNumber: number;
    /**
     * 判断指定货币的当前数量是否不少于需求量。
     */
    hasEnoughCurrency(currencyType: CurrencyType, amount: number): boolean;
    /**
     * 查询背包是否具有指定预设资源 ID 的物品。
     */
    hasPresetAssetItemByAssetId(prefabAssetId: string): Promise<boolean>;
    /**
     * 兼容旧指令参数，查询场景或背包中是否具有指定预设物品。
     * @deprecated 优先使用 hasPresetAssetItemByAssetId 查询背包预设资源。
     */
    hasPresetAssetItemNew(checkSceneItem: boolean, prefabAssetIdOrEntity: string | IEntity): boolean;
    /**
     * 查询背包是否具有指定运行时 prefab ID 的物品。
     */
    hasPresetItem(prefabId: string): boolean;
    /**
     * 返回当前持久化物品实例数量；该属性的 setter 当前不执行写入。
     */
    InventoryItemNumber: number;
    /**
     * 查询排行榜字段依赖的持久化首值是否已就绪。
     */
    isLeaderboardPropertyReady(propertyName: string): boolean;
    /**
     * 所有物品被移出背包时抛出。
     */
    readonly onAllItemRemoved: UDelegate<() => void>;
    /**
     * 背包容量设置、增加或减少处理后抛出操作、请求数量和结果消息。
     */
    readonly onCapacityChanged: UDelegate<(action: inventoryCapacityAction, count: number, changeMsg: string) => void>;
    /**
     * 背包货币变化时抛出货币类型、新值和变化量。
     */
    readonly onCurrencyChanged: UDelegate<(currencyType: CurrencyType, newValue: number, delta: number) => void>;
    /**
     * 背包槽位中的物品被装备时抛出槽位索引。
     */
    readonly onEquipItem: UDelegate<(index: number) => void>;
    /**
     * 物品实例创建失败时通知相关实体、失败原因和已成功数量。
     */
    readonly onItemInstanceCreatedFailed: UDelegate<(entity: IEntity, executor: IEntity, failedReason: createItemFailReason, validCount: number) => void>;
    /**
     * 暴露背包持久化数据加载完成状态。
     */
    readonly onPersistenceLoaded: PromiseResult<void>;
    /**
     * 新槽位加入时抛出其只读槽位数据。
     */
    readonly onSlotAdded: UDelegate<(slot: Readonly<InventorySpotSlotMessage>) => void>;
    /**
     * 单个已有槽位更新时抛出其只读槽位数据。
     */
    readonly onSlotUpdate: UDelegate<(slot: Readonly<InventorySpotSlotMessage>) => void>;
    /**
     * 背包初始化、清空或批量变更时抛出完整只读槽位快照。
     */
    readonly onSpotUpdate: UDelegate<(slots: Array<Readonly<InventorySpotSlotMessage>>) => void>;
    /**
     * 当前背包装备被卸下时抛出。
     */
    readonly onUnEquipItem: UDelegate<() => void>;
    /**
     * 请求当前玩家客户端打开背包面板。
     */
    openInventoryPanel(): void;
    /**
     * 在服务端移除零数量条目并重建槽位，同时刷新客户端货币缓存。
     */
    organizeInventory(): Promise<void>;
    /**
     * 减少指定货币数量；不足时归零，可选择显示提示。
     * @pitfall 在纯客户端减少金币会静默返回，金币值和事件均不变化。
     */
    reduceCurrency(currencyType: CurrencyType, amount: number, bShowPopUp?: boolean): boolean;
    /**
     * 清空背包中的全部物品实例并刷新槽位。
     */
    removeAllItem(): Promise<void>;
    /**
     * 按实例 GUID 从背包移除指定数量，并可将移除物品掉落到场景。
     */
    removeItemByGuid(guid: string, count: number, dropDown?: boolean): Promise<void>;
    /**
     * 按槽位索引从背包移除指定数量，并可将移除物品掉落到场景。
     * @pitfall 无效索引、数量或空槽位会静默返回，不抛出调用错误。
     */
    removeItemByIndex(index: number, count: number, dropDown?: boolean): Promise<void>;
    /**
     * 按运行时 prefab ID 从匹配的背包实例中移除指定总数量。
     */
    removeItemByPrefabId(prefabId: string, count: number, dropDown?: boolean): Promise<void>;
    /**
     * 兼容旧指令参数，在服务端从场景或背包移除指定预设物品。
     * @pitfall 数量无效或预设资源不存在时会静默返回。
     * @deprecated 优先使用 removeItemByPresetAssetIdOnly 移除背包预设资源。
     */
    removeItemByPresetAssetIdNew(checkSceneItem: boolean, presetAssetId: string, count: number, dropDown?: boolean): Promise<void>;
    /**
     * 在服务端按预设资源 ID 从背包移除指定数量，并可掉落到场景。
     * @pitfall 数量无效或预设资源不存在时会静默返回。
     */
    removeItemByPresetAssetIdOnly(presetAssetId: string, count: number, dropDown?: boolean): Promise<void>;
    /**
     * 请求服务端校验槽位丢弃操作，并在达到掉落上限时向客户端显示确认。
     * @pitfall 无效索引、数量、玩家或物品定义会静默返回，客户端不会收到确认。
     */
    requestDiscardConfirmByIndex(index: number, count: number, clientItemName?: string): Promise<void>;
    /**
     * 按预设资源 ID 回滚已发放的指定物品数量。
     */
    rollbackPresetItemGrant(itemGuid: string, count: number): Promise<void>;
    /**
     * 回滚指定商店商品已预占的购买数量。
     */
    rollbackPurchasedCount(shopItemDataGuid: string, count: number): void;
    /**
     * 按槽位索引出售指定数量的物品，并结算配置的出售货币。
     * @pitfall 无效索引、数量、配置或货币字段会静默返回，物品和货币均不变。
     */
    sellItemByIndex(index: number, count: number): Promise<void>;
    /**
     * 清空现有背包后按物品定义写入指定数量，并返回新实例数组。
     * @pitfall 方法会先清空现有背包；后续创建失败时不会恢复原物品。
     */
    setAllItems(definition: InventoryItemDefinition, count?: number): Promise<Array<InventoryItemInstance>>;
    /**
     * 设置、增加或减少背包容量，并抛出容量变化事件。
     */
    setCapacity(action: inventoryCapacityAction, count: number): boolean;
    /**
     * 设置指定货币数量；负数会归零，可选择显示货币获得提示。
     * @pitfall 在纯客户端设置金币会静默返回，金币值和事件均不变化。
     */
    setCurrency(currencyType: CurrencyType, amount: number, bShowPopUp?: boolean): void;
    /**
     * 按物品创建失败原因向当前玩家显示提示。
     * @pitfall 传入 success 时会静默返回，不显示任何提示。
     */
    showItemCreatedFailedTips(failedReason: createItemFailReason, count: number): void;
    /**
     * 使用调用方提供的图标、名称和数量显示自定义货币提示。
     */
    showPopUpCustomCurrency(customCurrencyIcon: string, customCurrencyName: string, amount: number): void;
    /**
     * 在发货前尝试预占指定商品的限购额度。
     */
    tryReservePurchaseLimitForDelivery(shopItemDataGuid: string, count: number, purchaseLimit: number, isInfinity: boolean): boolean;
    /**
     * 使用一个物品实例，并返回实际消耗数量。
     * @pitfall 在纯客户端调用时静默返回 0，物品不会被使用。
     */
    useItem(item: InventoryItemInstance, count?: number): Promise<number>;
    /**
     * 在服务端按实例 GUID 使用背包物品。
     * @pitfall 数量无效、实例不存在或库存不足时会静默返回。
     */
    useItemByGuid(guid: string, count?: number): Promise<void>;
    /**
     * 在服务端按资源 ID 使用背包物品。
     * @pitfall 数量无效或找不到匹配物品时会静默返回。
     */
    useItemById(id: string, count?: number): Promise<void>;
    /**
     * 在服务端按运行时 prefab ID 使用背包物品。
     * @pitfall 数量无效或找不到匹配物品时会静默返回。
     */
    useItemByPrefabId(prefabId: string, count?: number): Promise<void>;
    /**
     * 从一组物品实例中使用指定总数量，并返回实际消耗数量。
     * @pitfall 在纯客户端调用时静默返回 0，物品不会被使用。
     */
    useItems(items: Array<InventoryItemInstance>, count?: number): Promise<number>;
  }

  /**
   * 提供已标注的运行态能力
   * @category inventory
   */
  class ItemPickupComponent extends TouchDetectorComponent {
    /**
     * 是否在满足拾取条件时自动交互。
     */
    autoInteract: boolean;
    /**
     * 拾取后授予的预设资源 ID；写入会刷新对应预览。
     */
    giveAssetId: string;
    /**
     * 单次拾取尝试授予的物品数量，面板范围为 1 到 1000000。
     */
    giveCount: number;
  }
}

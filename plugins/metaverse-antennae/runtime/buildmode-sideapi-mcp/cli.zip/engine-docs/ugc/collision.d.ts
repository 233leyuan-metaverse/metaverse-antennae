// AI Export Declarations (collision) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category collision
   */
  class CollisionShapeData {
    "Extent": mw.Vector;
    "Shape": mw.CustomShapeType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category collision
   */
  enum MassMode {
    Density = 0,
    ConstantMass = 1,
  }

  /**
   * 提供已标注的运行态能力
   * @category collision
   */
  class CharacterCollisionComponent extends PhysicComponent {
    /**
     * 尝试为角色施加角冲量。
     * @pitfall 当前实现为空，调用不会产生物理效果。
     */
    addAngularImpulse(impulse: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 尝试为角色施加持续力。
     * @pitfall 当前实现为空，调用不会产生物理效果。
     */
    addForce(force: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 让本角色移动忽略指定游戏对象。
     */
    AddIgnoreGameObject(gameObject: mw.GameObject): void;
    /**
     * 为角色施加冲量。
     */
    addImpulse(impulse: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 尝试为角色施加扭矩。
     * @pitfall 当前实现为空，调用不会产生物理效果。
     */
    addTorque(torque: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 计算并应用当前角色的碰撞形状数据。
     * @pitfall 仅服务端路径返回形状数据；客户端调用实际返回空值，与现有公开返回声明不一致。
     */
    ApplyCollisionShapeData(): CollisionShapeData;
    /**
     * 立即停止角色底层移动。
     *
     * 当前实现调用移动组件的 `StopMovementImmediately`，会清除当前运动状态。
     */
    clearAllForces(): void;
    /**
     * 角色当前碰撞状态。
     *
     * 写入时同时更新角色对象和移动命中/重叠形状；`Off` 会关闭该形状，其余状态会把该形状设为仅查询。
     */
    collision: mw.CollisionStatus;
    /**
     * 当前角色碰撞范围。
     *
     * 仅在 `collisionModify` 为 `true` 时接受写入；向量按角色碰撞范围直接设置。
     */
    collisionExtent: mw.Vector;
    /**
     * 是否允许自定义角色碰撞形状和范围。
     *
     * 该标记为 `false` 时，`collisionShape` 和 `collisionExtent` 的写入会被忽略；修改标记本身不会立即重算碰撞数据。
     */
    collisionModify: boolean;
    /**
     * 当前角色碰撞形状。
     *
     * 仅在 `collisionModify` 为 `true` 时接受写入。运行态会尝试为新形状计算范围，构建环境沿用当前范围。
     */
    collisionShape: mw.CustomShapeType;
    /**
     * 是否与其他角色发生碰撞。
     *
     * 读取和写入都会直接访问角色的对应碰撞开关。
     */
    collisionWithOtherCharacterEnabled: boolean;
    /**
     * 获取角色当前碰撞通道。
     *
     * 正常情况下读取并转换 UE 对象通道；读取失败时记录错误并返回内部缓存通道。
     */
    getCollisionChannel(): CollisionChannel;
    /**
     * 查询角色胶囊体当前是否与目标实体重叠。
     */
    isOverlappingEntity(target: IEntity): boolean;
    /**
     * 角色胶囊体的线性阻尼。
     */
    linerDamping: number;
    /**
     * 角色底层移动组件的质量。
     */
    mass: number;
    /**
     * 是否使用组件配置的质量；当前角色实现只保存该公开状态。
     * @pitfall 当前字段未同步到底层 Character，修改后不会切换实际质量模式。
     */
    massEnable: boolean;
    /**
     * 角色碰撞形状数据应用或确认后触发。
     *
     * 回调参数包含形状和范围快照；每次应用形状数据，或服务器确认继续使用当前形状时都可能重复触发。
     * 监听方须在自身生命周期结束时取消监听。
     */
    readonly onCollisionShapeDataChanged: UDelegate<(shapeData: CollisionShapeData) => void>;
    /**
     * 是否启用角色物理模拟。
     */
    physicsEnabled: boolean;
    /**
     * 恢复本角色移动对指定游戏对象的检测。
     */
    RemoveIgnoreGameObject(gameObject: mw.GameObject): void;
    /**
     * 设置角色碰撞通道。
     *
     * 方法会保存通道、转换为 UE 通道编号，并按当前碰撞 Profile 应用相关通道关系；底层设置失败时记录错误。
     */
    setCollisionChannel(channel: CollisionChannel): void;
    /**
     * 是否启用角色触碰检测；当前角色实现只保存该公开状态。
     * @pitfall 当前字段未同步到底层 Character，修改后可能不会改变实际触碰检测。
     */
    touchEnabled: boolean;
  }

  /**
   * 提供已标注的运行态能力
   * @category collision
   */
  class ModelCollisionComponent extends PhysicComponent {
    /**
     * 为模型施加角冲量。
     */
    addAngularImpulse(impulse: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 为模型施加力。
     */
    addForce(force: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 为模型施加冲量。
     */
    addImpulse(impulse: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 为模型施加扭矩。
     */
    addTorque(torque: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 模型角阻尼。
     *
     * 写入总会缓存该值，并在物理模拟启用时立即应用到模型；读取优先返回缓存，否则返回模型值或默认阻尼。
     */
    angularDamping: number;
    /**
     * 模型对相机碰撞的处理模式。
     * @pitfall 仅识别 Block_Camera、Ignore_Camera_WithOpacity、Ignore_Camera；其他字符串只会被保存，不会应用相机响应。
     */
    cameraCollisionChannel: string;
    /**
     * 是否强制模型保留触摸检测能力。
     *
     * 碰撞已启用时，写入 `true` 会启用触摸并把碰撞切到仅查询；写入 `false` 会恢复阻挡碰撞。
     */
    canTouch: boolean;
    /**
     * 模型重心位置。
     *
     * 仅在物理模拟启用时接受写入；读取在模型不可用时返回零向量。
     */
    centerOfMass: mw.Vector;
    /**
     * 清除模型当前运动。
     *
     * 当前实现将底层 actor 的角速度和线速度同时置为零。
     */
    clearAllForces(): void;
    /**
     * 模型当前碰撞状态。
     *
     * 读取和写入均直接访问实体 GameObject 的碰撞状态。
     */
    collision: mw.CollisionStatus;
    /**
     * 是否启用模型碰撞。
     *
     * 写入会按当前环境保存或复制配置、设置模型碰撞状态，并在关闭/恢复碰撞时协调已缓存的物理模拟状态。
     * 读取以模型当前碰撞状态为准；模型销毁后返回 `false`。
     */
    collisionEnabled: boolean;
    /**
     * 模型密度。
     *
     * 写入和读取均直接访问模型当前值。
     */
    density: number;
    /**
     * 模型物理材质的摩擦系数。
     *
     * 写入会直接设置模型，并在服务端更新复制缓存；读取返回模型当前值。
     */
    friction: number;
    /**
     * 获取模型当前碰撞通道。
     *
     * 静态网格会读取并转换 UE 通道；实例化静态网格或读取失败时返回内部缓存通道。
     */
    getCollisionChannel(): CollisionChannel;
    /**
     * 模型是否受重力影响。
     *
     * 仅在物理模拟启用时接受写入；读取在模型不可用时返回 `false`。
     */
    gravityEnabled: boolean;
    /**
     * 查询模型当前是否与目标实体重叠。
     */
    isOverlappingEntity(target: IEntity): boolean;
    /**
     * 模型线性阻尼。
     *
     * 写入总会缓存该值，并在物理模拟启用时立即应用到模型；读取优先返回缓存，否则返回模型值或默认阻尼。
     */
    linerDamping: number;
    /**
     * 模型质量。
     *
     * 仅在物理模拟启用时接受写入并由服务端更新复制缓存；读取直接返回模型当前质量。
     */
    mass: number;
    /**
     * 是否启用模型恒定质量。
     *
     * 仅在物理模拟启用时接受写入；读取直接返回模型当前标记。
     */
    massEnable: boolean;
    /**
     * 模型质量计算模式。
     *
     * 仅在物理模拟启用时接受写入；恒定质量模式会启用模型质量值，密度模式会关闭恒定质量标记。
     */
    massMode: MassMode;
    /**
     * 同时设置模型的线性与角运动阻尼。
     * @pitfall setter 使用的复制字段名与声明字段不一致，跨端同步效果需人工确认；本地物理开启时仍会立即生效。
     */
    moveDamping: number;
    /**
     * 当模型开始触碰实体时触发。
     */
    readonly onTouch: UDelegate<(entity: IEntity, hitResult: mw.HitResult) => void>;
    /**
     * 当模型结束触碰实体时触发。
     * @pitfall 当前公开类型声明包含 hitResult，但实际广播点只传入 entity，第二个参数运行时可能为空。
     */
    readonly onTouchEnd: UDelegate<(entity: IEntity, hitResult: mw.HitResult) => void>;
    /**
     * 是否启用模型物理模拟。
     *
     * 构建环境会保存配置并在开启时先启用碰撞；运行态要求碰撞已开启，否则抛出用户可见错误。
     * 成功切换时会同步碰撞通道、轴锁、子物体处理和 AOI 注册状态。
     */
    physicsEnabled: boolean;
    /**
     * 模型物理材质的弹力系数。
     *
     * 写入和读取均直接访问模型当前值。
     */
    restitution: number;
    /**
     * 设置模型碰撞通道。
     *
     * 方法会保存通道、设置 UE 对象通道并应用当前 Profile 关系；`applyToChild=true` 时递归处理已有子实体的模型碰撞组件。
     * 底层设置失败会记录错误。
     */
    setCollisionChannel(channel: CollisionChannel, applyToChild?: boolean): void;
    /**
     * 是否启用模型触摸检测。
     *
     * 写入时同时更新构建配置缓存和模型的 `touchEnabled`；读取返回模型当前触摸开关。
     */
    touchEnabled: boolean;
    /**
     * 模型是否可见。
     *
     * 读取在模型不可用时返回 `false`；写入调用模型可见性接口。
     */
    visibility: boolean;
  }
}

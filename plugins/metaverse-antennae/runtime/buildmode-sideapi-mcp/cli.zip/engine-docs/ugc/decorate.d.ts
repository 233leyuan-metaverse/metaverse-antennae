// AI Export Declarations (decorate) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @category decorate
   * @capability decorate
   * @since 1.0
   */
  const editorType: (options: NonNullable<IPropertyAttributes['editorType']>) => LegacyPropertyDecorator;

  /**
   * @aiExport
   * @category decorate
   * @capability decorate
   * @since 1.0
   */
  const emptyDecorator: ClassDecorator & LegacyPropertyDecorator;

  /**
   * @aiExport
   * @category decorate
   * @capability decorate
   * @since 1.0
   */
  const emptyDecoratorFn: () => ClassDecorator & LegacyPropertyDecorator;

  /**
   * @aiExport
   * @category decorate
   * @capability decorate
   * @since 1.0
   */
  const option: (options: NonNullable<IPropertyAttributes['option']>) => LegacyPropertyDecorator;

  /**
   * @aiExport
   * @category decorate
   * @capability decorate
   * @since 1.0
   */
  const persistable: (target: any, propertyKey: string, descriptorOrInitializer?: PropertyDescriptor | (() => any)) => void;

  /**
   * @aiExport
   * @category decorate
   * @capability decorate
   * @since 1.0
   */
  function property(options?: IPropertyOptions): LegacyPropertyDecorator;

  /**
   * 标记一个函数是RPC函数
   * @aiExport
   * @category decorate
   * @capability decorate
   * @since 1.0
   */
  function remoteCall(...options: FunctionOption[]): (target: any, propertyKey: string, descriptor: PropertyDescriptor) => void;

  /**
   * @aiExport
   * @category decorate
   * @capability decorate
   * @since 1.0
   */
  const replicable: (onChanged?: string | ((path: string, value: unknown, oldVal: unknown) => void | boolean),brepOwner?: boolean) => LegacyPropertyDecorator;

  /**
   * @aiExport
   * @category decorate
   * @capability decorate
   * @since 1.0
   */
  const serializable: LegacyPropertyDecorator;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  class ArgumentSlot<T> {
    readonly "argConfig": ArgumentSlotConfig<UGCType>;
    readonly "description": string;
    getTypeWhiteList(): Set<string>;
    readonly "subTypes"?: undefined | Array<ArgumentSlot<UGCType>>;
    readonly "type": UGCType;
    readonly "useOwnerType": EUseOwnerType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  class ArgumentSlotConfig<T> {
    "assetEditTypes"?: undefined | Function;
    "associated"?: undefined | false | true;
    "default"?: undefined | unknown;
    "description"?: undefined | string;
    "displayWrapper"?: undefined | ((value: any) => string);
    "enum"?: undefined | string;
    "filterEntityTypes"?: undefined | Array<BlocklyTypes>;
    "id"?: undefined | string;
    "maxLength"?: undefined | number;
    "notifyOnPanelStateChanged"?: undefined | Function;
    "nullable"?: undefined | false | true;
    "precision"?: undefined | number;
    "range"?: undefined | Tuple_76e2e81993;
    "slider"?: undefined | false | true;
    "subTypes"?: undefined | Array<ArgumentSlot<UGCType>>;
    "tooltip"?: undefined | string;
    "useOwnerType"?: undefined | EUseOwnerType | EUseOwnerType | EUseOwnerType | EUseOwnerType | EUseOwnerType | EUseOwnerType | EUseOwnerType | EUseOwnerType | EUseOwnerType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  class ArgumentSlots<T> {
    ___iterator_171(): ArrayIterator<ArgumentSlot<unknown>>;
    readonly "__@unscopables@320": Inline_734eb4e8a3;
    concat(...items: Array<ConcatArray<ArgumentSlot<unknown>>>): Array<ArgumentSlot<unknown>>;
    concat(...items: Array<ArgumentSlot<unknown> | ConcatArray<ArgumentSlot<unknown>>>): Array<ArgumentSlot<unknown>>;
    copyWithin(target: number, start: number, end?: undefined | number): ArgumentSlots<T>;
    entries(): ArrayIterator<Tuple_5c086b1016>;
    every<S extends T>(predicate: (value: ArgumentSlot<unknown>, index: number, array: Array<ArgumentSlot<unknown>>) => boolean, thisArg?: any): boolean;
    every(predicate: (value: ArgumentSlot<unknown>, index: number, array: Array<ArgumentSlot<unknown>>) => unknown, thisArg?: any): boolean;
    fill(value: ArgumentSlot<unknown>, start?: undefined | number, end?: undefined | number): ArgumentSlots<T>;
    filter<S extends T>(predicate: (value: ArgumentSlot<unknown>, index: number, array: Array<ArgumentSlot<unknown>>) => boolean, thisArg?: any): Array<S>;
    filter(predicate: (value: ArgumentSlot<unknown>, index: number, array: Array<ArgumentSlot<unknown>>) => unknown, thisArg?: any): Array<ArgumentSlot<unknown>>;
    find<S extends T>(predicate: (value: ArgumentSlot<unknown>, index: number, obj: Array<ArgumentSlot<unknown>>) => boolean, thisArg?: any): undefined | S;
    find(predicate: (value: ArgumentSlot<unknown>, index: number, obj: Array<ArgumentSlot<unknown>>) => unknown, thisArg?: any): undefined | ArgumentSlot<unknown>;
    findIndex(predicate: (value: ArgumentSlot<unknown>, index: number, obj: Array<ArgumentSlot<unknown>>) => unknown, thisArg?: any): number;
    flat<A, D extends number>(depth?: undefined | D): Array<FlatArray<A, D>>;
    flatMap<U, This>(callback: (value: ArgumentSlot<unknown>, index: number, array: Array<ArgumentSlot<unknown>>) => U | Array<U>, thisArg?: undefined | This): Array<U>;
    forEach(callbackfn: (value: ArgumentSlot<unknown>, index: number, array: Array<ArgumentSlot<unknown>>) => void, thisArg?: any): void;
    includes(searchElement: ArgumentSlot<unknown>, fromIndex?: undefined | number): boolean;
    indexOf(searchElement: ArgumentSlot<unknown>, fromIndex?: undefined | number): number;
    join(separator?: undefined | string): string;
    keys(): ArrayIterator<number>;
    lastIndexOf(searchElement: ArgumentSlot<unknown>, fromIndex?: undefined | number): number;
    "length": number;
    map<U>(callbackfn: (value: ArgumentSlot<unknown>, index: number, array: Array<ArgumentSlot<unknown>>) => U, thisArg?: any): Array<U>;
    pop(): undefined | ArgumentSlot<unknown>;
    push(...items: Array<ArgumentSlot<unknown>>): number;
    reduce(callbackfn: (previousValue: ArgumentSlot<unknown>, currentValue: ArgumentSlot<unknown>, currentIndex: number, array: Array<ArgumentSlot<unknown>>) => ArgumentSlot<unknown>): ArgumentSlot<unknown>;
    reduce(callbackfn: (previousValue: ArgumentSlot<unknown>, currentValue: ArgumentSlot<unknown>, currentIndex: number, array: Array<ArgumentSlot<unknown>>) => ArgumentSlot<unknown>, initialValue: ArgumentSlot<unknown>): ArgumentSlot<unknown>;
    reduce<U>(callbackfn: (previousValue: U, currentValue: ArgumentSlot<unknown>, currentIndex: number, array: Array<ArgumentSlot<unknown>>) => U, initialValue: U): U;
    reduceRight(callbackfn: (previousValue: ArgumentSlot<unknown>, currentValue: ArgumentSlot<unknown>, currentIndex: number, array: Array<ArgumentSlot<unknown>>) => ArgumentSlot<unknown>): ArgumentSlot<unknown>;
    reduceRight(callbackfn: (previousValue: ArgumentSlot<unknown>, currentValue: ArgumentSlot<unknown>, currentIndex: number, array: Array<ArgumentSlot<unknown>>) => ArgumentSlot<unknown>, initialValue: ArgumentSlot<unknown>): ArgumentSlot<unknown>;
    reduceRight<U>(callbackfn: (previousValue: U, currentValue: ArgumentSlot<unknown>, currentIndex: number, array: Array<ArgumentSlot<unknown>>) => U, initialValue: U): U;
    reverse(): Array<ArgumentSlot<unknown>>;
    shift(): undefined | ArgumentSlot<unknown>;
    slice(start?: undefined | number, end?: undefined | number): Array<ArgumentSlot<unknown>>;
    some(predicate: (value: ArgumentSlot<unknown>, index: number, array: Array<ArgumentSlot<unknown>>) => unknown, thisArg?: any): boolean;
    sort(compareFn?: undefined | ((a: ArgumentSlot<unknown>, b: ArgumentSlot<unknown>) => number)): ArgumentSlots<T>;
    splice(start: number, deleteCount?: undefined | number): Array<ArgumentSlot<unknown>>;
    splice(start: number, deleteCount: number, ...items: Array<ArgumentSlot<unknown>>): Array<ArgumentSlot<unknown>>;
    toLocaleString(): string;
    toLocaleString(locales: string | Array<string>, options?: undefined | Intl.NumberFormatOptions & Intl.DateTimeFormatOptions): string;
    toString(): string;
    unshift(...items: Array<ArgumentSlot<unknown>>): number;
    values(): ArrayIterator<ArgumentSlot<unknown>>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type ArrayOptions<T = Object> = {
    "add"?: undefined | null | string | ((aggregator: IAggregator, value?: any, key?: undefined | string) => T);
    "defaultElement"?: undefined | string | T | ((aggregator: IAggregator) => T);
    "itemSet"?: undefined | null | string;
    "proccessName"?: undefined | string | ((index?: undefined | number) => string);
    "remove"?: undefined | null | string | ((key: string, value: any, aggregator: IAggregator) => T);
  };

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type AssetEditTypePeset = {
    "defaultAssetId"?: undefined | string;
    "isOnlyPreset"?: undefined | false | true;
    "type": Array<number>;
    "uploadTypes"?: undefined | Array<number>;
  };

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type BabelPropertyDecoratorDescriptor = PropertyDescriptor & Inline_1b4c4e00bd;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  enum BlocklyTypes {
    boolean = "Boolean",
    color = "Color",
    number = "Number",
    bigNumber = "BigNumber",
    quaternion = "Quaternion",
    rotation = "Rotation",
    string = "String",
    vector = "Vector",
    vector2 = "Vector2",
    vector4 = "Vector4",
    transform = "Transform",
    system = "System",
    buff = "Buff",
    ability = "Ability",
    skyuid = "skyuid",
    entity = "Entity",
    model = "Entity_Model",
    player = "Entity_Player",
    weapon = "Entity_Weapon",
    hotweapon = "Entity_Hotweapon",
    meleeWeapon = "Entity_MeleeWeapon",
    floor = "Entity_Floor",
    scene = "Entity_Scene",
    gear = "Entity_Gear",
    effect = "Entity_Effect",
    props = "Entity_Props",
    customModel = "Entity_CustomModel",
    waterVolume = "Entity_WaterVolume",
    statue = "Entity_Statue",
    anchor = "Entity_Anchor",
    asset = "Asset",
    dataTable = "DataTable",
    assetStaticMesh = "Asset_StaticMesh",
    assetModel = "Asset_Model",
    assetOrgan = "Asset_Organ",
    assetEffect = "Asset_Effect",
    assetRole = "Asset_Role",
    assetTetrapods = "Asset_Tetrapods",
    assetTexture = "Asset_Texture",
    assetGear = "Asset_Gear",
    assetSound = "Asset_Sound",
    assetAnimation = "Asset_Animation",
    assetMaterial = "Asset_Material",
    assetWeapon = "Asset_Weapon",
    assetEquip_Ranged_M = "Asset_Equip_Ranged_M",
    assetEquip_Melee_M = "Asset_Equip_Melee_M",
    assetFourFootAnimation = "Asset_FourFootAnimation",
    assetSlimeAnimation = "Asset_SlimeAnimation",
    assetDecoration = "Asset_Decoration",
    assetTerrain = "Asset_Terrain",
    assetStance = "Asset_Stance",
    CustomCurrency = "CustomCurrency",
    date = "Date",
    void = "Void",
    unknown = "Unknown",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type EditorChangeCallBack = (value: string, path: string, aggregator: IAggregator) => void;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type EditorPreChangeCallBack = (value: string, path: string, aggregator: IAggregator) => void;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type EditShape = {
    "editShape_Changed"?: undefined | string | ((transform: any, isEnd: any) => void);
    "editShape_Obj"?: undefined | string | (() => Promise<mw.GameObject>);
    "editShape_Shape"?: undefined | string | (() => Array<string> | Array<EShapedEditType>);
  };

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type EnumItem = Inline_70d92378ee | Record<string, string | number>;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type EnumOptions = EnumItem;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  enum EShapedEditType {
    None = 0,
    Move = "Move",
    Rot = "Rot",
    Scale = "Scale",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  enum EUseOwnerType {
    None = 0,
    InstructionOwner = "1 << 0",
    Player = "1 << 1",
    Model = "1 << 2",
    NPC = "1 << 3",
    Other = "1 << 4",
    Character = "Player | NPC",
    All = "0x7fffffff ^ InstructionOwner",
    NoPlayer = "All ^ Player",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type ExtraExtension = {
    "extensionResultBack": string | ((...args: Array<any>) => any);
    "funcIcon"?: undefined | string;
    "isEditEntry"?: undefined | false | true;
    "isOutside"?: undefined | false | true;
    "isPre"?: undefined | false | true;
    "UIPath"?: undefined | string;
    "visible"?: undefined | false | true | ((param?: undefined | string | number) => boolean);
  };

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type GroupOptions = Inline_438915bfc3 & Partial<Inline_02afa0c657>;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type HighLightConfig = {
    "assetId"?: undefined | string | number;
    "color"?: undefined | mw.LinearColor;
    "durationTime"?: undefined | number;
    "flashFrequencyTime"?: undefined | number;
    "isOpen": boolean;
    "margin"?: undefined | mw.Margin;
  };

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type Initializer = () => unknown;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  interface Inline_02afa0c657 {
    "displayName": string;
    "displayOrder": number;
    "id": string;
    "style"?: undefined | string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  interface Inline_1b4c4e00bd {
    "initializer"?: Initializer;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  interface Inline_24c44f2908 {
    "tabIcon"?: undefined | string | ((index?: undefined | number) => string | mw.LinearColor);
    "tabLayout": mw.UILayoutType;
    "tabName"?: undefined | string | ((index?: undefined | number) => string);
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  interface Inline_438915bfc3 {
    "name": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  interface Inline_467c05fc15 {
    "deep"?: undefined | false | true;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  interface Inline_70d92378ee {
    "enum": string | unknown;
    "enumIconBack"?: undefined | string | ((param?: undefined | string | number) => string);
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  interface Inline_734eb4e8a3 {
    readonly "__@unscopables@320"?: undefined | false | true;
    "length"?: undefined | false | true;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  interface Inline_aa356e9227 {
    "deep"?: undefined | false | true;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type InspectorDynamicFunction<T> = (...args: any) => T;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  interface IPropertyAttributes {
    "allowExpand"?: undefined | false | true;
    "array"?: ArrayOptions<Object>;
    "assetEditTypes"?: undefined | string | Array<number> | AssetEditTypePeset;
    "assetIcon"?: undefined | string | (() => string);
    "assetInfo"?: undefined | string;
    "assetPreview"?: undefined | string | InspectorDynamicFunction<void>;
    "assetPreviewApply"?: undefined | string | InspectorDynamicFunction<void>;
    "assetPreviewCancel"?: undefined | string | InspectorDynamicFunction<void>;
    "bottomPart"?: undefined | false | true;
    "childrenTransfer"?: undefined | string | Record<string, any>;
    "customAssetList"?: undefined | string | (() => Array<any>);
    "default"?: any;
    "deprecated"?: undefined | Array<string>;
    "displayName"?: undefined | string;
    "displayOrder"?: undefined | number;
    "displayWrapper"?: undefined | ((text: string) => string);
    "dynamicGroup"?: undefined | false | true;
    "editEntry"?: undefined | false | true;
    "editEntryCallback"?: undefined | string | InspectorDynamicFunction<void>;
    "editorChanged"?: undefined | string | EditorChangeCallBack;
    "editorOnly"?: undefined | false | true;
    "editorPreChanged"?: undefined | string | EditorPreChangeCallBack;
    "editorType"?: undefined | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType | UIComponentType;
    "editShape"?: EditShape;
    "emptyFallback"?: undefined | string | InspectorDynamicFunction<string>;
    "enable"?: undefined | string | InspectorDynamicFunction<null | string>;
    "exclude"?: undefined | Array<number>;
    "expandSelf"?: undefined | false | true;
    "extraExtensions"?: undefined | Array<ExtraExtension>;
    "formerlySerializedAs"?: undefined | string;
    "group"?: undefined | string | GroupOptions;
    "handleAssociatedParams"?: undefined | ((params: Array<any>) => any);
    "hideDisplayName"?: undefined | false | true;
    "hideDisplayNameWithStretch"?: undefined | false | true;
    "hideInEditor"?: undefined | false | true;
    "ignoreFormat"?: undefined | false | true;
    "indentAmount"?: undefined | number;
    "inputType"?: undefined | mw.InputTextLimit.NoLimit | mw.InputTextLimit.LimitToInt | mw.InputTextLimit.LimitToFloat | mw.InputTextLimit.LimitToNumberAndChar | mw.InputTextLimit.LimitToPassword;
    "max"?: undefined | number | (() => number);
    "maxInputClipCount"?: undefined | number;
    "maxLength"?: undefined | number;
    "min"?: undefined | number | (() => number);
    "notifyOnPanelStateChanged"?: undefined | string | InspectorDynamicFunction<void>;
    "number"?: undefined | mw.NumberType.Int8 | mw.NumberType.Int16 | mw.NumberType.Int32 | mw.NumberType.Int64 | mw.NumberType.Float | mw.NumberType.Double;
    "onChanged"?: undefined | string | ((path: string, value: unknown, oldVal: unknown) => false | true | void);
    "onlyUseChild"?: undefined | string;
    "option"?: EnumOptions;
    "override"?: undefined | false | true;
    "persistable"?: undefined | false | true;
    "precision"?: undefined | number;
    "range"?: undefined | Array<number>;
    "readonly"?: ReadonlyDecoratorArgs;
    "refresh"?: undefined | string | InspectorDynamicFunction<void>;
    "relative"?: undefined | false | true;
    "repetitionPreview"?: undefined | false | true;
    "replicated"?: undefined | false | true;
    "selectCallback"?: SelectCallBack;
    "selectTitle"?: undefined | number;
    "serializable"?: undefined | false | true;
    "showInQuickPanel"?: undefined | false | true;
    "showNowData"?: undefined | false | true;
    "showTooltipAtCustonPart"?: undefined | false | true;
    "skillDescription"?: undefined | string | InspectorDynamicFunction<void>;
    "skillIcon"?: undefined | string | InspectorDynamicFunction<void>;
    "skillPreviewInfo"?: skillPreviewInfo;
    "slider"?: undefined | false | true;
    "step"?: undefined | number;
    "tabLayout"?: TabLayout;
    "tooltip"?: undefined | string;
    "type"?: any;
    "ugcParams"?: undefined | ArgumentSlots<Array<UGCType>>;
    "ugcReturn"?: undefined | ArgumentSlot<UGCType>;
    "ugcType"?: undefined | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType | UGCType;
    "uiBindProperty"?: undefined | string;
    "uiBindSource"?: undefined | false | true;
    "uiBindSyncHook"?: undefined | string;
    "unpickChildren"?: undefined | false | true;
    "useByGuide"?: undefined | false | true;
    "useHightLight"?: undefined | string | InspectorDynamicFunction<HighLightConfig>;
    "useOnTextChanged"?: undefined | false | true;
    "viewButton"?: undefined | string;
    "visible"?: undefined | string | false | true | InspectorDynamicFunction<boolean>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type LegacyPropertyDecorator = (target: Record<string, any>, propertyKey: string | symbol, descriptorOrInitializer?: undefined | null | BabelPropertyDecoratorDescriptor | Initializer) => void;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type ReadonlyArgs = false | true | Inline_467c05fc15;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type ReadonlyDecoratorArgs = false | true | Inline_aa356e9227 | InspectorDynamicFunction<ReadonlyArgs>;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type SelectCallBack = {
    "checkCanUseSelect"?: undefined | string | (() => boolean);
    "noSelectSelf"?: undefined | false | true;
    "presetSelect"?: undefined | false | true;
    "sceneSelect"?: undefined | false | true;
    "selectCheck"?: undefined | string | ((entity: IEntity) => boolean);
    "showSaveObj"?: undefined | string;
  };

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type skillPreviewInfo = {
    "skillDescription"?: undefined | string | ((index?: undefined | number) => string);
    "skillIcon"?: undefined | string | ((index?: undefined | number) => string);
    "skillName"?: undefined | string | ((index?: undefined | number) => string);
  };

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type TabLayout = Inline_24c44f2908 | mw.UILayoutType.Horizontal | mw.UILayoutType.Vertical;

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type Tuple_5c086b1016 = [number, ArgumentSlot<unknown>];

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  type Tuple_76e2e81993 = [number, number];

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   */
  enum UGCType {
    Entity = "EEntityTag.TAG_All",
    Floor = "EEntityTag.TAG_Floor",
    Scene = "EEntityTag.TAG_Scene",
    Vehicle = "EEntityTag.TAG_Vehicle",
    Gear = "EEntityTag.TAG_Gear",
    Effect = "EEntityTag.TAG_Effect",
    Player = "EEntityTag.TAG_Character",
    Model = "EEntityTag.TAG_Model",
    Weapon = "EEntityTag.TAG_Weapon",
    Hotweapon = "EEntityTag.TAG_HotWeapon",
    MeleeWeapon = "EEntityTag.TAG_MeleeWeapon",
    Props = "EEntityTag.TAG_Props",
    WaterVolume = "EEntityTag.TAG_WaterVolume",
    Statue = "EEntityTag.TAG_Statue",
    CustomModel = "EEntityTag.TAG_CustomModel",
    Anchor = "EEntityTag.TAG_Anchor",
    Buff = "buff",
    Ability = "ability",
    Asset = "asset",
    Number = "number",
    BigNumber = "BigNumber",
    String = "string",
    Boolean = "boolean",
    Vector = "vector",
    Vector2 = "vector2",
    Vector4 = "vector4",
    Quaternion = "quaternion",
    Transform = "transform",
    Color = "color",
    Rotation = "rotation",
    System = "system",
    SkyUID = "skyuid",
    DataTable = "dataTable",
    Array = "Array",
    Set = "Set",
    Map = "Map",
    Void = "void",
    Unknown = "unknown",
    Date = "Date",
    ScaleVector = "ScaleVector",
    PositionVector = "PositionVector",
    DirectionVector = "DirectionVector",
    AssetAnimation = "BlocklyTypes.assetAnimation",
    AssetModel = "BlocklyTypes.assetModel",
    AssetTexture = "BlocklyTypes.assetTexture",
    AssetEffect = "BlocklyTypes.assetEffect",
    AssetSound = "BlocklyTypes.assetSound",
    AssetMaterial = "BlocklyTypes.assetMaterial",
    AssetGear = "BlocklyTypes.assetGear",
    AssetOrgan = "BlocklyTypes.assetOrgan",
    AssetDecoration = "BlocklyTypes.assetDecoration",
    AssetTerrain = "BlocklyTypes.assetTerrain",
    AssetRole = "BlocklyTypes.assetRole",
    AssetEquip_Melee_M = "BlocklyTypes.assetEquip_Melee_M",
    AssetEquip_Ranged_M = "BlocklyTypes.assetEquip_Ranged_M",
    CustomCurrency = "BlocklyTypes.CustomCurrency",
  }
}

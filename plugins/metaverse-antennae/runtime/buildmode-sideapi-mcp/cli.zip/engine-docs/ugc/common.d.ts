// AI Export Declarations (common) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @externalType global.AbstractedConstructor
   * @since 1.0
   */
  interface global_AbstractedConstructor {
    readonly __aiHandle_global_AbstractedConstructor: never;
  }

  /**
   * @aiExport
   * @externalType global.Action2
   * @since 1.0
   */
  interface global_Action2 {
    readonly __aiHandle_global_Action2: never;
  }

  /**
   * @aiExport
   * @externalType global.Class
   * @since 1.0
   */
  interface global_Class {
    readonly __aiHandle_global_Class: never;
  }

  /**
   * @aiExport
   * @externalType global.Constructor
   * @since 1.0
   */
  interface global_Constructor {
    readonly __aiHandle_global_Constructor: never;
  }

  /**
   * @aiExport
   * @externalType global.InferFnArgs
   * @since 1.0
   */
  interface global_InferFnArgs {
    readonly __aiHandle_global_InferFnArgs: never;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class AbilityActivateInfo {
    "activationMode": AbilityActivationMode;
    "canBeEndedByOtherPeer": boolean;
    clearPredictionKey(): AbilityActivateInfo;
    clone(): AbilityActivateInfo;
    markConfirmedByAuthority(): AbilityActivateInfo;
    markRejected(): AbilityActivateInfo;
    matchesPredictionKey(predictionSessionKey: number): boolean;
    "predictionKey": number;
    "remoteInstanceConfirmed": boolean;
    reset(): void;
    setPredictionKey(predictionKey: number): AbilityActivateInfo;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum AbilityActivationMode {
    Authority = 0,
    NonAuthority = 1,
    Predicting = 2,
    Confirmed = 3,
    Rejected = 4,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class AbilityActorInfo {
    readonly "abilityComponent": AbilitySystemComponent;
    clear(): void;
    readonly "entity": IEntity;
    isLocalControlled(): boolean;
    isLocalPlayerController(): boolean;
    readonly "player": null | mw.Player;
    readonly "playerController": undefined | IPlayerController;
    postUnSerialize(): void;
    preSerialize(): void;
    rebind(owner: IEntity): void;
    readonly "scene": IScene;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category collision
   * @category combat
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category movement
   * @category scene
   * @category shop
   * @category test
   * @category weapon
   */
  class AbilityBase {
    ___AbilityClearEvent_4298(): void;
    "__@AbilityComponents@4290": Array<IComponent>;
    "__@AbilityEntity@4288": Entity;
    "__@AbilityId@4294": string;
    "__@AbilityListenerHandler@4296": Array<ComponentEventHandler>;
    "__@AbilityPropertys@4292": Inline_64d9856528;
    "__@AbilityUserEvents@4300": Inline_99f5d74947;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum AbilityGraphViewMode {
    All = 0,
    LogicOnly = 1,
    CueOnly = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum AbilityInstancePolicy {
    NonInstanced = 0,
    Instance = 1,
    InstancedPerExecution = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum AbilityNetExecutionPolicy {
    LocalPredicted = 0,
    LocalOnly = 1,
    ServerInitiated = 2,
    ServerOnly = 3,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum AbilityNetSecurityPolicy {
    ClientOrServer = 0,
    ServerOnlyExecution = 1,
    ServerOnlyTermination = 2,
    ServerOnly = 3,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class AbilityPlayableContext extends PlayableContext {
    "ability": GameplayAbilityInstance<GameplayAbility>;
    "targetEntityList": Array<IEntity>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum AbilityReplicationPolicy {
    ReplicationYes = 0,
    ReplicationNo = 1,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   * @category equipment
   * @category weapon
   */
  type AbilitySpecHandle = number;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type AbilitySpecQuery = (spec: GameplayAbilitySpec) => boolean;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class AbilityTargetData extends ActiveEffectContext {
    "abilityHandler": number;
    addHitPosition(position: mw.Vector, reset?: boolean): void;
    addTarget(entity: IEntity): void;
    applyGameplayEffectSpec(gameplayEffect: GameplayEffectSpec, effectHandlers?: undefined | Array<number>): void;
    clear(): void;
    clone(): AbilityTargetData;
    copy(target: AbilityTargetData): AbilityTargetData;
    "direction": mw.Vector;
    "effectSpecHandler": number;
    equal(other: ActiveEffectContext): boolean;
    getAllHitPosition(): Array<mw.Vector>;
    getAllTargetEntities(result?: Array<IEntity>): Array<IEntity>;
    getInstigatorAbilitySysComponent(): AbilitySystemComponent;
    getOwnerAllTags(ret: TagContainer, specTagContainer?: undefined | TagContainer): boolean;
    getTargetAbilitySysComponent(): AbilitySystemComponent;
    "hitResult": mw.HitResult;
    "originPosition": mw.Vector;
    "originRotation": mw.Rotation;
    "randomSeed": number;
    removeTarget(entity: IEntity): void;
    "sourceObject": IAddressable<any>;
    toString(): string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class AbilityTargetGenericEvent<T = any> {
    "args": T;
    "eventName": string | number;
    "triggered": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class AbilityTrack extends TrackClip {
    addChildrenTrack(track: TrackClip): void;
    addClip(clip: TimelineClip): void;
    readonly "childrenTracks": Array<TrackClip>;
    readonly "childrenTracksCount": number;
    clear(): void;
    readonly "clips": Array<TimelineClip>;
    clone(): TrackClip;
    copy(target: TrackClip): AbilityTrack;
    createPlayable(context: AbilityPlayableContext, viewMode?: AbilityGraphViewMode): IPlayable;
    "duration": number;
    readonly "end": number;
    getChildrenClips(ret: Array<TimelineClip>): Array<TimelineClip>;
    readonly "hasCueTask": boolean;
    isClipValid(clip: TimelineClip): boolean;
    isFullOverAnyClip(clip: Inline_c4dde40ba1, except?: undefined | TimelineClip): null | TimelineClip;
    isOverlapsAnyClip(clip: Inline_b16a1e3608, except?: undefined | TimelineClip): null | TimelineClip;
    "name": string;
    readonly "onChildrenTracksAdded": UDelegate<(track: TrackClip) => void>;
    readonly "onChildrenTracksRemoved": UDelegate<(track: TrackClip, index: number) => void>;
    readonly "onClipAdded": UDelegate<(clip: TimelineClip, index: number) => void>;
    onClipMove(): void;
    readonly "onClipRefreshed": UDelegate<() => void>;
    readonly "onClipRemoved": UDelegate<(clip: TimelineClip) => void>;
    readonly "onParentTrackChanged": UDelegate<() => void>;
    readonly "onRecordStateChanged": UDelegate<(...arg: Array<any>) => any>;
    readonly "onTrackInfoChanged": UDelegate<() => void>;
    readonly "parentTrack": TrackClip;
    postDeSerialize(): void;
    removeChildrenTrack(track: TrackClip, ignoreEvent?: boolean): void;
    removeClip(clip: TimelineClip): void;
    sortClips(): void;
    readonly "start": number;
    updateDuration(): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class AbilityTriggerEventData {
    "tagOrEventName": string;
    "triggerSource": AbilityTriggerSource;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum AbilityTriggerSource {
    GameEvent = 0,
    TagAdded = 1,
    TagPresent = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface AbiProperty {
    "categorys"?: undefined | Array<string>;
    "property": string;
    "type": EValueType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type ActivateEffectQuery = (effect: ActiveGameplayEffect) => boolean;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface ActivateEffectRemainingResult {
    "endTime": number;
    "remainingTime": number;
    "startTime": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class ActiveEffectContext {
    "abilityHandler": number;
    addHitPosition(position: mw.Vector, reset?: boolean): void;
    clear(): void;
    clone(): ActiveEffectContext;
    copy(target: ActiveEffectContext): ActiveEffectContext;
    "direction": mw.Vector;
    "effectSpecHandler": number;
    equal(other: ActiveEffectContext): boolean;
    getAllHitPosition(): Array<mw.Vector>;
    getInstigatorAbilitySysComponent(): AbilitySystemComponent;
    getOwnerAllTags(ret: TagContainer, specTagContainer?: undefined | TagContainer): boolean;
    getTargetAbilitySysComponent(): AbilitySystemComponent;
    "hitResult": mw.HitResult;
    "originPosition": mw.Vector;
    "originRotation": mw.Rotation;
    "randomSeed": number;
    "sourceObject": IAddressable<any>;
    toString(): string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class ActiveEffectEvents {
    clear(): void;
    "onEffectRemoved": OnEffectRemovedInfo;
    "onEffectStackChange": OnEffectStackChange;
    "onInhibitionChanged": OnInhibitionChanged;
    "onTimeChange": OnTimeChange;
    "test": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type ActiveEffectHandler = number;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class ActiveEffectSystem {
    ___iterator_171(): Iterator<ActiveGameplayEffect, any, any>;
    readonly "activeGameplayEffects": Array<ActiveGameplayEffect>;
    addActiveEffectGrantTagsAndModifiers(effect: ActiveGameplayEffect, invokeCue: boolean): void;
    applyGameplayEffectSpec(spec: GameplayEffectSpec, key: PredictionKey): ApplyEffectRet;
    attemptRemoveActiveEffectsOnEffectApplication(inSpec: GameplayEffectSpec, inHandler: ActiveEffectHandler): void;
    checkDurationExpired(effect: ActiveGameplayEffect, index: number): boolean;
    clear(): void;
    executeActiveEffectsFrom(specToUse: GameplayEffectSpec): void;
    executePeriodicEffect(activeEffect: ActiveGameplayEffect): void;
    findByHandler(handler: ActiveEffectHandler): null | ActiveGameplayEffect;
    handleMagnitudeDependencyChange(effect: ActiveGameplayEffect, changedAggregator: Aggregator): void;
    hasApplicationImmunityToSpec(specToApply: GameplayEffectSpec): ActiveGameplayEffect;
    readonly "length": number;
    postGameplayEffectChanged(effect: ActiveGameplayEffect): void;
    postGameplayEffectReplicatedAdd(effect: ActiveGameplayEffect): void;
    postGameplayEffectReplicatedRemove(handler: ActiveEffectHandler): void;
    registerOwner(owner: AbilitySystemComponent, attributeSystem: IAttributeSystem): void;
    removeActiveEffect(index: number, stackToRemove: number, isPrematureRemoval: boolean): boolean;
    removeActiveEffectGrantTagsAndModifiers(effect: ActiveGameplayEffect, invokeCue: boolean): void;
    removeActiveGameplayEffectsByPredictionKey(predictionKey: number): void;
    toString(): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class ActiveGameplayEffect {
    "cacheStartServerTime": number;
    checkOnGoingTagRequirements(ownerTags: TagContainer, attributeComponent: ActiveEffectSystem, invokeCue: boolean): void;
    checkRemovalTagRequirements(tags: TagContainer, system: ActiveEffectSystem): boolean;
    clear(): void;
    "clientCachedStackCount": number;
    copy(other: ActiveGameplayEffect): void;
    readonly "duration": number;
    "durationHandler": number;
    readonly "endTime": number;
    equal(other: ActiveGameplayEffect): boolean;
    "events": ActiveEffectEvents;
    getOwningAbilitySystemComponent(): AbilitySystemComponent;
    getTimeRemaining(worldTime: number): number;
    "handler": number;
    initialize(): ActiveGameplayEffect;
    initialize(other: ActiveGameplayEffect): ActiveGameplayEffect;
    initialize(handler: ActiveEffectHandler, spec: GameplayEffectSpec, currentWorldTime: number, startServerTime: number): ActiveGameplayEffect;
    "isInhibited": boolean;
    "isPendingRemove": boolean;
    localCopy(other: ActiveGameplayEffect): void;
    "onActiveGameplayEffectPropertyChanged": Handler;
    readonly "period": number;
    "periodHandler": number;
    "predictionKey": number;
    recomputeStartWorldTime(container: AbilitySystemComponent): any;
    recomputeStartWorldTime(worldTime: number, serverWorldTime: number): any;
    resetForPool(): void;
    "spec": GameplayEffectSpec;
    "startServerWorldTime": number;
    "startWorldTime": number;
    toString(): string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class Aggregator {
    addAggregatorMod(evaluateData: number, modifierOp: ModifierOp, sourceTagReqs?: TagRequirements, targetTagReqs?: TagRequirements, activeHandle?: ActiveEffectHandler, channel?: number): void;
    addDependent(handle: ActiveEffectHandler): void;
    addModsFrom(source: Aggregator): void;
    broadcastOnDirty(): void;
    clear(): void;
    clone(): Aggregator;
    copy(ret: Aggregator): Aggregator;
    evaluate(parameters: AggregatorEvaluateParameters): number;
    evaluateBonus(parameters: AggregatorEvaluateParameters): number;
    evaluateContribution(parameters: AggregatorEvaluateParameters, specHandle: ActiveEffectHandler): number;
    evaluateQualificationForAllMods(parameters: AggregatorEvaluateParameters): void;
    evaluateToChannel(parameters: AggregatorEvaluateParameters, finalChannel: number): number;
    evaluateWithBase(baseValue: number, parameters: AggregatorEvaluateParameters): number;
    execModOnBaseValue(modifierOp: ModifierOp, evaluateMag: number): void;
    forEachMod(func: (value: AggregatorModifier) => void, thisArg?: any): void;
    getAllAggregatorMods(candidates: Map<number, Array<AggregatorModifier>>): Map<number, Array<AggregatorModifier>>;
    getBaseValue(): number;
    onActiveEffectDependenciesSwapped(swappedDependencies: Map<number, number>): void;
    "onDirty": OnAggregatorDirty;
    "onDirtyRecursive": OnAggregatorDirty;
    removeAggregatorMod(activeHandle: ActiveEffectHandler): void;
    removeDependent(handle: ActiveEffectHandler): void;
    reverseEvaluate(finalValue: number, parameters: AggregatorEvaluateParameters): number;
    setBaseValue(newVal: number, broadcastDirtyEvent?: boolean): void;
    updateAggregatorMod(handle: ActiveEffectHandler, attribute: Attribute, spec: GameplayEffectSpec, newHandler: ActiveEffectHandler): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class AggregatorEvaluateParameters {
    "appliedSourceTagFilter": TagContainer;
    "appliedTargetTagFilter": TagContainer;
    clone(): AggregatorEvaluateParameters;
    copy(target: AggregatorEvaluateParameters): AggregatorEvaluateParameters;
    "ignoreHandles": Set<number>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class AggregatorModifier {
    "activeHandle": ActiveEffectHandler;
    clone(): AggregatorModifier;
    copy(target: AggregatorModifier): AggregatorModifier;
    "evaluatedMagnitude": number;
    readonly "qualifies": boolean;
    setExplicitQualifies(value: boolean): void;
    "sourceTagReqs": TagRequirements;
    "stackCount": number;
    "targetTagReqs": TagRequirements;
    updateQualifies(parameters: AggregatorEvaluateParameters): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface ApplyEffectRet {
    "effect": ActiveGameplayEffect;
    "foundExistingStackable": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category audio
   * @category combat
   * @category environment
   * @category equipment
   * @category inventory
   * @category weapon
   */
  class Asset {
    "createTime": number;
    "creatorId": string;
    "localPathName": string;
    "name": string;
    onCreate(): void;
    postDeSerialize(): void;
    postLoaded(): void;
    preSerialize(): void;
    "uuid": string;
    "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, obj: Asset) => Asset;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   * @category equipment
   */
  enum AttackMethod {
    Slash = 0,
    Stab = 1,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class Attribute {
    "attributeSetName": string;
    readonly "name": string;
    "propertyName": string;
    recover(): void;
    toString(): string;
    "value": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class AttributeCaptureDef {
    "attribute": Attribute;
    "snapShot": boolean;
    "sourceOrTarget": EffectAttributeCaptureSource;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category scene
   * @category shop
   */
  class BaseComponent {
    readonly "_canEverTick": boolean;
    "_isDestroyed": boolean;
    "_referenceCount": number;
    readonly "canEverTick": boolean;
    destroy(): void;
    "entity": IEntity;
    getIsAuthority(): boolean;
    getOccupy(context?: any): any;
    getPropertyChangeDelegate(property: string): Readonly<mw.MulticastDelegate<(path: string, value: unknown, oldValue: unknown) => void>>;
    readonly "guid": string;
    readonly "internalBeselect": () => void;
    readonly "internalCloseDetailPanel": () => void;
    readonly "internalComponentAwake": () => void;
    readonly "internalComponentLateUpdate": (dt: number) => void;
    readonly "internalComponentStart": () => void;
    readonly "internalComponentUpdate": (dt: number) => void;
    readonly "internalDeselect": () => void;
    readonly "internalLiveBeselect": () => void;
    readonly "internalLiveDeselect": () => void;
    readonly "internalOnActivate": () => void;
    readonly "internalOnDeactivate": () => void;
    readonly "internalOnDestroy": () => void;
    readonly "internalOnGameModeChanged": (from: string, to: string) => void;
    readonly "internalOpenDetailPanel": () => void;
    "isAuthority": boolean;
    "isComponentInitializeCompleted": boolean;
    isPersistentSerialized(str: string): boolean;
    isRunningClient(): boolean;
    "name": string;
    notifyOtherComponentReady(): void;
    notSupportLazyInitInBuild(): boolean;
    onDestroyed(): void;
    "onPropertyChange": Readonly<mw.MulticastDelegate<(path: string, value: unknown, oldValue: unknown) => void>>;
    onSyncPresetAfterDeserialize(): void;
    preSyncPreset(): void;
    "stateFlag": number;
    supportLazyInit(): boolean;
    "tickEnable": boolean;
    readonly "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, baseComponent: BaseComponent) => void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  class BasicPlayerInfo {
    "aiPlayer"?: undefined | false | true;
    "joinTime"?: undefined | number;
    "playerId": string;
    "playerNickName": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class BitMask {
    addId(id: number): BitMask;
    addSet(set: ReadonlyBitMask): BitMask;
    clear(): BitMask;
    contains(id: number): boolean;
    equals(set: ReadonlyBitMask): boolean;
    readonly "flag": number;
    getDifference(set: ReadonlyBitMask, tempCacheClaimedResource: BitMask): BitMask;
    getOverLap(set: ReadonlyBitMask, tempCacheClaimedResource: BitMask): BitMask;
    hasAllIds(set: ReadonlyBitMask): boolean;
    hasAnyId(set: ReadonlyBitMask): boolean;
    readonly "isEmpty": boolean;
    removeId(id: number): BitMask;
    removeSet(set: ReadonlyBitMask): BitMask;
    set(bitMask: BitMask): BitMask;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface CallCompFuncInst {
    "component": number;
    "function": string;
    "params": Array<Property>;
    "type": EInstructionType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum ClipCaps {
    None = 0,
    Looping = "1 << 0",
    Extrapolation = "1 << 1",
    ClipIn = "1 << 2",
    SpeedMultiplier = "1 << 3",
    Blending = "1 << 4",
    AutoScale = "1 << 5 | SpeedMultiplier",
    Duration = "1 << 6",
    All = "~None",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum ClipExtrapolation {
    None = 0,
    Hold = 1,
    Loop = 2,
    PingPong = 3,
    Continue = 4,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category collision
   * @category physics
   */
  enum CollisionChannel {
    UnMapping = 1,
    Camera = 2,
    WorldStatic = 3,
    WorldDynamic = 4,
    Visibility = 5,
    Pawn = 6,
    Vehicle = 7,
    PhysicsBody = 8,
    UGC_Attached = 14,
    Projectile = 15,
    Trigger = 16,
    WorldUI = 17,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface ComponentEvent {
    "component": number;
    "event": string;
    "type": "component_event";
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category collision
   * @category combat
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category movement
   * @category scene
   * @category shop
   * @category test
   * @category weapon
   */
  interface ComponentEventHandler {
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  enum ComponentFlag {
    None = 0,
    ComponentOnAwake = "1 << 0",
    ComponentOnAwakeCalled = "1 << 1",
    ComponentOnStart = "1 << 2",
    ComponentOnStartCalled = "1 << 3",
    ComponentOnEnableCalled = "1 << 5",
    ComponentInitialized = "1 << 6",
    ComponentAddedCalled = "1 << 7",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category scene
   * @category shop
   * @category test
   */
  class ComponentFunctionCls {
    "_referenceCount": number;
    readonly "canEverTick": boolean;
    destroy(): void;
    "enable": boolean;
    "entity": IEntity;
    getOccupy(context?: any): any;
    readonly "isAuthority": boolean;
    isPersistentSerialized(str: string): boolean;
    "name": string;
    notSupportLazyInitInBuild(): boolean;
    onSyncPresetAfterDeserialize(): void;
    preSyncPreset(): void;
    "stateFlag": ComponentFlag;
    supportLazyInit(): boolean;
    "tickEnable": boolean;
    "version": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  type ComponentOccupyCalculateContext = {
    "calculateModelOccupy"?: undefined | ((assetId: string) => Promise<number>);
  };

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  type ComponentOccupyCalculateResult = {
    "attachedGameObjectIds"?: undefined | Array<string> | Set<string>;
    "occupy": number;
    "sharedOccupies"?: undefined | Array<ComponentSharedOccupy>;
  };

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  enum ComponentOwnership {
    Server = "1 << 0",
    Client = "1 << 1",
    Both = "Server | Client",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  type ComponentSharedOccupy = {
    "key": string;
    "occupy": number;
  };

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface CompProperty {
    "categorys"?: undefined | Array<string>;
    "component": number;
    "property": string;
    "type": EValueType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface ConditionInst {
    "else"?: undefined | Array<Instruction>;
    "left": Property;
    "operator": "==" | "!=" | "===" | "!==" | ">" | "<" | ">=" | "<=";
    "right": Property;
    "then": Array<Instruction>;
    "type": EInstructionType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   * @category inventory
   * @category weapon
   */
  class CurrencyInfo {
    "count": number;
    "type": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   * @category inventory
   * @category shop
   * @category weapon
   */
  enum CurrencyType {
    Gold = 0,
    Custom = 98989,
    GCoin = 119979,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface CustomApplyRequirement {
    canApplyGameplayEffect(def: GameplayEffect, spec: GameplayEffectSpec, sourceASC: AbilitySystemComponent): boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum DurationType {
    Instant = 0,
    Infinite = 1,
    HasDuration = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category collision
   * @category combat
   * @category effect
   * @category equipment
   * @category interaction
   * @category inventory
   * @category movement
   */
  enum EAOIInstanceState {
    Enabled = 1,
    Disabled = 1,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum EasingMethod {
    LINEAR = 0,
    CONSTANT = 1,
    QUAD_IN = 2,
    QUAD_OUT = 3,
    QUAD_IN_OUT = 4,
    QUAD_OUT_IN = 5,
    CUBIC_IN = 6,
    CUBIC_OUT = 7,
    CUBIC_IN_OUT = 8,
    CUBIC_OUT_IN = 9,
    QUART_IN = 10,
    QUART_OUT = 11,
    QUART_IN_OUT = 12,
    QUART_OUT_IN = 13,
    QUINT_IN = 14,
    QUINT_OUT = 15,
    QUINT_IN_OUT = 16,
    QUINT_OUT_IN = 17,
    SINE_IN = 18,
    SINE_OUT = 19,
    SINE_IN_OUT = 20,
    SINE_OUT_IN = 21,
    EXPO_IN = 22,
    EXPO_OUT = 23,
    EXPO_IN_OUT = 24,
    EXPO_OUT_IN = 25,
    CIRC_IN = 26,
    CIRC_OUT = 27,
    CIRC_IN_OUT = 28,
    CIRC_OUT_IN = 29,
    ELASTIC_IN = 30,
    ELASTIC_OUT = 31,
    ELASTIC_IN_OUT = 32,
    ELASTIC_OUT_IN = 33,
    BACK_IN = 34,
    BACK_OUT = 35,
    BACK_IN_OUT = 36,
    BACK_OUT_IN = 37,
    BOUNCE_IN = 38,
    BOUNCE_OUT = 39,
    BOUNCE_IN_OUT = 40,
    BOUNCE_OUT_IN = 41,
    SMOOTH = 42,
    FADE = 43,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  enum EEntityLifeStatus {
    None = 0,
    Serialized = "1 << 0",
    PostPendingAwake = "1 << 1",
    PreActivate = "1 << 2",
    PostActivate = "1 << 3",
    PreDeactivate = "1 << 4",
    PostDeactivate = "1 << 5",
    PreDestroy = "1 << 6",
    PostDestroy = "1 << 7",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  enum EEntityTag {
    TAG_None = 0,
    TAG_Floor = "1 << 0",
    TAG_Model = "1 << 1",
    TAG_Effect = "1 << 2",
    TAG_Character = "1 << 3",
    TAG_MeleeWeapon = "1 << 4",
    TAG_Gear = "1 << 5",
    TAG_Vehicle = "1 << 6",
    TAG_PlayerStart = "1 << 7",
    TAG_Scene = "1 << 8",
    TAG_HotWeapon = "1 << 9",
    TAG_Props = "1 << 10",
    TAG_WaterVolume = "1 << 11",
    TAG_CustomModel = "1 << 12",
    TAG_Anchor = "1 << 13",
    TAG_FloorAndModel = "TAG_Floor | TAG_Model | TAG_CustomModel",
    TAG_Weapon = "TAG_MeleeWeapon | TAG_HotWeapon",
    TAG_Items = "TAG_Props | TAG_Weapon",
    TAG_Picks = "1 << 14",
    TAG_Statue = "1 << 15",
    TAG_All = 2147483647,
    TAG_AllButPlayerStart = "TAG_All ^ TAG_PlayerStart",
    TAG_Locomotorium = "TAG_All ^ TAG_Character ^ TAG_PlayerStart ^ TAG_Vehicle",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class EffectAttributeCapture extends AttributeCaptureDef {
    "aggregator": Aggregator;
    attemptAddModsFromAggregator(aggregator: Aggregator): boolean;
    attemptCalculateAttributeContributionMagnitude(inEvalParams: AggregatorEvaluateParameters, handler: ActiveEffectHandler): number;
    attemptCalculateAttributeMagnitude(inEvalParams: AggregatorEvaluateParameters): number;
    attemptCalculateAttributeMagnitudeWithBase(base: number, inEvalParams: AggregatorEvaluateParameters): number;
    attemptCalculateBaseValue(): number;
    attemptCalculateBonus(inEvalParams: AggregatorEvaluateParameters): number;
    attemptGatherAttributeMods(inEvalParams: AggregatorEvaluateParameters, candidates: Map<number, Array<AggregatorModifier>>): null | Map<number, Array<AggregatorModifier>>;
    attemptGetAttributeAggregatorSnapshot(outAggregator: Aggregator): null | Aggregator;
    "attribute": Attribute;
    clear(): void;
    copy(from: EffectAttributeCapture): EffectAttributeCapture;
    registerLinkedAggregatorCallback(handler: ActiveEffectHandler): void;
    shouldRefreshLinkedAggregator(changedAggregator: Aggregator): boolean;
    "snapShot": boolean;
    "sourceOrTarget": EffectAttributeCaptureSource;
    unregisterLinkedAggregatorCallback(handler: ActiveEffectHandler): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class EffectAttributeCaptureContainer {
    addCaptureDefinition(attribute: Attribute, sourceOrTarget: EffectAttributeCaptureSource, snapShot: boolean): void;
    captureAttribute(inAsc: AbilitySystemComponent, target: EffectAttributeCaptureSource): void;
    clear(): void;
    clone(from: EffectAttributeCaptureContainer): void;
    findCaptureInfo(attribute: Attribute, target: EffectAttributeCaptureSource): undefined | EffectAttributeCapture;
    hasAllCaptures(checks: Array<AttributeCaptureDef>): boolean;
    registerLinkedAggregatorCallbacks(handler: ActiveEffectHandler): void;
    "source": Array<EffectAttributeCapture>;
    "target": Array<EffectAttributeCapture>;
    unregisterLinkedAggregatorCallbacks(handler: ActiveEffectHandler): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum EffectAttributeCaptureSource {
    Source = 0,
    Target = 1,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class EffectModCallbackData {
    clear(): void;
    set(inEffectSpec: GameplayEffectSpec, inEvaluateData: ModifierEvaluateData, inTarget: AbilitySystemComponent): EffectModCallbackData;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class EffectModifiedAttribute {
    "attribute": Attribute;
    "totalMagnitude": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class EffectModifierInfo {
    "_attribute": Attribute;
    "channel": number;
    "magnitudeModifier": IModifier;
    "modifierOp": ModifierOp;
    "sourceTags": TagRequirements;
    "targetTags": TagRequirements;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class EffectRemovalInfo {
    "effectContext": ActiveEffectContext;
    "isPrematureRemoval": boolean;
    set(stackCount: number, isPrematureRemoval: boolean, effectContext: ActiveEffectContext): EffectRemovalInfo;
    "stackCount": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  enum EInstructionType {
    call_comp_func = "call_comp_func",
    emit_event = "emit_event",
    emit_global_event = "emit_global_event",
    set_property = "set_property",
    condition_inst = "condition_inst",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface EmitEventInst {
    "event": string;
    "params": Array<Property>;
    "type": EInstructionType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  class Entity {
    destroy(removeGo?: boolean): void;
    emit(event: string, ...args: Array<any>): boolean;
    findAbilityIndexByDescriptionName(abilityName: string): number;
    getAbilities(): Array<AbilityBase>;
    getAbilityByIndex(index: number): AbilityBase;
    getAbilityCount(): number;
    getComponentById<T extends IComponent>(id: string): T;
    getComponents<T extends IComponent>(): Array<IComponent>;
    getComponentsByName<T extends IComponent>(clsName: string): Array<IComponent>;
    hasAbilityByDescriptionName(abilityName: string): boolean;
    hasEvent(event: string): boolean;
    off(event: string, callback: Function, thisArg?: unknown): IEventDispatcher;
    offAll(event: string): IEventDispatcher;
    offAll(thisArg?: unknown): IEventDispatcher;
    on(event: string, callback: Function, thisArg?: unknown, ...args: Array<any>): IEventDispatcher;
    once(event: string, callback: Function, thisArg?: unknown, ...args: Array<any>): IEventDispatcher;
    removeAbility<T extends AbilityBase>(ability: T, ignoreCheck?: undefined | false | true): boolean;
    removeAbilityByIndex(index: number, ignoreCheck?: undefined | false | true): boolean;
    waitDeserialized(): Promise<boolean>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  class EntityDescription {
    "abilities"?: undefined | string;
    "assetId": string;
    "components": string;
    "customdata": Map<string, unknown>;
    "deleteAbilities"?: undefined | string;
    "internalComponents": string;
    "transform"?: undefined | mw.Transform;
    "version"?: undefined | string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category audio
   * @category environment
   */
  class EnvironmentData {
    "cloudDensity": number;
    "cloudOpacity": number;
    "cloudSpeed": number;
    "cloudTexture": string;
    "cloudTint": string;
    "colorBiasValue": string;
    "colorTem": number;
    "disturbanceDensity": number;
    "disturbanceIntensity": number;
    "exposureCompensation": number;
    "floodLight": number;
    "fogAttenuationHeight": number;
    "fogDensity": number;
    "fogHeight": number;
    "fogInitDistance": number;
    "fogMaxOpacity": number;
    "fogScatteringColor": string;
    "globalContrast": number;
    "globalSaturation": number;
    "HorizontalFadeValue": number;
    "ID": number;
    "imgGuid": string;
    "isDisturbance": boolean;
    "isEnableCloud": boolean;
    "isEnableColorTem": boolean;
    "isEnabledCastShadows": boolean;
    "isEnableFog": boolean;
    "isEnableMoon": boolean;
    "isEnableShade": boolean;
    "isEnableStar": boolean;
    "isEnableSun": boolean;
    "moonIntensity": number;
    "moonSize": number;
    "moonTexture": string;
    "moonTint": string;
    "parallelLightColor": string;
    "parallelLightIntensity": number;
    "particleSize": number;
    "pitchAngle": number;
    "preset": number;
    "shadowDistance": number;
    "skyboxBottomTint": string;
    "skyboxBrightness": number;
    "skyboxDomeTint": string;
    "skyboxMidTint": string;
    "skyboxRotation": number;
    "skyboxTexture": string;
    "skyboxTopTint": string;
    "skyLightColor": string;
    "skyLightIntensity": number;
    "skyLightTexture": string;
    "skyName": string;
    "skyNameID": string;
    "starBrightness": number;
    "starDensity": number;
    "starTexture": string;
    "style": number;
    "sunIntensity": number;
    "sunScatteringColor": string;
    "sunScatteringIndex": number;
    "sunScatteringInitDis": number;
    "sunSize": number;
    "sunTexture": string;
    "sunTint": string;
    "weatherIntensity": number;
    "weatherType": number;
    "yawAngle": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category combat
   * @category effect
   * @category interaction
   * @category inventory
   * @category movement
   * @category ui
   */
  enum EPoolReusePhase {
    None = 0,
    Reset = 1,
    Resume = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   * @category weapon
   */
  class EquipmentBaseAttribute {
    "attachBoneName": mw.HumanoidSlotType.Hair | mw.HumanoidSlotType.Head | mw.HumanoidSlotType.LeftHead | mw.HumanoidSlotType.RightHead | mw.HumanoidSlotType.Glasses | mw.HumanoidSlotType.Eyes | mw.HumanoidSlotType.FaceOrnamental | mw.HumanoidSlotType.Mouse | mw.HumanoidSlotType.LeftShoulder | mw.HumanoidSlotType.RightShoulder | mw.HumanoidSlotType.LeftGlove | mw.HumanoidSlotType.RightGlove | mw.HumanoidSlotType.BackOrnamental | mw.HumanoidSlotType.LeftBack | mw.HumanoidSlotType.RightBack | mw.HumanoidSlotType.LeftHand | mw.HumanoidSlotType.RightHand | mw.HumanoidSlotType.LeftFoot | mw.HumanoidSlotType.RightFoot | mw.HumanoidSlotType.Buttocks | mw.HumanoidSlotType.Rings | mw.HumanoidSlotType.Nameplate | mw.HumanoidSlotType.ChatFrame | mw.HumanoidSlotType.Root | mw.HumanoidSlotType.LeftLowerArm | mw.HumanoidSlotType.RightLowerArm | mw.HumanoidSlotType.LeftThigh | mw.HumanoidSlotType.RightThigh | mw.HumanoidSlotType.LeftCalf | mw.HumanoidSlotType.RightCalf | mw.HumanoidSlotType.FirstpersonCamera | mw.NonHumanoidSlotType.Root | mw.NonHumanoidSlotType.Chest | mw.NonHumanoidSlotType.UpperSpine | mw.NonHumanoidSlotType.LowerSpine | mw.NonHumanoidSlotType.Neck | mw.NonHumanoidSlotType.Head | mw.NonHumanoidSlotType.FrontalLeftFoot | mw.NonHumanoidSlotType.FrontalRightFoot | mw.NonHumanoidSlotType.RearLeftFoot | mw.NonHumanoidSlotType.RearRightFoot | mw.NonHumanoidSlotType.Tail | mw.NonHumanoidSlotType.RightHand | mw.NonHumanoidSlotType.LeftHand | mw.NonHumanoidSlotType.HumanoidHead | mw.NonHumanoidSlotType.HumanoidChest | mw.NonHumanoidSlotType.DorsalFin | mw.NonHumanoidSlotType.LeftFin | mw.NonHumanoidSlotType.RightFin | mw.NonHumanoidSlotType.RightWing | mw.NonHumanoidSlotType.LeftWing | mw.NonHumanoidSlotType.ExtraRightFoot1 | mw.NonHumanoidSlotType.ExtraRightFoot2 | mw.NonHumanoidSlotType.ExtraRightFoot3 | mw.NonHumanoidSlotType.ExtraRightFoot4 | mw.NonHumanoidSlotType.ExtraLeftFoot1 | mw.NonHumanoidSlotType.ExtraLeftFoot2 | mw.NonHumanoidSlotType.ExtraLeftFoot3 | mw.NonHumanoidSlotType.ExtraLeftFoot4 | mw.NonHumanoidSlotType.Mouth | mw.NonHumanoidSlotType.RightEye | mw.NonHumanoidSlotType.LeftEye | mw.NonHumanoidSlotType.Crest | mw.NonHumanoidSlotType.ExtraRightTail1 | mw.NonHumanoidSlotType.ExtraRightTail2 | mw.NonHumanoidSlotType.ExtraLeftTail1 | mw.NonHumanoidSlotType.ExtraLeftTail2 | mw.NonHumanoidSlotType.RearRightWing | mw.NonHumanoidSlotType.RearLeftWing | mw.NonHumanoidSlotType.HumanoidLeftEye | mw.NonHumanoidSlotType.HumanoidRightEye | mw.NonHumanoidSlotType.HumanoidMouth | mw.NonHumanoidSlotType.HumanoidPelvis | mw.NonHumanoidSlotType.HumanoidSpine | mw.NonHumanoidSlotType.HumanoidNeck | mw.NonHumanoidSlotType.FrontTentacle | mw.NonHumanoidSlotType.RearTentacle | mw.NonHumanoidSlotType.LeftTentacle1 | mw.NonHumanoidSlotType.LeftTentacle2 | mw.NonHumanoidSlotType.LeftTentacle3 | mw.NonHumanoidSlotType.RightTentacle1 | mw.NonHumanoidSlotType.RightTentacle2 | mw.NonHumanoidSlotType.RightTentacle3;
    "giveAbilities": Array<GameplayAbilitySpecDef>;
    "giveEffects": Array<string>;
    "idleAnimation": string;
    "idleAnimationSpeed": number;
    "IK_leftHandPoint": mw.Vector;
    "loadAnimation": string;
    "primaryGripPoint": mw.Transform;
    "runAnimation": string;
    "runAnimationSpeed": number;
    "unloadAnimation": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   * @category inventory
   * @category weapon
   */
  enum EquipmentSlotType {
    RightHand = "RightHand",
    LeftHand = "LeftHand",
    Head = "Head",
    Chest = "Chest",
    Legs = "Legs",
    Feet = "Feet",
    Ring = "Ring",
    necklace = "necklace",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  enum EValueType {
    param = "param",
    params = "params",
    abi_prop = "abi_prop",
    comp_prop = "comp_prop",
    method_res = "method_res",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  type Event = ComponentEvent | OtherEvent;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface EventListener {
    "event": Event;
    "instructions": Array<Instruction>;
    "once"?: undefined | false | true;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class GameplayAbility extends Asset {
    "abilityGraph": AbilityTrack;
    readonly "abilityTag": TagContainer;
    readonly "abilityTriggers": Array<AbilityTriggerEventData>;
    readonly "activationBlockedTags": TagContainer;
    readonly "activationOwnerTag": TagContainer;
    readonly "activationRequiredTags": TagContainer;
    readonly "blockAbilitiesTag": TagContainer;
    readonly "cancelAbilitiesWithTag": TagContainer;
    "coolDown": number;
    readonly "coolDownEffect": GameplayEffectName;
    readonly "coolDownTag": TagContainer;
    readonly "costEffect": GameplayEffectName;
    createAbilityInstance<T extends GameplayAbilityInstance>(): T;
    "createTime": number;
    "creatorId": string;
    readonly "defaultInstance": GameplayAbilityInstance<GameplayAbility>;
    readonly "instancePolicy": AbilityInstancePolicy;
    "localPathName": string;
    "name": string;
    readonly "netExecutePolicy": AbilityNetExecutionPolicy;
    readonly "netSecurityPolicy": AbilityNetSecurityPolicy;
    onCreate(): void;
    postDeSerialize(): void;
    postLoaded(): void;
    preSerialize(): void;
    readonly "replicatedPolicy": AbilityReplicationPolicy;
    "replicateInputDirectly": boolean;
    readonly "retriggerInstancedAbility": boolean;
    readonly "serverRespectsRemoteAbilityCancellation": boolean;
    readonly "sourceBlockedTags": TagContainer;
    readonly "sourceRequiredTags": TagContainer;
    readonly "targetBlockedTags": TagContainer;
    readonly "targetRequiredTags": TagContainer;
    "uuid": string;
    "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, obj: Asset) => Asset;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class GameplayAbilityInstance<T = GameplayAbility> {
    applyGameplayEffectToOwner(specHandle: AbilitySpecHandle, actorInfo: AbilityActorInfo, activationInfo: AbilityActivateInfo, effect: GameplayEffect, level: number): number;
    applyGameplayEffectToTarget(target: AbilityTargetData, specHandle: AbilitySpecHandle, actorInfo: AbilityActorInfo, activationInfo: AbilityActivateInfo, effect: GameplayEffect, level?: undefined | number, stack?: number): number | Array<number>;
    callActivateAbility(handler: AbilitySpecHandle, actorInfo: AbilityActorInfo, activationInfo: AbilityActivateInfo, eventData?: undefined | GameplayEventData): void;
    canActivateAbility(handler: AbilitySpecHandle, actorInfo: AbilityActorInfo, optionRelevantTag: TagContainer, sourceTags?: undefined | TagContainer, targetTags?: undefined | TagContainer): boolean;
    cancelAbility(replicatedCancelAbility: boolean): void;
    cancelAbility(abilityHandler: AbilitySpecHandle, actorInfo: AbilityActorInfo, activationInfo: AbilityActivateInfo, replicatedCancelAbility: boolean): void;
    checkCoolDown(handler: AbilitySpecHandle, actorInfo: AbilityActorInfo, optionRelevantTag: TagContainer): boolean;
    checkCost(handler: AbilitySpecHandle, actorInfo: AbilityActorInfo, optionRelevantTag: TagContainer): boolean;
    commitAbility(handler: AbilitySpecHandle, actorInfo: AbilityActorInfo, activationInfo: AbilityActivateInfo, optionRelevantTag?: undefined | TagContainer): boolean;
    commitExecute(handler: AbilitySpecHandle, actorInfo: AbilityActorInfo, activationInfo: AbilityActivateInfo): void;
    readonly "currentAbilityActor": AbilityActorInfo;
    readonly "currentActivationInfo": AbilityActivateInfo;
    readonly "currentSpecHandle": number;
    decrementListLock(): void;
    endAbility(replicatedEndedAbility: boolean, wasCanceled: boolean): any;
    endAbility(abilityHandler: AbilitySpecHandle, actorInfo: AbilityActorInfo, activationInfo: AbilityActivateInfo, replicatedEndedAbility: boolean, wasCanceled: boolean): void;
    getAbilityCoolDownTag(): TagContainer;
    getCoolDownRemaining(actorInfo: AbilityActorInfo, handler: AbilitySpecHandle): number;
    getCoolDownTime(handler?: AbilitySpecHandle, actorInfo?: undefined | AbilityActorInfo, activationInfo?: undefined | AbilityActivateInfo): number;
    getTaskOwner(): IEntity;
    getTaskQueue(): ITaskQueue;
    incrementListLock(): void;
    "info": T;
    initialize(ability: T): void;
    inputPressed(handle: AbilitySpecHandle, actorInfo: AbilityActorInfo, activationInfo: AbilityActivateInfo): void;
    inputReleased(handle: AbilitySpecHandle, actorInfo: AbilityActorInfo, activationInfo: AbilityActivateInfo): void;
    readonly "isActive": boolean;
    "isMarkPendingKillOnAbilityEnd": boolean;
    makeGameplayEffectSpec(abilityHandler: AbilitySpecHandle, actorInfo: AbilityActorInfo, activationInfo: AbilityActivateInfo, effect: GameplayEffect, level: number): GameplayEffectSpec;
    readonly "onAbilityCancelled": OnGameplayAbilityCancelled;
    readonly "onAbilityEnded": OnGameplayAbilityEnded;
    readonly "onAbilityStateChanged": OnGameplayAbilityStateChanged;
    onGiveAbility(actorInfo: AbilityActorInfo, specHandle: AbilitySpecHandle): void;
    onRemoveAbility(actorInfo: AbilityActorInfo, specHandle: GameplayAbilitySpec): void;
    onTaskActivated(task: Task): void;
    onTaskDeactivated(task: Task): void;
    onTaskInitialized(task: Task): void;
    postUnSerialize(): void;
    preSerialize(): void;
    runAbilityGraph(handle: AbilitySpecHandle, actorInfo: AbilityActorInfo, activationInfo: AbilityActivateInfo, registerEndAbility?: boolean): void;
    setCurrentActivateInfo(activateInfo: AbilityActivateInfo): void;
    setCurrentActorInfo(handle: AbilitySpecHandle, actorInfo: AbilityActorInfo): void;
    setCurrentInfo(handle: AbilitySpecHandle, actorInfo: AbilityActorInfo, activateInfo: AbilityActivateInfo): void;
    "shouldBlockingOtherAbilities": boolean;
    shouldResponseToEvent(event: string, ...args: Array<any>): boolean;
    waitTargetResult(): Promise<AbilityTargetData>;
    waitTargetResult(handle: AbilitySpecHandle, activationInfo: AbilityActivateInfo, actorInfo: AbilityActorInfo): Promise<AbilityTargetData>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   * @category equipment
   * @category weapon
   */
  type GameplayAbilityName = string | number | symbol;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class GameplayAbilitySpec {
    "abilityInfo": GameplayAbility;
    readonly "abilityTag": TagContainer;
    "activateAtOnce": boolean;
    "activateCount": number;
    "activationInfo": AbilityActivateInfo;
    appendAbilityTag(tag: string): void;
    appendDynamicAbilityTags(tags: TagContainer): void;
    clear(): void;
    readonly "dynamicAbilityTags": ReadonlyTagContainer;
    getAbilityInstance(): Array<GameplayAbilityInstance<GameplayAbility>>;
    "handler": AbilitySpecHandle;
    initialize(handler: AbilitySpecHandle): void;
    "inputId": number;
    "inputPressed": boolean;
    readonly "isActive": boolean;
    isFromPool(): boolean;
    "level": number;
    "lockHandler": boolean;
    markFromPool(value: boolean): void;
    readonly "nonReplicatedInstance": Array<GameplayAbilityInstance<GameplayAbility>>;
    "pendingToRemove": boolean;
    postUnSerialize(): void;
    preSerialize(): void;
    readonly "primaryInstance": null | GameplayAbilityInstance<GameplayAbility>;
    pushInstance(instance: GameplayAbilityInstance<GameplayAbility>, replicated: boolean): void;
    removeAbilityTag(tag: string): void;
    "removeAfterActivation": boolean;
    removeDynamicAbilityTags(tags: TagContainer): void;
    removeInstance(instance: GameplayAbilityInstance<GameplayAbility>, replicated: boolean): void;
    readonly "replicatedInstance": Array<GameplayAbilityInstance<GameplayAbility>>;
    "setByCaller": Map<string, any>;
    "sourceObject": IAddressable<any>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   * @category equipment
   * @category weapon
   */
  class GameplayAbilitySpecDef {
    "ability": GameplayAbilityName;
    "assignHandler": AbilitySpecHandle;
    "inputId": number;
    "level": number;
    "removePolicy": GrantedAbilityRemovePolicy;
    "setByCaller": Map<string, number>;
    "sourceObject": IAddressable<any>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class GameplayEffect extends Asset {
    readonly "applicationRequirements": TagRequirements;
    readonly "assetsTag": TagContainer;
    readonly "chanceToApply": number;
    readonly "clearStackOnOverflow": boolean;
    "createTime": number;
    "creatorId": string;
    readonly "cueTag": TagContainer;
    readonly "customApplyRequirement": CustomApplyRequirement;
    readonly "customCalculator": Array<ICalculation>;
    readonly "denyOverflowApplication": boolean;
    readonly "duration": number;
    readonly "durationPolicy": DurationType;
    readonly "executePeriodicOnApplication": boolean;
    readonly "grantAbilities": Array<GameplayAbilitySpecDef>;
    readonly "grantedApplicationImmunityTags": TagRequirements;
    readonly "grantTags": TagContainer;
    readonly "immunityQuery"?: undefined | IGameplayEffectQuery;
    "localPathName": string;
    readonly "modifiers": Array<EffectModifierInfo>;
    "name": string;
    onCreate(): void;
    readonly "ongoingTagRequirements": TagRequirements;
    readonly "overflowEffects": Array<string>;
    readonly "period": number;
    readonly "periodInhibitionPolicy": PeriodInhibitionPolicy;
    postDeSerialize(): void;
    postLoaded(): void;
    readonly "prematureExpirationEffects": Array<string>;
    preSerialize(): void;
    readonly "removalEffectWithTags": TagContainer;
    readonly "removalTagRequirements": TagRequirements;
    readonly "routineExpirationEffectClasses": Array<string>;
    readonly "stackDurationRefreshPolicy": StackRefreshPolicy;
    readonly "stackExpirationPolicy": StackExpirationPolicy;
    readonly "stackLimit": number;
    readonly "stackPeriodRefreshPolicy": StackRefreshPolicy;
    readonly "stackType": StackingType;
    "uuid": string;
    "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, obj: Asset) => Asset;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class GameplayEffectCustomExecutionOutput {
    "handlerGameplayCuesManually": boolean;
    "handlerStackCountManually": boolean;
    "outputModifiers": Array<ModifierEvaluateData>;
    reset(): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class GameplayEffectCustomExecutionParameters {
    "passedInTags": TagContainer;
    reset(): void;
    "spec": GameplayEffectSpec;
    "targetAsc": AbilitySystemComponent;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type GameplayEffectName = string;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class GameplayEffectSpec {
    addDynamicAssetsTag(tag: string): void;
    addDynamicGrantedTag(tag: string): void;
    addModifiedAttribute(attribute: Attribute): EffectModifiedAttribute;
    appendsDynamicAssetsTag(tag: TagContainer): void;
    appendsDynamicGrantedTag(tag: TagContainer): void;
    attemptCalculateDurationFromDef(): number;
    calculateModifiedDuration(): number;
    calculateModifierMagnitudes(): void;
    captureAttributeDataFromTarget(target: AbilitySystemComponent): void;
    captureDataFromSource(skipRecapture?: boolean): void;
    "capturedRelevantAttributes": EffectAttributeCaptureContainer;
    "capturedSourceTag": TagContainerAggregator;
    "capturedTargetTag": TagContainerAggregator;
    "chanceToApply": number;
    clear(): void;
    "clientPredictionKey": number;
    clone(): GameplayEffectSpec;
    "context": ActiveEffectContext;
    copy(source: GameplayEffectSpec): GameplayEffectSpec;
    copySetByCallerMagnitude(source: GameplayEffectSpec): void;
    "duration": number;
    "dynamicAssetsTag": TagContainer;
    "dynamicGrantedTag": TagContainer;
    "effect": Readonly<GameplayEffect>;
    equal(other: GameplayEffectSpec): boolean;
    getAllAssetTags(ret: TagContainer): TagContainer;
    getAllGrantedTags(ret: TagContainer): TagContainer;
    getLevel(): number;
    getModifiedAttribute(attribute: Attribute): EffectModifiedAttribute;
    getModifierMagnitude(index: number, factorInStackCount: boolean): number;
    getSetByCallerMagnitude(setByCallerName: string, errorWhenNotFound: boolean, defaultNotFound?: number): number;
    "grantedAbilitySpecs": Array<GameplayAbilitySpecDef>;
    initialize(def: GameplayEffect, context: ActiveEffectContext, level: number): GameplayEffectSpec;
    initializeFromLinkedSpec(effect: GameplayEffect, linkedSpec: GameplayEffectSpec): void;
    mergeSetByCallerMagnitudes(magnitudes: Map<string, number>): void;
    "modifiedAttributes": Array<EffectModifiedAttribute>;
    "modifiers": Array<ModifierSpec>;
    "period": number;
    postUnSerialize(): void;
    preSerialize(): void;
    readonly "setByCaller": Map<string, any>;
    setByCallerMagnitude(setByCallerName: string, magnitude: number): void;
    setDuration(duration: number, lockDuration: boolean): void;
    setLevel(value: number): void;
    "stackCount": number;
    readonly "targetEffectSpecs": Array<GameplayEffectSpec>;
    toString(): string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class GameplayEventData {
    "eventMagnitude": number;
    "eventName": string;
    "instigatorTag": TagContainer;
    "targetTag": TagContainer;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type GameplayTaskResource = number;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  class GameState<PlayerInfo = BasicPlayerInfo> {
    isPlayerIn(playerId: string): boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category equipment
   * @category weapon
   */
  enum GrantedAbilityRemovePolicy {
    CancelAbilityImmediately = 0,
    RemoveAbilityOnEnd = 1,
    DoNothing = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   * @category decorate
   */
  class Handler extends THandler<any> {
    "args": null | Array<any>;
    "caller": unknown;
    clear(): THandler<any>;
    "method": any;
    "once": boolean;
    recover(): void;
    "ref": number;
    run(): any;
    runWith(...args: any): any;
    setTo(caller: any, method: any, args?: undefined | null | Array<unknown>, once?: boolean): THandler<any>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   * @category equipment
   * @category weapon
   */
  interface IAddressable<T> {
    clear(): any;
    get(): T | Promise<T>;
    set(value: T): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category decorate
   * @category ui
   */
  interface IAggregator {
    get<T>(): T;
    getChild<T>(name: string): T;
    getChildAggregator(): IAggregator;
    "parent": IAggregator;
    "popPanelHandler": Handler;
    "refreshHandler": Handler;
    set<T>(value: any): any;
    setChild<T>(name: string, value: T): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category collision
   * @category combat
   * @category effect
   * @category equipment
   * @category interaction
   * @category inventory
   * @category movement
   */
  interface IAOIInstance {
    "aoiState"?: undefined | EAOIInstanceState | EAOIInstanceState;
    getDistanceSquared(): number;
    getEntity(): IEntity;
    "localPos"?: undefined | mw.Vector;
    onAOIStateChanged(state: EAOIInstanceState): any;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface IAttributeSystem {
    applyModToAttribute(attribute: Attribute, modifierOp: ModifierOp, modifierMagnitude: number, modData?: undefined | EffectModCallbackData): any;
    findAttributeAggregator(attribute: Attribute, createdWhenNotFound?: undefined | false | true): any;
    findAttributeChangeEvents(attribute: Attribute, createdWhenNotFound?: undefined | false | true): OnAttributeChangeEvent;
    getAttributeValue(attribute: Attribute, attributeSet: any): number;
    setAttributeBaseValue(attribute: Attribute, newVal: number): any;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface IBatchedTransform {
    "dirty": boolean;
    "entity": IEntity;
    "worldTransform": mw.Transform;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface ICalculation {
    execute(params: GameplayEffectCustomExecutionParameters, output: GameplayEffectCustomExecutionOutput): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface IClipAsset<T> {
    "clipCaps"?: undefined | ClipCaps | ClipCaps | ClipCaps | ClipCaps | ClipCaps | ClipCaps | ClipCaps | ClipCaps | ClipCaps;
    clone(): T;
    "duration"?: undefined | number;
    "name": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface IComponent {
    "enable": boolean;
    "entity": IEntity;
    "name": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface ICreateEntityInfo {
    "components"?: undefined | Array<global_Class>;
    "disenable"?: undefined | false | true;
    "enableAnchorage"?: undefined | false | true;
    "isActorAtLevel"?: undefined | false | true;
    "isUsingActorName"?: undefined | false | true;
    "replicated"?: undefined | false | true;
    "static"?: undefined | false | true;
    "templateEntity"?: undefined | IEntity;
    "transform"?: undefined | mw.Transform;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category collision
   * @category combat
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category movement
   * @category scene
   * @category shop
   * @category test
   * @category weapon
   */
  interface IEntity {
    /**
     * 添加组件
     * @param componentClsName 组件对应的类名
     * @aiExport
     * @category entity
     * @since 1.0
     * @capability framework.entity
     */
    addComponent<T extends IComponent>(componentClsName: string): T;
    /**
     * 获取指定组件,如果entity中包含多个相同类型的组件，则返回第一个组件
     * @param componentClsName 组件对应的类名
     * @aiExport
     * @category entity
     * @since 1.0
     * @capability framework.entity
     */
    getComponent<T extends IComponent>(componentClsName: string): T;
    readonly "basicInfo": BasicInfoComponent;
    destroy(removeGo?: undefined | false | true): void;
    emit(event: string, ...args: Array<any>): boolean;
    "enable": boolean;
    "enableInScene": boolean;
    "gameObject": mw.GameObject;
    "gameObjectId": string;
    getComponentById<T extends IComponent>(id: string): T;
    getComponents(): Array<IComponent>;
    getComponentsByName(clsName: string): Array<IComponent>;
    hasEvent(event: string): boolean;
    "name": string;
    off(event: string, callback: Function, thisArg?: unknown): IEventDispatcher;
    offAll(event: string): IEventDispatcher;
    offAll(thisArg?: unknown): IEventDispatcher;
    on(event: string, callback: Function, thisArg?: unknown, ...args: Array<any>): IEventDispatcher;
    once(event: string, callback: Function, thisArg?: unknown, ...args: Array<any>): IEventDispatcher;
    "playerController"?: undefined | IPlayerController;
    "ready": boolean;
    removeComponent<T extends IComponent>(component: global_Constructor | global_AbstractedConstructor): boolean;
    removeComponent<T extends IComponent>(componentClsName: string): boolean;
    removeComponent<T extends IComponent>(component: T): boolean;
    "scene": IScene;
    readonly "transform": TransformComponent;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface IEventDispatcher {
    emit(event: string, ...args: Array<any>): boolean;
    hasEvent(event: string): boolean;
    off(event: string, callback: Function, thisArg?: unknown): IEventDispatcher;
    offAll(event: string): IEventDispatcher;
    offAll(thisArg?: unknown): IEventDispatcher;
    on(event: string, callback: Function, thisArg?: unknown, ...args: Array<any>): IEventDispatcher;
    once(event: string, callback: Function, thisArg?: unknown, ...args: Array<any>): IEventDispatcher;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface IGameplayEffectQuery {
    match(target: GameplayEffectSpec): boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   * @category effect
   * @category interaction
   * @category inventory
   * @category spawning
   */
  interface ILazyWakeCapable {
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface ILifecycleComponent {
    "_referenceCount": number;
    readonly "canEverTick": boolean;
    "enable": boolean;
    "entity": IEntity;
    "executeOrder"?: undefined | number;
    getIsAuthority(): boolean;
    getOccupy(context?: ComponentOccupyCalculateContext): number | ComponentOccupyCalculateResult | Promise<number | ComponentOccupyCalculateResult>;
    "id"?: undefined | string;
    readonly "internalBeselect": Function;
    readonly "internalCloseDetailPanel": Function;
    readonly "internalComponentAwake": Function;
    readonly "internalComponentLateUpdate": Function;
    readonly "internalComponentStart": Function;
    readonly "internalComponentUpdate": Function;
    readonly "internalDeselect": Function;
    readonly "internalLiveBeselect": Function;
    readonly "internalLiveDeselect": Function;
    readonly "internalOnActivate": Function;
    readonly "internalOnDeactivate": Function;
    readonly "internalOnDestroy": Function;
    readonly "internalOnGameModeChanged"?: undefined | Function;
    readonly "internalOpenDetailPanel": Function;
    "isAuthority": boolean;
    "isPermanent"?: undefined | false | true;
    isPersistentSerialized(str: string): boolean;
    "name": string;
    notSupportLazyInitInBuild(): boolean;
    onDestroyed(): void;
    "ownership"?: undefined | ComponentOwnership | ComponentOwnership | ComponentOwnership;
    preSyncPreset(): void;
    "stateFlag"?: undefined | ComponentFlag | ComponentFlag | ComponentFlag | ComponentFlag | ComponentFlag | ComponentFlag | ComponentFlag | ComponentFlag;
    supportLazyInit(): boolean;
    "tickEnable": boolean;
    "version"?: undefined | string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface IMediator {
    addEvent(): void;
    closeUI(): void;
    displayUI(): void;
    forceCloseUI(destroy?: undefined | false | true): void;
    getAddUILayer(): number;
    getUI(): mw.UIScript;
    initialization(): void;
    initUI(): void;
    "mediatorName": any;
    "openData": OpenUIData;
    openUI(): void;
    "panel": any;
    refreshUI(): void;
    removeEvent(): void;
    unDisplayUI(): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class IModifier {
    attemptCalculateMagnitude(effect: GameplayEffectSpec): number;
    attemptRecalculateMagnitudeFromDependentAggregatorChange(inRelevantSpec: GameplayEffectSpec, changedAggregator: Aggregator): number;
    canCalculateMagnitude(effect: GameplayEffectSpec): boolean;
    getAttributeCaptureDefinition(source: Array<AttributeCaptureDef>): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface Inline_1db48e7d4e {
    "duration": number;
    "end": number;
    "start": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category collision
   * @category combat
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category movement
   * @category scene
   * @category shop
   * @category test
   * @category weapon
   */
  interface Inline_385e2428cf {
    "x": boolean;
    "y": boolean;
    "z": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category collision
   * @category combat
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category movement
   * @category scene
   * @category shop
   * @category test
   * @category weapon
   */
  interface Inline_64d9856528 {
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface Inline_7841299f8f {
    "x": boolean;
    "y": boolean;
    "z": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category collision
   * @category combat
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category movement
   * @category scene
   * @category shop
   * @category test
   * @category weapon
   */
  interface Inline_894729dc93 {
    "x": boolean;
    "y": boolean;
    "z": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category collision
   * @category combat
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category movement
   * @category scene
   * @category shop
   * @category test
   * @category weapon
   */
  interface Inline_99f5d74947 {
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category collision
   * @category combat
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category movement
   * @category scene
   * @category shop
   * @category test
   * @category weapon
   */
  interface Inline_ab971f6e89 {
    "x": boolean;
    "y": boolean;
    "z": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface Inline_b16a1e3608 {
    "duration": number;
    "end": number;
    "start": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface Inline_c25bf6a3d1 {
    "x": boolean;
    "y": boolean;
    "z": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface Inline_c4dde40ba1 {
    "duration": any;
    "start": any;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface Inline_dfe7c608f0 {
    "x": boolean;
    "y": boolean;
    "z": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface Inline_efaee7d9d5 {
    "duration": any;
    "start": any;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  type Instruction = CallCompFuncInst | EmitEventInst | SetPropInst | ConditionInst;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  class InternalComponent implements IComponent{
    "_referenceCount": number;
    readonly "canPersistentSerializedIgnore": boolean;
    getIsAuthority(): boolean;
    getOccupy(context?: any): any;
    "id": string;
    "isAuthority": boolean;
    isPersistentSerialized(str: string): boolean;
    "name": string;
    notSupportLazyInitInBuild(): boolean;
    onDestroyed(): void;
    onSyncPresetAfterDeserialize(): void;
    "ownership": ComponentOwnership;
    preSyncPreset(): void;
    "stateFlag": number;
    'enable': boolean;
    'entity': IEntity;
    supportLazyInit(): boolean;
    readonly "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, component: InternalComponent) => void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  class InternalLifeComponent extends InternalComponent {
    "_referenceCount": number;
    readonly "binder": mw.GameObject;
    readonly "canEverTick": boolean;
    readonly "canPersistentSerializedIgnore": boolean;
    getIsAuthority(): boolean;
    getOccupy(context?: any): any;
    "id": string;
    readonly "internalBeselect": () => void;
    readonly "internalCloseDetailPanel": () => void;
    readonly "internalComponentAwake": () => void;
    readonly "internalComponentLateUpdate": (dt: number) => void;
    readonly "internalComponentStart": () => void;
    readonly "internalComponentUpdate": (dt: number) => void;
    readonly "internalDeselect": () => void;
    readonly "internalLiveBeselect": () => void;
    readonly "internalLiveDeselect": () => void;
    readonly "internalOnActivate": () => void;
    readonly "internalOnDeactivate": () => void;
    readonly "internalOnDestroy": () => void;
    readonly "internalOnGameModeChanged": (from: string, to: string) => void;
    readonly "internalOpenDetailPanel": () => void;
    "isAuthority": boolean;
    isPersistentSerialized(str: string): boolean;
    "name": string;
    notSupportLazyInitInBuild(): boolean;
    onDestroyed(): void;
    onEditorActiveUpdate(dt: number): void;
    onEditorSelectedUpdate(dt: number): void;
    onSyncPresetAfterDeserialize(): void;
    "ownership": ComponentOwnership;
    preSyncPreset(): void;
    "stateFlag": number;
    supportLazyInit(): boolean;
    "tickEnable": boolean;
    "useEditorSelectedUpdate": boolean;
    readonly "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, component: InternalComponent) => void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   * @category inventory
   * @category weapon
   */
  class InventoryItemConfig extends Asset {
    "AutoUse": boolean;
    "CanStack": boolean;
    "canTrade": boolean;
    "CharacterSlot": mw.HumanoidSlotType;
    clone(): InventoryItemConfig;
    "CurrencyName": string;
    "CurrencyType": CurrencyType;
    "Description": string;
    "Destoryable": boolean;
    "DropDestroyTime": number;
    "Droppable": boolean;
    "EquipmentSlot": EquipmentSlotType;
    "IconID": string;
    "ItemType": InventoryItemType;
    "MaxStack": number;
    "MeshID": string;
    "Name": string;
    "Offset": mw.Transform;
    "prefabAssetId": string;
    "prefabId": string;
    "Price": number;
    "sellable": boolean;
    "SellCurrencyName": string;
    "SellPrice": number;
    "StackCount": number;
    "uniqueTag": string;
    "Useable": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   * @category inventory
   * @category weapon
   */
  enum InventoryItemType {
    Consumable = 0,
    NonConsumable = 1,
    Equipment = 2,
    Currency = 3,
    MeleeWeapon = 4,
    HotWeapon = 5,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface IPlayable {
    "context": PlayableContext;
    pause(): void;
    play(startTime: number): void;
    preview(time: number): void;
    resume(): void;
    stop(): void;
    tick(dt: number): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface IPlayerController {
    "currentCamera"?: undefined | mw.Camera;
    "currentEntity": IEntity;
    emit(event: string, ...args: Array<any>): boolean;
    "gameState": GameState<BasicPlayerInfo>;
    hasEvent(event: string): boolean;
    off(event: string, callback: Function, thisArg?: unknown): IEventDispatcher;
    offAll(event: string): IEventDispatcher;
    offAll(thisArg?: unknown): IEventDispatcher;
    on(event: string, callback: Function, thisArg?: unknown, ...args: Array<any>): IEventDispatcher;
    once(event: string, callback: Function, thisArg?: unknown, ...args: Array<any>): IEventDispatcher;
    "onEntityProcessed"?: undefined | UDelegate<(old: IEntity, newEntity: IEntity) => void>;
    "player": mw.Player;
    "playerId": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category combat
   * @category effect
   * @category interaction
   * @category inventory
   * @category movement
   * @category ui
   */
  interface IPoolReusableComponent {
    onComponentPoolReset(context: IPoolReuseContext): void;
    onComponentPoolResume(context: IPoolReuseContext): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category combat
   * @category effect
   * @category interaction
   * @category inventory
   * @category movement
   * @category ui
   */
  interface IPoolReuseContext {
    "phase": EPoolReusePhase;
    "poolTypeKey": string;
    "restoreSucceeded": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface IScene {
    createEntity(): Promise<IEntity>;
    createEntity(go: mw.GameObject): Promise<IEntity>;
    createEntity(go: mw.GameObject, createInfo: ICreateEntityInfo): Promise<IEntity>;
    createEntity(gameObjectAssetId: string): Promise<IEntity>;
    createEntity(gameObjectAssetId: string, createInfo: ICreateEntityInfo): Promise<IEntity>;
    emit(event: string, ...args: Array<any>): boolean;
    "enable": boolean;
    findEntity(gameObjectId: string): undefined | IEntity;
    findEntityWithoutCreate(gameObjectId: string): undefined | IEntity;
    getAllEntities(): Array<IEntity>;
    hasEvent(event: string): boolean;
    "isAuthority": boolean;
    "isLocalScene": boolean;
    lockEntityNotAsyncFound(gameObjectId?: undefined | string): void;
    off(event: string, callback: Function, thisArg?: unknown): IEventDispatcher;
    offAll(event: string): IEventDispatcher;
    offAll(thisArg?: unknown): IEventDispatcher;
    on(event: string, callback: Function, thisArg?: unknown, ...args: Array<any>): IEventDispatcher;
    once(event: string, callback: Function, thisArg?: unknown, ...args: Array<any>): IEventDispatcher;
    "scheduler": IScheduler;
    unlockEntityNotAsyncFound(gameObjectId?: undefined | string): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface IScheduler {
    callLater(caller: any, method: Function, ...args: Array<any>): TimerHandler;
    readonly "delta": number;
    readonly "elapsed": number;
    readonly "frame": number;
    getRemindTime(handler: number): number;
    getRemindTime(caller: unknown, method: Function): number;
    hasTimer(caller: any, method?: undefined | Function): boolean;
    hasTimer(handler: TimerHandler): boolean;
    readonly "localTime": number;
    loop(delay: number, caller: any, method: Function, ...args: Array<any>): TimerHandler;
    once(delay: number, caller: any, method: Function, ...args: Array<any>): TimerHandler;
    pauseTarget(caller: any): any;
    remove(handler: TimerHandler): any;
    remove(caller: any, method: Function): any;
    removeAll(caller: any): void;
    resumeTarget(caller: any): any;
    run(caller: any, method: Function): any;
    run(handler: TimerHandler): any;
    run(caller: any): any;
    readonly "serverTime": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface ISubSystem {
    activate(): void;
    deactivate(): void;
    destroy(): void;
    initialize(): void;
    "scene": IScene;
    start(): void;
    tick(): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface ISystemAssembler {
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface ITaskOwner {
    getTaskOwner(): IEntity;
    getTaskQueue(): ITaskQueue;
    onTaskActivated(task: Task): void;
    onTaskDeactivated(task: Task): void;
    onTaskInitialized(task: Task): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface ITaskQueue {
    addTaskReadyForActivation(task: Task): void;
    getTaskOwner(): IEntity;
    getTaskQueue(): ITaskQueue;
    onTaskActivated(task: Task): void;
    onTaskDeactivated(task: Task): void;
    onTaskInitialized(task: Task): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category audio
   * @category environment
   */
  class MapData extends Asset {
    ___serializeTag_7285(output: SerializationOutput, context: SerializationContext): void;
    clone(): MapData;
    "createTime": number;
    "creatorId": string;
    "env": EnvironmentData;
    "localPathName": string;
    "name": string;
    onCreate(): void;
    postDeSerialize(): void;
    postLoaded(): void;
    preSerialize(): void;
    setData(data: EnvironmentData): void;
    "uuid": string;
    "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, obj: Asset) => Asset;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   * @category equipment
   */
  class MeleeStrike {
    "checkDuration": number;
    "startTime": number;
    "strikeInfo": StrikeInfo;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface MethodRes {
    "method": CallCompFuncInst;
    "params": Array<Property>;
    "type": EValueType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class ModifierEvaluateData {
    toString(): string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum ModifierOp {
    Additive = 0,
    Multiplicative = 1,
    Division = 2,
    Override = 3,
    Max = 4,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class ModifierSpec {
    clone(): ModifierSpec;
    copy(source: ModifierSpec): ModifierSpec;
    "evaluatedMagnitude": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnAbilityTargetConformed = UDelegate<(handle: number, tag: string, targetData: AbilityTargetData) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnAggregatorDirty = UDelegate<(aggregator: Aggregator) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnAttributeChangeEvent = UDelegate<(attribute: Attribute, oldValue: number, newValue: number, modData: EffectModCallbackData) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnEffectRemovedInfo = UDelegate<(removalInfo: EffectRemovalInfo) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnEffectStackChange = UDelegate<(handler: number, newStack: number, oldStack: number) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category equipment
   * @category weapon
   */
  type OnEquipmentDelegate = UDelegate<(entity: IEntity, equipment: EquipmentComponent) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnGameplayAbilityActivateFailed = UDelegate<(abilitySpecHandler: number, ability: GameplayAbilityInstance<GameplayAbility>, failureReason: TagContainer) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnGameplayAbilityCancelled = UDelegate<(ability: GameplayAbilityInstance<GameplayAbility>) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnGameplayAbilityEnd = UDelegate<(abilitySpecHandler: number, ability: GameplayAbilityInstance<GameplayAbility>, wasCanceled: boolean) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnGameplayAbilityEnded = UDelegate<(ability: GameplayAbilityInstance<GameplayAbility>, handle: number, replicated: boolean, wasCanceled: boolean) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnGameplayAbilityHandleEvent = UDelegate<(abilitySpecHandler: number, ability: GameplayAbilityInstance<GameplayAbility>) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnGameplayAbilitySpecEvent = UDelegate<(abilitySpecHandler: GameplayAbilitySpec, ability: GameplayAbilityInstance<GameplayAbility>) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnGameplayAbilityStateChanged = UDelegate<(ability: GameplayAbilityInstance<GameplayAbility>, name: string) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnGameplayEffectAppliedDelegate = UDelegate<(targetAsc: AbilitySystemComponent, effectSpec: GameplayEffectSpec, handler: number) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnInhibitionChanged = UDelegate<(handler: number, isInhibited: boolean) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnTagCountChanged = UDelegate<(tag: string, count: number) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type OnTimeChange = UDelegate<(handler: number, newStartTime: number, newDuration: number) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface OpenUIData {
    "customObject"?: any;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface OtherEvent {
    "event": string;
    "type": "entity_event" | "global_event";
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface Param {
    "index": number;
    "type": EValueType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface Params {
    "type": EValueType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum PeriodInhibitionPolicy {
    NeverReset = 0,
    ResetPeriod = 1,
    ExecuteAndReset = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class PlayableContext {
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type PredictionKey = number;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class PredictionSnapshot {
    "abilityHandle": AbilitySpecHandle;
    "confirmed": boolean;
    "consumed": boolean;
    "predictionKey": PredictionKey;
    "rejected": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   * @category equipment
   */
  enum ProjectileCollisionCheckMethod {
    LineTrace = 0,
    Projectile = 1,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  type Property = Value | AbiProperty | CompProperty | Param | Params | MethodRes;

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface PropertyBase {
    "categorys"?: undefined | Array<string>;
    "property": string;
    "type": EValueType;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  type ReadonlyBitMask = {
    readonly "contains": (id: number) => boolean;
    readonly "equals": (set: BitMask) => boolean;
    readonly "flag": number;
    readonly "getDifference": (set: BitMask, tempCacheClaimedResource: BitMask) => BitMask;
    readonly "getOverLap": (set: BitMask, tempCacheClaimedResource: BitMask) => BitMask;
    readonly "hasAllIds": (set: BitMask) => boolean;
    readonly "hasAnyId": (set: BitMask) => boolean;
    readonly "isEmpty": boolean;
  };

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  interface ReadonlyTagContainer {
    ___iterator_171(): Iterator<string, any, any>;
    clone(): TagContainer;
    debugPrintHierarchy(): string;
    diff(other: TagContainer): TagDiffResult;
    equal(other: TagContainer): boolean;
    getInvalidTags(): Array<string>;
    hasAll(tags: string | TagContainer): boolean;
    hasAllExact(tags: string | TagContainer): boolean;
    hasAny(tags: string | TagContainer): boolean;
    hasAnyExact(tags: string | TagContainer): boolean;
    hasTag(tag: string): boolean;
    hasTagExact(tag: string): boolean;
    isEmpty(): boolean;
    readonly "length": number;
    matchTag(source: string): string;
    readonly "tags": Array<string>;
    toString(): string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  class SceneSlot {
    attach(child: SceneSlot, tag: string, offset: mw.Transform, slotType?: undefined | number): boolean;
    "blockSlotType": TagContainer;
    checkMountCondition(tag: string): boolean;
    readonly "children": Set<SceneSlot>;
    destroy(): void;
    detach(child: SceneSlot): boolean;
    initialize(): void;
    "offset": mw.Transform;
    readonly "owner": IEntity;
    "parent": SceneSlot;
    "slotType": TagContainer;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category audio
   * @category environment
   */
  type SerializationContext = {
    "customArguments": Record<string | number | symbol, unknown>;
    "root": Record<string, unknown>;
  };

  /**
   * @aiExport
   * @since 1.0
   * @category audio
   * @category environment
   */
  interface SerializationOutput {
    writeProperty(name: string, value: unknown): void;
    writeSuper(): void;
    writeThis(): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface SetPropInst {
    "component": number;
    "property": string;
    "type": EInstructionType;
    "value": Property;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface SlotInterface {
    attach(child: SceneSlot, tag: string, offset: mw.Transform, slotType?: undefined | mw.HumanoidSlotType.Hair | mw.HumanoidSlotType.Head | mw.HumanoidSlotType.LeftHead | mw.HumanoidSlotType.RightHead | mw.HumanoidSlotType.Glasses | mw.HumanoidSlotType.Eyes | mw.HumanoidSlotType.FaceOrnamental | mw.HumanoidSlotType.Mouse | mw.HumanoidSlotType.LeftShoulder | mw.HumanoidSlotType.RightShoulder | mw.HumanoidSlotType.LeftGlove | mw.HumanoidSlotType.RightGlove | mw.HumanoidSlotType.BackOrnamental | mw.HumanoidSlotType.LeftBack | mw.HumanoidSlotType.RightBack | mw.HumanoidSlotType.LeftHand | mw.HumanoidSlotType.RightHand | mw.HumanoidSlotType.LeftFoot | mw.HumanoidSlotType.RightFoot | mw.HumanoidSlotType.Buttocks | mw.HumanoidSlotType.Rings | mw.HumanoidSlotType.Nameplate | mw.HumanoidSlotType.ChatFrame | mw.HumanoidSlotType.Root | mw.HumanoidSlotType.LeftLowerArm | mw.HumanoidSlotType.RightLowerArm | mw.HumanoidSlotType.LeftThigh | mw.HumanoidSlotType.RightThigh | mw.HumanoidSlotType.LeftCalf | mw.HumanoidSlotType.RightCalf | mw.HumanoidSlotType.FirstpersonCamera | mw.NonHumanoidSlotType.Root | mw.NonHumanoidSlotType.Chest | mw.NonHumanoidSlotType.UpperSpine | mw.NonHumanoidSlotType.LowerSpine | mw.NonHumanoidSlotType.Neck | mw.NonHumanoidSlotType.Head | mw.NonHumanoidSlotType.FrontalLeftFoot | mw.NonHumanoidSlotType.FrontalRightFoot | mw.NonHumanoidSlotType.RearLeftFoot | mw.NonHumanoidSlotType.RearRightFoot | mw.NonHumanoidSlotType.Tail | mw.NonHumanoidSlotType.RightHand | mw.NonHumanoidSlotType.LeftHand | mw.NonHumanoidSlotType.HumanoidHead | mw.NonHumanoidSlotType.HumanoidChest | mw.NonHumanoidSlotType.DorsalFin | mw.NonHumanoidSlotType.LeftFin | mw.NonHumanoidSlotType.RightFin | mw.NonHumanoidSlotType.RightWing | mw.NonHumanoidSlotType.LeftWing | mw.NonHumanoidSlotType.ExtraRightFoot1 | mw.NonHumanoidSlotType.ExtraRightFoot2 | mw.NonHumanoidSlotType.ExtraRightFoot3 | mw.NonHumanoidSlotType.ExtraRightFoot4 | mw.NonHumanoidSlotType.ExtraLeftFoot1 | mw.NonHumanoidSlotType.ExtraLeftFoot2 | mw.NonHumanoidSlotType.ExtraLeftFoot3 | mw.NonHumanoidSlotType.ExtraLeftFoot4 | mw.NonHumanoidSlotType.Mouth | mw.NonHumanoidSlotType.RightEye | mw.NonHumanoidSlotType.LeftEye | mw.NonHumanoidSlotType.Crest | mw.NonHumanoidSlotType.ExtraRightTail1 | mw.NonHumanoidSlotType.ExtraRightTail2 | mw.NonHumanoidSlotType.ExtraLeftTail1 | mw.NonHumanoidSlotType.ExtraLeftTail2 | mw.NonHumanoidSlotType.RearRightWing | mw.NonHumanoidSlotType.RearLeftWing | mw.NonHumanoidSlotType.HumanoidLeftEye | mw.NonHumanoidSlotType.HumanoidRightEye | mw.NonHumanoidSlotType.HumanoidMouth | mw.NonHumanoidSlotType.HumanoidPelvis | mw.NonHumanoidSlotType.HumanoidSpine | mw.NonHumanoidSlotType.HumanoidNeck | mw.NonHumanoidSlotType.FrontTentacle | mw.NonHumanoidSlotType.RearTentacle | mw.NonHumanoidSlotType.LeftTentacle1 | mw.NonHumanoidSlotType.LeftTentacle2 | mw.NonHumanoidSlotType.LeftTentacle3 | mw.NonHumanoidSlotType.RightTentacle1 | mw.NonHumanoidSlotType.RightTentacle2 | mw.NonHumanoidSlotType.RightTentacle3): boolean;
    detach(child: SceneSlot): boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum StackExpirationPolicy {
    ClearEntireStack = 0,
    RemoveSingleStackAndRefreshDuration = 1,
    RefreshDuration = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum StackingType {
    None = 0,
    AggregatorSource = 1,
    AggregatorTarget = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum StackRefreshPolicy {
    RefreshOnApply = 0,
    NeverRefresh = 1,
    Max = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   * @category equipment
   */
  class StrikeInfo {
    "length": number;
    "size": mw.Vector;
    "start": mw.Vector;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  class TagContainer {
    ___iterator_171(): Iterator<string, any, any>;
    add(tag: string): boolean;
    appendTags(other: TagContainer): TagContainer;
    clear(): TagContainer;
    clone(): TagContainer;
    copy(from: TagContainer): TagContainer;
    debugPrintHierarchy(): string;
    diff(other: TagContainer): TagDiffResult;
    equal(other: TagContainer): boolean;
    fillParentTags(): void;
    from(tags: string | Array<string>): TagContainer;
    fromString(str: string): void;
    getInvalidTags(): Array<string>;
    hasAll(tags: string | TagContainer): boolean;
    hasAllExact(tags: string | TagContainer): boolean;
    hasAny(tags: string | TagContainer): boolean;
    hasAnyExact(tags: string | TagContainer): boolean;
    hasTag(tag: string): boolean;
    hasTagExact(tag: string): boolean;
    isEmpty(): boolean;
    readonly "length": number;
    matchTag(source: string): string;
    postUnSerialize(): void;
    preSerialize(): void;
    remove(tag: string, deferParentTags?: boolean): boolean;
    removeFromParent(tag: string): boolean;
    removeTags(other: TagContainer): void;
    readonly "tags": Array<string>;
    toString(): string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class TagContainerAggregator {
    readonly "actorTag": TagContainer;
    readonly "aggregatorTags": TagContainer;
    "cacheIsValid": boolean;
    clear(): void;
    from(captureSourceTag: TagContainerAggregator): TagContainerAggregator;
    readonly "specTag": TagContainer;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class TagCountOwnerComponent extends UTaskComponent {
    addLooseGameplayTag(tag: string): any;
    addLooseGameplayTag(tag: TagContainer): any;
    readonly "genericGameplayEvent": OnTagCountChanged;
    getOwnerAllTags(ret: TagContainer): boolean;
    getTagCount(tag: string): number;
    getTagGameplayTagEvent(tag: string): OnTagCountChanged;
    hasAllMatchingGameplayTags(tag: TagContainer): boolean;
    hasAnyMatchingGameplayTags(tag: TagContainer): boolean;
    hasMatchingGameplayTag(tag: string): boolean;
    removeLooseGameplayTag(tag: string): any;
    removeLooseGameplayTag(tag: TagContainer): any;
    setLooseGameplayTag(tag: string, count?: number): void;
    setTagMapCount(tag: string, count: number): void;
    updateTagMap(tag: string, count: number): any;
    updateTagMap(tag: TagContainer, count: number): any;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category collision
   * @category combat
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category movement
   * @category scene
   * @category shop
   * @category test
   * @category weapon
   */
  interface TagDiffResult {
    "added": Array<string>;
    "removed": Array<string>;
    "unchanged": Array<string>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class TagRequirements {
    clear(): void;
    clone(): TagRequirements;
    "ignoreTags": TagContainer;
    isEmpty(): boolean;
    require(container: TagContainer): boolean;
    "requireTags": TagContainer;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class Task {
    ___ActivateInTaskQueue_6013(): void;
    ___PauseInTaskQueue_6016(): void;
    activate(): void;
    addClaimedResource(resource: GameplayTaskResource): void;
    addClaimedResourceSet(set: BitMask): void;
    addRequiredResourceSet(set: BitMask): void;
    addRequireResource(resource: GameplayTaskResource): void;
    "careAboutPriority": boolean;
    readonly "claimedResource": ReadonlyBitMask;
    "claimRequiredResource": boolean;
    clone(): Task;
    copy(source: Task): Task;
    readonly "currentOwner": ITaskOwner;
    externalCancel(): void;
    externalConfirm(endTask: boolean): void;
    initialize(owner: ITaskOwner, priority?: undefined | number): void;
    readonly "isActive": boolean;
    readonly "isFinished": boolean;
    "isPauseable": boolean;
    readonly "isPaused": boolean;
    "isSimulated": boolean;
    "name": string;
    "ownerByTaskQueue": boolean;
    pause(): void;
    "priority": number;
    removeClaimedResource(resource: GameplayTaskResource): void;
    removeClaimedResourceSet(set: BitMask): void;
    removeRequiredResourceSet(set: BitMask): void;
    removeRequireResource(resource: GameplayTaskResource): void;
    readonly "requiredResource": ReadonlyBitMask;
    readonly "requiresPriorityOrResourceOverlap": boolean;
    "resourceOverlapPolicy": TaskResourceOverlapPolicy;
    resume(): void;
    "runAtSimulated": boolean;
    readonly "state": TaskState;
    taskOwnerEnd(): void;
    tick(delta: number): void;
    "tickable": boolean;
    "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, obj: Task) => Task;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum TaskResourceOverlapPolicy {
    StartOnTop = 0,
    StartAtEnd = 1,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  enum TaskState {
    Uninitialized = 0,
    AwaitingActivation = 1,
    Paused = 2,
    Active = 3,
    Finished = 4,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class THandler<T> {
    "args": null | Array<any>;
    "caller": unknown;
    clear(): THandler<T>;
    "method": T;
    "once": boolean;
    recover(): void;
    "ref": number;
    run(): any;
    runWith(...args: Array<unknown>): any;
    setTo(caller: any, method: T, args?: undefined | null | Array<unknown>, once?: boolean): THandler<T>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class TimelineClip {
    "asset": IClipAsset<any>;
    readonly "assetDuration": number;
    "blendInDuration": number;
    "blendMixInCurve": EasingMethod;
    "blendMixOutCurve": EasingMethod;
    "blendOutDuration": number;
    readonly "clipCaps": ClipCaps;
    "clipIn": number;
    clone(): TimelineClip;
    conformEaseValues(): void;
    copy(target: TimelineClip): TimelineClip;
    readonly "displayName": string;
    "duration": number;
    readonly "easeOutTime": number;
    editorCheckDurationEnable(): boolean;
    readonly "end": number;
    evaluateMixIn(time: number): number;
    evaluateMixOut(time: number): number;
    readonly "extrapolatedDuration": number;
    readonly "extrapolatedStart": number;
    fromLocalToGlobal(time: number): number;
    readonly "hasBlendIn": boolean;
    readonly "hasBlendOut": boolean;
    readonly "hasPostExtrapolation": boolean;
    readonly "hasPreExtrapolation": boolean;
    internalSetParentTrack(parent: TrackClip): void;
    isExtrapolatedTime(sequenceTime: number): boolean;
    isPostExtrapolatedTime(sequenceTime: number): boolean;
    isPreExtrapolatedTime(sequenceTime: number): boolean;
    readonly "mixInDuration": number;
    readonly "mixInPercentage": number;
    readonly "mixOutDuration": number;
    readonly "mixOutPercentage": number;
    readonly "mixOutTime": number;
    "name": string;
    readonly "onClipInfoChanged": UDelegate;
    onLoaded(): void;
    readonly "parentTrack": TrackClip;
    "postExtrapolationMode": ClipExtrapolation;
    "postExtrapolationTime": number;
    "preExtrapolationMode": ClipExtrapolation;
    "preExtrapolationTime": number;
    "start": number;
    supportsBlending(): boolean;
    supportsClipIn(): boolean;
    supportsDuration(): boolean;
    supportsExtrapolation(): boolean;
    supportsLooping(): boolean;
    supportsSpeedMultiplier(): boolean;
    toClipLocalTime(time: number): number;
    toLocalTime(time: number): number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category collision
   * @category combat
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category movement
   * @category scene
   * @category shop
   * @category test
   * @category weapon
   */
  type TimerHandler = number;

  /**
   * @aiExport
   * @since 1.0
   * @category interaction
   * @category inventory
   */
  enum TouchDetectShape {
    Cube = "Cube",
    Sphere = "Sphere",
    Capsule = "Capsule",
    Cone = "Cone",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class TrackClip {
    addChildrenTrack(track: TrackClip): void;
    addClip(clip: TimelineClip): void;
    readonly "childrenTracks": Array<TrackClip>;
    readonly "childrenTracksCount": number;
    clear(): void;
    readonly "clips": Array<TimelineClip>;
    clone(): TrackClip;
    copy(target: TrackClip): TrackClip;
    createPlayable(context: PlayableContext): IPlayable;
    readonly "duration": number;
    readonly "end": number;
    isClipValid(clip: TimelineClip): boolean;
    isFullOverAnyClip(clip: Inline_efaee7d9d5, except?: undefined | TimelineClip): null | TimelineClip;
    isOverlapsAnyClip(clip: Inline_1db48e7d4e, except?: undefined | TimelineClip): null | TimelineClip;
    "name": string;
    readonly "onChildrenTracksAdded": UDelegate<(track: TrackClip) => void>;
    readonly "onChildrenTracksRemoved": UDelegate<(track: TrackClip, index: number) => void>;
    readonly "onClipAdded": UDelegate<(clip: TimelineClip, index: number) => void>;
    onClipMove(): void;
    readonly "onClipRefreshed": UDelegate<() => void>;
    readonly "onClipRemoved": UDelegate<(clip: TimelineClip) => void>;
    readonly "onParentTrackChanged": UDelegate<() => void>;
    readonly "onRecordStateChanged": UDelegate<(...arg: Array<any>) => any>;
    readonly "onTrackInfoChanged": UDelegate<() => void>;
    readonly "parentTrack": TrackClip;
    postDeSerialize(): void;
    removeChildrenTrack(track: TrackClip, ignoreEvent?: boolean): void;
    removeClip(clip: TimelineClip): void;
    sortClips(): void;
    readonly "start": number;
    updateDuration(): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   * @category interaction
   * @category inventory
   */
  enum TriggerShape {
    Box = 1,
    Sphere = 1,
    Capsule = 2,
    Cylinder = 3,
    Custom = 4,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category combat
   * @category interaction
   * @category inventory
   */
  class TriggerShapeData {
    "bHorizontal": boolean;
    "bUseCustomShape": boolean;
    "bVisible": boolean;
    "customShapeGuid": string;
    "Offset": mw.Vector;
    "rotation": mw.Rotation;
    "Scale": mw.Vector;
    "shape": TriggerShape;
    "Size": mw.Vector;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category animation
   * @category audio
   * @category collision
   * @category combat
   * @category common
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category movement
   * @category scene
   * @category shop
   * @category test
   * @category weapon
   */
  class UDelegate<T extends (...args: any[]) => any = (...args: any[]) => any> {
    add(thisArg: unknown, callBack: (...args: [...Parameters<T>, ...any[]]) => ReturnType<T>, ...args: unknown[]): void;
    broadCast(...args: Parameters<T>): void;
    broadCastAndClear(...args: Parameters<T>): void;
    clear(): void;
    once(thisArg: unknown, callBack: (...args: [...Parameters<T>, ...any[]]) => ReturnType<T>, ...args: unknown[]): void;
    remove(thisArg: unknown, call: (...args: [...Parameters<T>, ...any[]]) => ReturnType<T>): void;
    removeByTarget(thisArg: unknown): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category scene
   * @category shop
   * @category spawning
   * @category test
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  class UgcDate {
    ___toPrimitive_1381(hint: "default"): string;
    ___toPrimitive_1381(hint: "string"): string;
    ___toPrimitive_1381(hint: "number"): number;
    ___toPrimitive_1381(hint: string): string | number;
    add(hours: number, minutes: number, seconds: number, years?: number, months?: number, days?: number): UgcDate;
    clone(): UgcDate;
    compare(ugcDate: UgcDate): boolean;
    "day": number;
    "dayOfWeek": number;
    fromNumber(seconds: number): UgcDate;
    getDate(): number;
    getDay(): number;
    getFullYear(): number;
    getHours(): number;
    getMilliseconds(): number;
    getMinutes(): number;
    getMonth(): number;
    getSeconds(): number;
    getTime(): number;
    getTimezoneOffset(): number;
    getUTCDate(): number;
    getUTCDay(): number;
    getUTCFullYear(): number;
    getUTCHours(): number;
    getUTCMilliseconds(): number;
    getUTCMinutes(): number;
    getUTCMonth(): number;
    getUTCSeconds(): number;
    "hour": number;
    initialize(hours: number, minutes: number, seconds: number, years?: number, months?: number, days?: number): UgcDate;
    "minutes": number;
    "month": number;
    postDeSerialize(): void;
    "seconds": number;
    setDate(date: number): number;
    setFullYear(year: number, month?: undefined | number, date?: undefined | number): number;
    setHours(hours: number, min?: undefined | number, sec?: undefined | number, ms?: undefined | number): number;
    setMilliseconds(ms: number): number;
    setMinutes(min: number, sec?: undefined | number, ms?: undefined | number): number;
    setMonth(month: number, date?: undefined | number): number;
    setSeconds(sec: number, ms?: undefined | number): number;
    setTime(time: number): number;
    setUTCDate(date: number): number;
    setUTCFullYear(year: number, month?: undefined | number, date?: undefined | number): number;
    setUTCHours(hours: number, min?: undefined | number, sec?: undefined | number, ms?: undefined | number): number;
    setUTCMilliseconds(ms: number): number;
    setUTCMinutes(min: number, sec?: undefined | number, ms?: undefined | number): number;
    setUTCMonth(month: number, date?: undefined | number): number;
    setUTCSeconds(sec: number, ms?: undefined | number): number;
    sub(hours: number, minutes: number, seconds: number, years?: number, months?: number, days?: number): UgcDate;
    toDateString(): string;
    toISOString(): string;
    toJSON(key?: any): string;
    toLocaleDateString(): string;
    toLocaleDateString(locales?: undefined | string | Array<string>, options?: undefined | Intl.DateTimeFormatOptions): string;
    toLocaleDateString(locales?: undefined | string | Intl.Locale | Array<string | Intl.Locale>, options?: undefined | Intl.DateTimeFormatOptions): string;
    toLocaleString(): string;
    toLocaleString(locales?: undefined | string | Array<string>, options?: undefined | Intl.DateTimeFormatOptions): string;
    toLocaleString(locales?: undefined | string | Intl.Locale | Array<string | Intl.Locale>, options?: undefined | Intl.DateTimeFormatOptions): string;
    toLocaleTimeString(): string;
    toLocaleTimeString(locales?: undefined | string | Array<string>, options?: undefined | Intl.DateTimeFormatOptions): string;
    toLocaleTimeString(locales?: undefined | string | Intl.Locale | Array<string | Intl.Locale>, options?: undefined | Intl.DateTimeFormatOptions): string;
    toNumber(): number;
    toString(): string;
    toTimeString(): string;
    toUTCString(): string;
    "value": number;
    valueOf(): number;
    "year": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category decorate
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  enum UIComponentType {
    AssetIconShow = "AssetIconShow",
    AssetIconEdit = "AssetIconEdit",
    AssetPresetEdit = "AssetPresetEdit",
    AssetSelectPanel = "AssetSelectPanel",
    SingleLineText = "SingleLineText",
    MultiLineText = "MultiLineText",
    SingleButton = "SingleButton",
    NumberInput = "NumberInput",
    VisibleButton = "VisibleButton",
    ToggleButton = "ToggleButton",
    Color = "Color",
    ColorPicker = "ColorPicker",
    Dropdown = "Dropdown",
    DropItem = "DropItem",
    ComboCheckBox = "ComboCheckBox",
    Vector3D = "Vector3D",
    Position = "Position",
    Scale = "Scale",
    Rotation = "Rotation",
    TransformEdit = "TransformEdit",
    ComponentHead = "ComponentHead",
    GroupHead = "GroupHead",
    EditButton = "EditButton",
    InstructionListShow = "InstructionList",
    InstructionItem = "InstructionItem",
    ArrayButton = "ArrayButton",
    ArrayItem = "ArrayItem",
    GainFuncButton = "GainFuncButton",
    SwitchButton = "SwitchButton",
    IntroDrop = "IntroDrop",
    IntroButton = "IntroButton",
    NumberSlider = "NumberSlider",
    DialogSetting = "DialogSetting",
    OptionGroup = "OptionGroup",
    ButtonGroup = "ButtonGroup",
    EmptyCustom = "EmptyCustom",
    PhysicalLockTogBtn = "PhysicalLockTogBtn",
    HorizontalGroup = "HorizontalGroup",
    BigNumberInput = "BigNumberInput",
    Invalid = "Invalid",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category combat
   */
  class UTaskComponent extends InternalLifeComponent {
    "_referenceCount": number;
    addTaskReadyForActivation(task: Task): void;
    readonly "binder": mw.GameObject;
    readonly "canEverTick": boolean;
    readonly "canPersistentSerializedIgnore": boolean;
    getIsAuthority(): boolean;
    getOccupy(context?: any): any;
    getTaskOwner(): IEntity;
    getTaskQueue(): ITaskQueue;
    "id": string;
    readonly "internalBeselect": () => void;
    readonly "internalCloseDetailPanel": () => void;
    readonly "internalComponentAwake": () => void;
    readonly "internalComponentLateUpdate": (dt: number) => void;
    readonly "internalComponentStart": () => void;
    readonly "internalComponentUpdate": (dt: number) => void;
    readonly "internalDeselect": () => void;
    readonly "internalLiveBeselect": () => void;
    readonly "internalLiveDeselect": () => void;
    readonly "internalOnActivate": () => void;
    readonly "internalOnDeactivate": () => void;
    readonly "internalOnDestroy": () => void;
    readonly "internalOnGameModeChanged": (from: string, to: string) => void;
    readonly "internalOpenDetailPanel": () => void;
    "isAuthority": boolean;
    isPersistentSerialized(str: string): boolean;
    "name": string;
    notSupportLazyInitInBuild(): boolean;
    readonly "onClaimResourceChanged": UDelegate<(claimedResource: BitMask, releasedResource: BitMask) => void>;
    onDestroyed(): void;
    onEditorActiveUpdate(dt: number): void;
    onEditorSelectedUpdate(dt: number): void;
    onSyncPresetAfterDeserialize(): void;
    onTaskActivated(task: Task): void;
    onTaskDeactivated(task: Task): void;
    onTaskInitialized(task: Task): void;
    "ownership": ComponentOwnership;
    preSyncPreset(): void;
    "stateFlag": number;
    supportLazyInit(): boolean;
    "tickEnable": boolean;
    "useEditorSelectedUpdate": boolean;
    readonly "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, component: InternalComponent) => void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  interface Value {
    "type": ValueType;
    "value": unknown;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  type ValueType = "string" | "boolean" | "int" | "float" | "vector" | "quaternion" | "unknown";

  /**
   * 提供已标注的运行态能力
   * @category ability
   * @category combat
   */
  class AbilitySystemComponent extends TagCountOwnerComponent {
    /**
     * 是否阻止所有技能的释放
     *
     * 基类固定返回 `false`；技能激活检查会读取该值。
     */
    readonly abilityActivationInhibited: boolean;
    /**
     * 将本地输入按下事件转交能力系统。
     */
    abilityLocalInputPressed(inputId: number): void;
    /**
     * 将本地输入释放事件转交能力系统。
     */
    abilityLocalInputReleased(inputId: number): void;
    /**
     * 为指定预测键添加确认或拒绝结果监听。
     */
    addPredictionCatchUpOrRejectEvent(predictionKey: PredictionKey, func: (snapShot: PredictionSnapshot, confirmed: boolean) => void, thisArgs?: any, ...args: Array<any>): boolean;
    /**
     * 分配一个新的技能预测键。
     */
    allocatePredictionKey(): PredictionKey;
    /**
     * 根据技能标签更新阻断状态，并按配置取消匹配的活动技能。
     */
    applyAbilityBlockAndCancelTags(tag: TagContainer, requestAbility: GameplayAbilityInstance<GameplayAbility>, enableBlock: boolean, blockAbilityTag: TagContainer, executeCancel: boolean, cancelAbilityTag: TagContainer): void;
    /**
     * 应用已确认或已取消的目标数据与通用事件。
     */
    applyConfirmedOrCanceledTargetDataAndEvents(handler: AbilitySpecHandle, predictionKey?: PredictionKey): void;
    /**
     * 将 GameplayEffect 施加到自身并返回活动效果句柄。
     */
    applyGameplayEffect(effect: GameplayEffect, level?: number, instigator?: IEntity | AbilitySystemComponent): number;
    /**
     * 应用已构造的 GameplayEffectSpec 并返回活动效果句柄。
     * @pitfall 非权威端仅能在有效预测会话中施加，否则返回无效句柄。
     */
    applyGameplayEffectSpec(effectSpec: GameplayEffectSpec, predictionKey?: PredictionKey): number;
    /**
     * 将 GameplayEffect 施加到目标能力系统。
     */
    applyGameplayEffectToTarget(target: AbilitySystemComponent, effect: GameplayEffect, level?: number): number;
    /**
     * 绕过 GameplayEffect 条件检查直接修改属性聚合值。
     */
    applyModToAttribute(attribute: Attribute, modifierOp: ModifierOp, modifierMagnitude: number, modData?: EffectModCallbackData): void;
    /**
     * 查询当前Asc是否阻碍了指定tag的技能
     */
    areAbilityTagsBlocked(tag: TagContainer): boolean;
    /**
     * 检查指定技能当前是否满足激活条件。
     */
    canActiveAbility(abilityToActivate: number | GameplayAbility, optionRelevantTag?: undefined | TagContainer, sourceTag?: undefined | TagContainer, targetTag?: undefined | TagContainer): boolean;
    /**
     * 检查当前属性是否足以承担 GameplayEffect 的加法消耗。
     */
    canApplyAttributeModifiers(effect: GameplayEffect, level: number, context: ActiveEffectContext): boolean;
    /**
     * 取消所有指定的技能
     */
    cancelAbilities(withTag?: undefined | TagContainer, withOutTag?: undefined | TagContainer, ignore?: undefined | GameplayAbilityInstance<GameplayAbility>): void;
    /**
     * 取消指定的技能
     */
    cancelAbility(ability: GameplayAbility): void;
    /**
     * 通过技能句柄取消技能
     */
    cancelAbilityByHandle(abilityHandler: AbilitySpecHandle): void;
    /**
     * 取消技能目标
     */
    cancelAbilityTargetData(handle: AbilitySpecHandle, predictionKey?: PredictionKey): void;
    /**
     * 清除指定技能与预测键对应的已复制数据缓存。
     */
    clearAbilityReplicatedDataCache(abilityHandle: AbilitySpecHandle, predictionKey?: PredictionKey): void;
    /**
     * 清除指定预测键对应的预测会话。
     */
    clearPredicateSession(predictionKey: PredictionKey): void;
    /**
     * 确认技能目标数据
     */
    confirmAbilityTargetData(handle: AbilitySpecHandle, targetData: AbilityTargetData, applicationTag?: string, predictionKey?: PredictionKey): void;
    /**
     * 消费指定技能与预测键对应的全部已复制数据。
     */
    consumeAllReplicatedData(abilityHandle: AbilitySpecHandle, predictionKey?: PredictionKey): void;
    /**
     * 消费指定技能与预测键对应的已复制通用事件。
     */
    consumeGenericReplicatedEvent(handle: AbilitySpecHandle, event: string, predictionKey?: PredictionKey): void;
    /**
     * 消费指定技能与预测键对应的已复制目标数据。
     */
    consumeReplicatedTargetData(handle: AbilitySpecHandle, predictionKey?: PredictionKey): void;
    /**
     * 当前正在处理的属性修改上下文；无处理中的修改时为空。
     */
    readonly currentModData: EffectModCallbackData;
    /**
     * 应用一个周期性buff的效果
     */
    executePeriodicGameplayEffect(handler: ActiveEffectHandler): void;
    /**
     * 按谓词查询技能规格，并可收集全部命中项。
     */
    findAbilityHandlerWithQuery(query: AbilitySpecQuery, ret?: undefined | Array<GameplayAbilitySpec>): GameplayAbilitySpec;
    /**
     * 通过技能句柄查找技能
     */
    findAbilitySpec(abilitySpecHandler: number | GameplayAbility): GameplayAbilitySpec;
    /**
     * 查询拥有全部指定资产标签的技能规格。
     */
    findAbilityWithAllAssetTag(tagContainer: string | TagContainer, ret?: Array<GameplayAbilitySpec>): Array<GameplayAbilitySpec>;
    /**
     */
    findAbilityWithAnyAssetTag(tagContainer: string | TagContainer, ret?: Array<GameplayAbilitySpec>): Array<GameplayAbilitySpec>;
    /**
     * 按句柄查询活动 GameplayEffect。
     */
    findActiveGameplayEffect(handler: ActiveEffectHandler): ActiveGameplayEffect;
    /**
     * 按配置名称查询活动 GameplayEffect。
     */
    findActiveGameplayEffectWithName(name: string): ActiveGameplayEffect;
    /**
     * 按谓词查询活动 GameplayEffect，并可收集全部命中项。
     */
    findActiveGameplayEffectWithQuery(query: ActivateEffectQuery, ret?: undefined | Array<ActiveGameplayEffect>): ActiveGameplayEffect;
    /**
     * 获取属性变化事件；可选择在不存在时创建。
     */
    findAttributeChangeEvents(attribute: Attribute, createdWhenNotFound?: boolean): OnAttributeChangeEvent;
    /**
     * 通用取消输入 ID；`abilityLocalInputPressed` 会用它识别取消输入。
     */
    genericCancelInputID: number;
    /**
     * 通用确认输入 ID；`abilityLocalInputPressed` 会用它识别确认输入。
     */
    genericConfirmInputID: number;
    /**
     * 通用取消输入触发时广播的事件。
     */
    readonly genericLocalCancelCallbacks: UDelegate<(...args: Array<any>) => void>;
    /**
     * 通用确认输入触发时广播的事件。
     */
    readonly genericLocalConfirmCallbacks: UDelegate<(...args: Array<any>) => void>;
    /**
     * 获取指定技能通用事件的委托。
     */
    getAbilityGenericDelegate(handle: AbilitySpecHandle, event: string, predictionKey?: PredictionKey): UDelegate<any>;
    /**
     * 获取指定技能通用事件缓存的数据。
     */
    getAbilityGenericEventData(handle: AbilitySpecHandle, event: string, predictionKey?: PredictionKey): null | AbilityTargetGenericEvent<any>;
    /**
     * 获取指定技能的剩余冷却时间
     */
    getAbilityRemainCoolDown(handler: AbilitySpecHandle): number;
    /**
     * 获取指定技能目标取消事件的委托。
     */
    getAbilityTargetCancelDelegate(handle: AbilitySpecHandle, predictionKey?: PredictionKey): UDelegate<(...arg: Array<any>) => any>;
    /**
     * 获取指定技能目标确认事件的委托。
     */
    getAbilityTargetConfirmDelegate(handle: AbilitySpecHandle, predictionKey?: PredictionKey): OnAbilityTargetConformed;
    /**
     * 获取指定技能与预测键缓存的目标数据。
     */
    getAbilityTargetData(handle: AbilitySpecHandle, predictionKey?: PredictionKey): null | AbilityTargetData;
    /**
     * 获取指定激活效果的最小剩余时间。
     */
    getActivateEffectRemainingTime(handler: ActiveEffectHandler): number;
    /**
     * 查询全部匹配活动效果的起止时间与剩余秒数。
     * @pitfall 返回缓冲区仅在当前同步调用栈内有效，不可跨帧持有。
     */
    getActivateEffectRemainingTimeWithQuery(query: ActivateEffectQuery): Array<ActivateEffectRemainingResult>;
    /**
     * 获取属性当前值。
     */
    getAttributeValue(attribute: Attribute): number;
    /**
     * 获取某个buff在激活时捕获的施加者的tag
     */
    getEffectSourceTagsFromHandler(handle: ActiveEffectHandler): null | TagContainer;
    /**
     * 获取某个buff在激活时捕获的目标的tag
     */
    getEffectTargetTagsFromHandler(handle: ActiveEffectHandler): null | TagContainer;
    /**
     * 给与一个已经创建好的技能
     * @pitfall 应在权威端授予技能；无效配置返回无效句柄。
     */
    giveAbility(ability: GameplayAbilitySpec): AbilitySpecHandle;
    giveAbility(ability: GameplayAbility, level: number): AbilitySpecHandle;
    giveAbility(ability: GameplayAbilityName, level: number): AbilitySpecHandle;
    /**
     * 给与一个技能并立即激活
     * @pitfall 仅适用于可实例化且能在服务端执行的技能。
     */
    giveAbilityAndActivateOnce(ability: GameplayAbilitySpec): number;
    /**
     * 2026-03-30 16:30:00 增加 LocalPredicted 分支：本地玩家或权威端均可激活。
     * 原因：docs/plan/ability-prediction-plan.md — LocalPredicted 允许本地玩家预测激活。
     */
    hasAuthorityToActivateAbility(abilitySpec: GameplayAbilitySpec): boolean;
    /**
     * 触发指定技能的已复制通用事件并保存事件数据。
     */
    invokeReplicatedEvent(handle: AbilitySpecHandle, event: string, eventData: any, predictionKey?: PredictionKey): void;
    /**
     * 判断输入 ID 是否命中当前的通用取消输入绑定。
     */
    isGenericCancelInputBound(inputId: number): boolean;
    /**
     * 判断输入 ID 是否命中当前的通用确认输入绑定。
     */
    isGenericConfirmInputBound(inputId: number): boolean;
    /**
     * 广播并清空当前通用取消输入的回调。
     */
    localInputCancel(): void;
    /**
     * 广播并清空当前通用确认输入的回调。
     */
    localInputConfirmed(): void;
    /**
     * 为效果施加构造来源与目标上下文。
     */
    makeEffectContext(instigator: IEntity | AbilitySystemComponent, target?: IEntity | AbilitySystemComponent): ActiveEffectContext;
    /**
     * 构造可供施加的 GameplayEffectSpec。
     */
    makeOutgoingGameplayEffectSpec(gameplayEffect: GameplayEffect, level: number, context: ActiveEffectContext): GameplayEffectSpec;
    /**
     * 当一个持续时间类型buff被添加时触发
     */
    readonly onActiveGameplayEffectAddedDelegateToSelf: UDelegate<(targetAsc: AbilitySystemComponent, effectSpec: GameplayEffectSpec, handler: number) => void>;
    /**
     * 当任意一个buff被移除时触发
     */
    readonly onAnyEffectRemovedDelegate: UDelegate<(ge: ActiveGameplayEffect, removalInfo: EffectRemovalInfo) => void>;
    /**
     * 当buff持续时间变更时触发
     *
     * 回调提供持续时间发生变更的活动效果。
     */
    readonly onEffectDurationChangedDelegate: UDelegate<(ge: ActiveGameplayEffect) => void>;
    /**
     * 当技能激活成功后触发。
     */
    readonly onGameplayAbilityActivated: UDelegate<(abilitySpecHandler: number, ability: GameplayAbilityInstance<GameplayAbility>) => void>;
    /**
     * 当技能激活失败时触发，并提供失败原因标签。
     */
    readonly onGameplayAbilityActivateFailed: UDelegate<(abilitySpecHandler: number, ability: GameplayAbilityInstance<GameplayAbility>, failureReason: TagContainer) => void>;
    /**
     * 当技能提交消耗与冷却后触发。
     */
    readonly onGameplayAbilityCommitted: UDelegate<(abilitySpecHandler: number, ability: GameplayAbilityInstance<GameplayAbility>) => void>;
    /**
     * 当技能结束时触发。
     */
    readonly onGameplayAbilityEnded: UDelegate<(abilitySpecHandler: number, ability: GameplayAbilityInstance<GameplayAbility>, wasCanceled: boolean) => void>;
    /**
     * 当技能规格被授予时触发。
     */
    readonly onGameplayAbilityGranted: UDelegate<(abilitySpecHandler: number, ability: GameplayAbilityInstance<GameplayAbility>) => void>;
    /**
     * 当技能规格被移除时触发。
     */
    readonly onGameplayAbilityRemoved: UDelegate<(abilitySpecHandler: GameplayAbilitySpec, ability: GameplayAbilityInstance<GameplayAbility>) => void>;
    /**
     * 当buff被添加到自身时
     */
    readonly onGameplayEffectAppliedDelegateToSelf: UDelegate<(targetAsc: AbilitySystemComponent, effectSpec: GameplayEffectSpec, handler: number) => void>;
    /**
     * 当buff被添加到目标时触发
     */
    readonly onGameplayEffectAppliedDelegateToTarget: UDelegate<(targetAsc: AbilitySystemComponent, effectSpec: GameplayEffectSpec, handler: number) => void>;
    /**
     * 当一个buff添加被免疫时触发
     */
    readonly onImmunityBlockGameplayEffectDelegate: UDelegate<(blockedGE: GameplayEffectSpec, immunityGameplayEffect: ActiveGameplayEffect) => void>;
    /**
     * 当一个周期性buff执行tick时
     */
    readonly onPeriodicGameplayEffectExecuteDelegateOnSelf: UDelegate<(targetAsc: AbilitySystemComponent, effectSpec: GameplayEffectSpec, handler: number) => void>;
    /**
     * 当一个周期性buff执行tick时
     */
    readonly onPeriodicGameplayEffectExecuteDelegateOnTarget: UDelegate<(targetAsc: AbilitySystemComponent, effectSpec: GameplayEffectSpec, handler: number) => void>;
    /**
     * 移除一个技能
     */
    removeAbility(abilitySpecHandler: number | GameplayAbility): void;
    /**
     * 移除某个buff
     */
    removeActiveGameplayEffect(effectHandle: ActiveEffectHandler): boolean;
    /**
     * 移除指定预测键的确认或拒绝结果监听。
     */
    removePredictionCatchUpOrRejectEvent(predictionKey: PredictionKey, func: (snapShot: PredictionSnapshot, confirmed: boolean) => void, thisArgs?: any, ...args: Array<any>): boolean;
    /**
     * 设置技能的通用事件数据，并在需要时同步到服务端。
     */
    setAbilityGenericEventData(handle: AbilitySpecHandle, event: string, eventData: unknown, predictionKey?: PredictionKey): void;
    /**
     * 在权威端设置属性基础值。
     * @pitfall 非权威端调用不会修改属性。
     */
    setAttributeBaseValue(attribute: Attribute, newVal: number): void;
    /**
     * 将技能设置为结束后移除。
     */
    setRemoveAbilityOnEnd(abilitySpecHandler: AbilitySpecHandle): void;
    /**
     * 使用预测键和技能句柄开始一次预测会话。
     */
    startPredicateSession(predictionKey: PredictionKey, abilityHandler: AbilitySpecHandle): void;
    /**
     * 在权威端触发 GameplayEvent，供匹配事件的技能响应。
     * @pitfall 非权威端调用不会触发事件。
     */
    triggerGameplayEvent(event: GameplayEventData): void;
    /**
     * 2026-03-30 16:30:00 增加 LocalPredicted 客户端预测分支。
     * 原因：docs/plan/ability-prediction-plan.md — 本地玩家立即预测激活，同时向服务端发送验证 RPC。
     * @pitfall 远程分支返回 true 只表示激活请求已发出，最终结果通过激活或失败事件通知。
     */
    tryActivateAbility(abilityToActivate: number | GameplayAbility, allowRemoteActivation?: boolean): boolean;
    /**
     * 显示更改某个buff的持续时间
     */
    updateActiveEffectDuration(handler: ActiveEffectHandler, desireDuration: number): void;
  }

  /**
   * 提供已标注的运行态能力
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  class BasicInfoComponent extends InternalLifeComponent {
    /**
     * 以当前实体为事件源发送工程中已定义的自定义事件。
     * 2026-04-01 12:00:00 BasicInfo 能力不再挂载 CustomEventComponent，由本组件提供该入口。
     * @pitfall event 必须来自工程自定义事件表，args 的顺序和类型必须与事件定义一致。
     */
    broadcastCustomEvent(event: string, ...args: Array<any>): void;
    /**
     * 读取当前 UGC 时间；写入不会改变返回值。
     * @pitfall setter 当前为空实现，请只把该属性当作只读时间快照使用。
     */
    date: UgcDate;
    /**
     * 实体的描述文本。写入仅更新组件保存的文本。
     */
    description: string;
    /**
     * 销毁当前实体，并解除与 owner 的销毁监听。
     * @pitfall 构建编辑环境会直接返回；运行态调用会永久销毁实体，请先解除业务侧引用和事件监听。
     */
    destroyEntity(): void;
    /**
     * 非玩家实体的启用状态。
     * 写入会同步到实体启用状态；玩家实体忽略该同步。
     */
    entityEnable: boolean;
    /**
     * 实体名称。未设置自定义名称时读取宿主 GameObject 名称。
     * 空字符串写入会被忽略；有效写入会更新实体名称并触发名称事件。
     */
    entityName: string;
    /**
     * 实体持有的玩法标签容器。
     * @pitfall 返回的是组件内部容器引用；修改前需遵循 TagContainer 的增删接口和同步约束。
     */
    readonly gameplayTags: TagContainer;
    /**
     * 实体图标资源 ID。未设置覆盖值时返回宿主 GameObject 的资源 ID。
     */
    icon: string;
    /**
     * 实体名称更新时广播更新后的名称。
     */
    readonly onNameChange: UDelegate<(name: string) => void>;
    /**
     * 组件应用新的实体显隐状态时广播目标状态。
     * Instruction 强制隐藏分支不会触发此事件。
     */
    readonly onVisibleChange: UDelegate<(status: mw.PropertyStatus) => void>;
    /**
     * 实体的归属者；归属者销毁时该实体会跟随销毁，不能把实体自身设为归属者。
     * @pitfall 设为实体自身会被忽略；更换归属者时调用方仍应明确管理旧归属关系的业务语义。
     */
    owner: Entity;
    /**
     * 角色挂件跟随主体显示或保持显示的模式。
     * 写入后重新应用实体整体显隐状态。
     */
    pendantVisible: mw.PropertyStatus;
    /**
     * 将实体复位到 Transform 组件记录的默认位置和旋转。
     * 玩家处于载具上时不执行；载具实体会先重置载具状态，物理模型会短暂关闭物理后恢复。
     */
    restEntityPos(): void;
    /**
     * 生成该实体所使用的来源资源 ID。
     */
    source: string;
    /**
     * 宿主 GameObject 的当前标签。
     */
    readonly tag: string;
    /**
     * 实体的目标显隐状态。
     * 运行态写入后应用到宿主及相关子对象；构建态只刷新预览监听。
     */
    visible: mw.PropertyStatus;
  }

  /**
   * 配置场景物品并由实体执行物品使用流程
   * @category equipment
   * @category inventory
   * @category weapon
   */
  class ItemTemplateComponent extends InternalLifeComponent {
    /**
     * 拾取后是否自动使用而不进入背包。
     */
    autoUse: boolean;
    /**
     * 物品是否允许通过摆摊交易。
     */
    canTrade: boolean;
    /**
     * 物品是否允许被销毁。
     */
    destoryable: boolean;
    /**
     * 丢弃物无人拾取时的自动销毁时间，单位秒；写入会按允许范围规范化。
     */
    dropDestroyTime: number;
    /**
     * 物品是否允许丢弃到场景。
     */
    droppable: boolean;
    /**
     * 供物品业务保存的额外字符串数据。
     */
    extraData: string;
    /**
     * 对应背包物品实例的唯一标识。
     */
    inventoryGuid: string;
    /**
     * 获取物品的完整运行时配置对象。
     */
    readonly InventoryItemConfig: InventoryItemConfig;
    /**
     * 出售该物品时使用的货币类型和数量。
     */
    saleCurrency: CurrencyInfo;
    /**
     * 物品是否允许出售。
     */
    sellable: boolean;
    /**
     * 由指定实体使用物品，并执行已配置的物品使用指令。
     * @pitfall 当物品配置为不可使用时，该方法会销毁物品实体并返回 false。
     */
    use(executor: IEntity): Promise<boolean>;
    /**
     * 物品是否允许使用。
     */
    useable: boolean;
  }

  /**
   * 管理地图环境与全局音频
   * @category audio
   * @category environment
   */
  class MapComponent extends InternalLifeComponent {
    /**
     * 新增或更新一个环境资产并返回 UUID。
     */
    addAsset(data: EnvironmentData, uuid?: undefined | string): string;
    /**
     * 当前背景音乐资源 ID。
     */
    bgmGuid: string;
    /**
     * 背景音乐音量缩放百分比；写入同步到 SoundService。
     */
    BGMVolumeScale: number;
    /**
     * 将滤镜变更加入当前组件的应用队列。
     */
    changeFilter(effectId: number): void;
    /**
     * 配置并立即应用 CloudDensity 环境属性。
     */
    CloudDensity: number;
    /**
     * 配置并立即应用 CloudOpacity 环境属性。
     */
    CloudOpacity: number;
    /**
     * 配置并立即应用 CloudSpeed 环境属性。
     */
    CloudSpeed: number;
    /**
     * 配置并立即应用 CloudTexture 环境属性。
     */
    CloudTexture: string;
    /**
     * 配置并立即应用 CloudTint 环境属性。
     */
    CloudTint: string;
    /**
     * 配置并立即应用 ColorBiasValue 环境属性。
     */
    ColorBiasValue: string;
    /**
     * 配置并立即应用 ColorTem 环境属性。
     */
    ColorTem: number;
    /**
     * 配置并立即应用 DisturbanceDensity 环境属性。
     */
    DisturbanceDensity: number;
    /**
     * 配置并立即应用 DisturbanceIntensity 环境属性。
     */
    DisturbanceIntensity: number;
    /**
     * 配置并立即应用 ExposureCompensation 环境属性。
     */
    ExposureCompensation: number;
    /**
     * 当前客户端使用的后处理滤镜预设 ID。
     */
    FilterId: number;
    /**
     * 配置并立即应用 FogAttenuationHeight 环境属性。
     */
    FogAttenuationHeight: number;
    /**
     * 配置并立即应用 FogDensity 环境属性。
     */
    FogDensity: number;
    /**
     * 配置并立即应用 FogHeight 环境属性。
     */
    FogHeight: number;
    /**
     * 配置并立即应用 FogInitDistance 环境属性。
     */
    FogInitDistance: number;
    /**
     * 配置并立即应用 FogMaxOpacity 环境属性。
     */
    FogMaxOpacity: number;
    /**
     * 配置并立即应用 FogScatteringColor 环境属性。
     */
    FogScatteringColor: string;
    /**
     * 查询全部环境资产。
     */
    getAllAsset(): Array<MapData>;
    /**
     * 按 UUID 查询环境资产数据。
     */
    getAsset(uuid: string): EnvironmentData;
    /**
     * 配置并立即应用 HorizontalFadeValue 环境属性。
     */
    HorizontalFadeValue: number;
    /**
     * 配置并立即应用 IsDisturbance 环境属性。
     */
    IsDisturbance: boolean;
    /**
     * 配置并立即应用 IsEnableCloud 环境属性。
     */
    IsEnableCloud: boolean;
    /**
     * 配置并立即应用 IsEnableColorTem 环境属性。
     */
    IsEnableColorTem: boolean;
    /**
     * 配置并立即应用 IsEnabledCastShadows 环境属性。
     */
    IsEnabledCastShadows: boolean;
    /**
     * 配置并立即应用 IsEnableFog 环境属性。
     */
    IsEnableFog: boolean;
    /**
     * 配置并立即应用 IsEnableMoon 环境属性。
     */
    IsEnableMoon: boolean;
    /**
     * 配置并立即应用 IsEnableShade 环境属性。
     */
    IsEnableShade: boolean;
    /**
     * 配置并立即应用 IsEnableStar 环境属性。
     */
    IsEnableStar: boolean;
    /**
     * 配置并立即应用 IsEnableSun 环境属性。
     */
    IsEnableSun: boolean;
    /**
     * 配置并立即应用 MoonIntensity 环境属性。
     */
    MoonIntensity: number;
    /**
     * 配置并立即应用 MoonSize 环境属性。
     */
    MoonSize: number;
    /**
     * 配置并立即应用 MoonTexture 环境属性。
     */
    MoonTexture: string;
    /**
     * 配置并立即应用 MoonTint 环境属性。
     */
    MoonTint: string;
    /**
     * 配置并立即应用 ParallelLightColor 环境属性。
     */
    ParallelLightColor: string;
    /**
     * 配置并立即应用 ParallelLightIntensity 环境属性。
     */
    ParallelLightIntensity: number;
    /**
     * 配置并立即应用 PitchAngle 环境属性。
     */
    PitchAngle: number;
    /**
     * 在目标实体对应的客户端播放背景音乐，并记录本组件当前的资源 ID 与音量。
     */
    PlayBGM(player: IEntity, assetId: string, volume?: number): void;
    /**
     * 按 UUID 删除环境资产。
     */
    removeAsset(uuid: string): void;
    /**
     * 为指定玩家应用完整环境数据。
     */
    seEnvByPlayer(player: mw.Player, data: any): void;
    /**
     * 按环境资产 UUID 为所有玩家应用环境。
     */
    setAllEnv(uuid: string): void;
    /**
     * 设置目标客户端的背景音乐音量百分比。
     */
    setCurrentBGMVolumeScale(player: IEntity, bgmVolumeScale?: number): void;
    /**
     * 设置目标客户端的全局音效音量百分比。
     */
    setCurrentVolumeScale(player: IEntity, volumeScale?: number): void;
    /**
     * 为所有玩家设置滤镜。
     */
    setFilterByAllPlayer(value: number): void;
    /**
     * 为指定玩家设置滤镜。
     */
    setFilterByPlayer(player: mw.Player, value: number): void;
    /**
     * 应用一组完整的环境数据。
     */
    setWeatherData(data: any): void;
    /**
     * 配置并立即应用 ShadowDistance 环境属性。
     */
    ShadowDistance: number;
    /**
     * 配置并立即应用 SkyBoxBottomTint 环境属性。
     */
    SkyBoxBottomTint: string;
    /**
     * 配置并立即应用 SkyBoxBrightness 环境属性。
     */
    SkyBoxBrightness: number;
    /**
     * 配置并立即应用 SkyBoxDomeTint 环境属性。
     */
    SkyBoxDomeTint: string;
    /**
     * 配置并立即应用 SkyBoxMidTint 环境属性。
     */
    SkyBoxMidTint: string;
    /**
     * 配置并立即应用 SkyBoxRotation 环境属性。
     */
    SkyBoxRotation: number;
    /**
     * 配置并立即应用 SkyBoxTexture 环境属性。
     */
    SkyBoxTexture: string;
    /**
     * 配置并立即应用 SkyBoxTopTint 环境属性。
     */
    SkyBoxTopTint: string;
    /**
     * 配置并立即应用 SkyLightColor 环境属性。
     */
    SkyLightColor: string;
    /**
     * 配置并立即应用 SkyLightIntensity 环境属性。
     */
    SkyLightIntensity: number;
    /**
     * 配置并立即应用 SkyLightTexture 环境属性。
     */
    SkyLightTexture: string;
    /**
     * 全局音效音量缩放百分比；写入同步音效与背景音乐服务。
     */
    SoundVolumeScale: number;
    /**
     * 配置并立即应用 StarBrightness 环境属性。
     */
    StarBrightness: number;
    /**
     * 配置并立即应用 StarDensity 环境属性。
     */
    StarDensity: number;
    /**
     * 配置并立即应用 StarTexture 环境属性。
     */
    StarTexture: string;
    /**
     * 停止目标实体对应客户端当前由 SoundService 播放的背景音乐。
     */
    StopBGM(player: IEntity): void;
    /**
     * 配置并立即应用 SunIntensity 环境属性。
     */
    SunIntensity: number;
    /**
     * 配置并立即应用 SunScatteringColor 环境属性。
     */
    SunScatteringColor: string;
    /**
     * 配置并立即应用 SunScatteringIndex 环境属性。
     */
    SunScatteringIndex: number;
    /**
     * 配置并立即应用 SunScatteringInitDis 环境属性。
     */
    SunScatteringInitDis: number;
    /**
     * 配置并立即应用 SunSize 环境属性。
     */
    SunSize: number;
    /**
     * 配置并立即应用 SunTexture 环境属性。
     */
    SunTexture: string;
    /**
     * 配置并立即应用 SunTint 环境属性。
     */
    SunTint: string;
    /**
     * 当前天气强度，面板值范围为 0 到 100。
     */
    WeatherIntensity: number;
    /**
     * 当前天气粒子尺寸，面板值范围为 0 到 100。
     */
    WeatherParticleSize: number;
    /**
     * 当前天气类型数值；写入会清理或初始化对应天气特效。
     */
    WeatherType: number;
    /**
     * 配置并立即应用 YawAngle 环境属性。
     */
    YawAngle: number;
  }

  /**
   * 提供已标注的运行态能力
   * @category collision
   * @category physics
   */
  class PhysicComponent extends InternalLifeComponent {
    /**
     * 向物体添加角冲量。
     */
    addAngularImpulse(impulse: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 向物体添加线性力。
     */
    addForce(force: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 向物体添加线性冲量。
     */
    addImpulse(impulse: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 向物体添加扭矩。
     */
    addTorque(torque: mw.Vector, ignoreMass?: undefined | false | true): void;
    /**
     * 检查是否可以与指定通道碰撞（基于当前Profile）
     */
    canCollideWithChannel(targetChannel: CollisionChannel): boolean;
    /**
     * 检查是否可以与指定实体碰撞
     */
    canCollideWithEntity(targetEntity: IEntity): boolean;
    /**
     * 清除物体当前受到的全部力。
     */
    clearAllForces(): void;
    /**
     * 物体的碰撞启用状态。
     */
    collision: mw.CollisionStatus;
    /**
     * 获取物体当前使用的碰撞通道。
     */
    getCollisionChannel(): CollisionChannel;
    /**
     * 检查是否与指定通道阻塞（基于当前Profile）
     */
    isBlockingWithChannel(targetChannel: CollisionChannel): boolean;
    /**
     * 检查是否与指定实体阻挡
     */
    isBlockingWithEntity(targetEntity: IEntity): boolean;
    /**
     * 查询当前物理对象是否正在与目标实体重叠。
     */
    isOverlappingEntity(target: IEntity): boolean;
    /**
     * 检查是否与指定通道重叠（基于当前Profile）
     */
    isOverlappingWithChannel(targetChannel: CollisionChannel): boolean;
    /**
     * 检查是否与指定实体重叠
     */
    isOverlappingWithEntity(targetEntity: IEntity): boolean;
    /**
     * 物体的线性阻尼。
     */
    linerDamping: number;
    /**
     * 物理质量。
     */
    mass: number;
    /**
     * 是否使用组件配置的质量。
     */
    massEnable: boolean;
    /**
     * 是否启用物理模拟。
     */
    physicsEnabled: boolean;
    /**
     * 设置物体使用的碰撞通道。
     */
    setCollisionChannel(channel: CollisionChannel): void;
    /**
     * 是否启用触碰检测。
     */
    touchEnabled: boolean;
  }

  /**
   * 提供已标注的运行态能力
   * @category ability
   * @category ai
   * @category animation
   * @category appearance
   * @category archive
   * @category audio
   * @category camera
   * @category collision
   * @category combat
   * @category data
   * @category display
   * @category effect
   * @category entity
   * @category environment
   * @category equipment
   * @category gameplay
   * @category interaction
   * @category inventory
   * @category matchmaking
   * @category movement
   * @category physics
   * @category progression
   * @category rendering
   * @category shop
   * @category spawning
   * @category timer
   * @category transform
   * @category ui
   * @category weapon
   */
  class TransformComponent extends InternalLifeComponent implements SlotInterface {
    /**
     * 三个分量的底层绝对模式位数组。
     * @pitfall absolutePosition/Rotation/Scale 的“跟随父物体”语义与这些位相反。
     */
    absoluteMode: Array<boolean>;
    /**
     * 位置是否跟随父物体；getter/setter 对底层 absolute 位取反。
     */
    absolutePosition: boolean;
    /**
     * 旋转是否跟随父物体；getter/setter 对底层 absolute 位取反。
     */
    absoluteRotation: boolean;
    /**
     * 缩放是否跟随父物体；getter/setter 对底层 absolute 位取反。
     */
    absoluteScale: boolean;
    /**
     * 把子槽按名称、偏移和可选骨骼类型挂接到当前槽。
     */
    attach(child: SceneSlot, tag: string, offset: mw.Transform, slotType?: undefined | mw.HumanoidSlotType.Hair | mw.HumanoidSlotType.Head | mw.HumanoidSlotType.LeftHead | mw.HumanoidSlotType.RightHead | mw.HumanoidSlotType.Glasses | mw.HumanoidSlotType.Eyes | mw.HumanoidSlotType.FaceOrnamental | mw.HumanoidSlotType.Mouse | mw.HumanoidSlotType.LeftShoulder | mw.HumanoidSlotType.RightShoulder | mw.HumanoidSlotType.LeftGlove | mw.HumanoidSlotType.RightGlove | mw.HumanoidSlotType.BackOrnamental | mw.HumanoidSlotType.LeftBack | mw.HumanoidSlotType.RightBack | mw.HumanoidSlotType.LeftHand | mw.HumanoidSlotType.RightHand | mw.HumanoidSlotType.LeftFoot | mw.HumanoidSlotType.RightFoot | mw.HumanoidSlotType.Buttocks | mw.HumanoidSlotType.Rings | mw.HumanoidSlotType.Nameplate | mw.HumanoidSlotType.ChatFrame | mw.HumanoidSlotType.Root | mw.HumanoidSlotType.LeftLowerArm | mw.HumanoidSlotType.RightLowerArm | mw.HumanoidSlotType.LeftThigh | mw.HumanoidSlotType.RightThigh | mw.HumanoidSlotType.LeftCalf | mw.HumanoidSlotType.RightCalf | mw.HumanoidSlotType.FirstpersonCamera | mw.NonHumanoidSlotType.Root | mw.NonHumanoidSlotType.Chest | mw.NonHumanoidSlotType.UpperSpine | mw.NonHumanoidSlotType.LowerSpine | mw.NonHumanoidSlotType.Neck | mw.NonHumanoidSlotType.Head | mw.NonHumanoidSlotType.FrontalLeftFoot | mw.NonHumanoidSlotType.FrontalRightFoot | mw.NonHumanoidSlotType.RearLeftFoot | mw.NonHumanoidSlotType.RearRightFoot | mw.NonHumanoidSlotType.Tail | mw.NonHumanoidSlotType.RightHand | mw.NonHumanoidSlotType.LeftHand | mw.NonHumanoidSlotType.HumanoidHead | mw.NonHumanoidSlotType.HumanoidChest | mw.NonHumanoidSlotType.DorsalFin | mw.NonHumanoidSlotType.LeftFin | mw.NonHumanoidSlotType.RightFin | mw.NonHumanoidSlotType.RightWing | mw.NonHumanoidSlotType.LeftWing | mw.NonHumanoidSlotType.ExtraRightFoot1 | mw.NonHumanoidSlotType.ExtraRightFoot2 | mw.NonHumanoidSlotType.ExtraRightFoot3 | mw.NonHumanoidSlotType.ExtraRightFoot4 | mw.NonHumanoidSlotType.ExtraLeftFoot1 | mw.NonHumanoidSlotType.ExtraLeftFoot2 | mw.NonHumanoidSlotType.ExtraLeftFoot3 | mw.NonHumanoidSlotType.ExtraLeftFoot4 | mw.NonHumanoidSlotType.Mouth | mw.NonHumanoidSlotType.RightEye | mw.NonHumanoidSlotType.LeftEye | mw.NonHumanoidSlotType.Crest | mw.NonHumanoidSlotType.ExtraRightTail1 | mw.NonHumanoidSlotType.ExtraRightTail2 | mw.NonHumanoidSlotType.ExtraLeftTail1 | mw.NonHumanoidSlotType.ExtraLeftTail2 | mw.NonHumanoidSlotType.RearRightWing | mw.NonHumanoidSlotType.RearLeftWing | mw.NonHumanoidSlotType.HumanoidLeftEye | mw.NonHumanoidSlotType.HumanoidRightEye | mw.NonHumanoidSlotType.HumanoidMouth | mw.NonHumanoidSlotType.HumanoidPelvis | mw.NonHumanoidSlotType.HumanoidSpine | mw.NonHumanoidSlotType.HumanoidNeck | mw.NonHumanoidSlotType.FrontTentacle | mw.NonHumanoidSlotType.RearTentacle | mw.NonHumanoidSlotType.LeftTentacle1 | mw.NonHumanoidSlotType.LeftTentacle2 | mw.NonHumanoidSlotType.LeftTentacle3 | mw.NonHumanoidSlotType.RightTentacle1 | mw.NonHumanoidSlotType.RightTentacle2 | mw.NonHumanoidSlotType.RightTentacle3): boolean;
    /**
     * 当前归一化世界后方向。
     */
    readonly backward: mw.Vector;
    /**
     * 查询对象包围盒并可写入 origin/extend 输出向量。
     */
    calculateBoundingBox(onlyCollidingComponents: boolean, includeFromChild?: undefined | false | true, originOuter?: undefined | mw.Vector, extendOuter?: undefined | mw.Vector): void;
    /**
     * 从当前槽解除指定子槽。
     */
    detach(child: SceneSlot): boolean;
    /**
     * 当前归一化世界下方向。
     */
    readonly down: mw.Vector;
    /**
     * 当前归一化世界前方向。
     */
    readonly forward: mw.Vector;
    /**
     * 获取角色指定骨骼槽位的世界位置；非角色返回物体世界位置。
     */
    getBonesTransform(bone: mw.HumanoidSlotType): mw.Vector;
    /**
     * 查询对象包围尺寸，可把结果写入 outer。
     */
    getBoundSize(nonColliding?: undefined | false | true, includeFromChild?: undefined | false | true, outer?: undefined | mw.Vector): mw.Vector;
    /**
     * 获取默认世界变换的副本；尚未保存时从当前世界变换初始化。
     */
    getDefaultTransform(): mw.Transform;
    /**
     * 把当前前向方向写入 ret 并返回它。
     * @pitfall ret 会被原地修改。
     */
    getDirection(ret: mw.Vector): mw.Vector;
    /**
     * 获取当前本地位置。
     */
    getLocalPosition(): mw.Vector;
    /**
     * 获取当前本地旋转。
     */
    getLocalRotation(): mw.Rotation;
    /**
     * 获取当前本地缩放。
     */
    getLocalScale(): mw.Vector;
    /**
     * 获取当前本地变换。
     */
    getLocalTransform(): mw.Transform;
    /**
     * 获取当前世界位置。
     */
    getWorldPosition(): mw.Vector;
    /**
     * 获取当前世界旋转。
     */
    getWorldRotation(): mw.Rotation;
    /**
     * 获取当前世界缩放。
     */
    getWorldScale(): mw.Vector;
    /**
     * 获取当前世界变换。
     */
    getWorldTransform(): mw.Transform;
    /**
     * 当前归一化世界左方向。
     */
    readonly left: mw.Vector;
    /**
     * 相对父级的本地变换；写入时应用各轴锁定。
     */
    localTransform: mw.Transform;
    /**
     * 聚合读写三条移动轴锁。
     */
    lockMoveAxis: Inline_dfe7c608f0;
    /**
     * X 轴移动锁定状态。
     */
    lockMoveAxisX: boolean;
    /**
     * Y 轴移动锁定状态。
     */
    lockMoveAxisY: boolean;
    /**
     * Z 轴移动锁定状态。
     */
    lockMoveAxisZ: boolean;
    /**
     * 聚合读写三条旋转轴锁。
     */
    lockRotateAxis: Inline_7841299f8f;
    /**
     * X 轴旋转锁定状态。
     */
    lockRotateAxisX: boolean;
    /**
     * Y 轴旋转锁定状态。
     */
    lockRotateAxisY: boolean;
    /**
     * Z 轴旋转锁定状态。
     */
    lockRotateAxisZ: boolean;
    /**
     * 聚合读写三条缩放轴锁。
     */
    lockScaleAxis: Inline_c25bf6a3d1;
    /**
     * X 轴缩放锁定状态。
     */
    lockScaleAxisX: boolean;
    /**
     * Y 轴缩放锁定状态。
     */
    lockScaleAxisY: boolean;
    /**
     * Z 轴缩放锁定状态。
     */
    lockScaleAxisZ: boolean;
    /**
     * 使物体朝向目标位置并应用旋转轴锁定。
     * 移动旋转被 GameplayTag 禁用时返回 false；仅绕 Z 轴时会把传入位置的 Z 改为当前高度。
     */
    lookAt(position: mw.Vector, onlyZAxis?: undefined | false | true): boolean;
    /**
     * 按相对位移移动；锁定轴分量会被过滤，其余分量保持原位移长度。
     */
    moveBy(deltaPosition: mw.Vector, isLocal?: undefined | false | true, time?: number): void;
    /**
     * 使用运动器扩展参数执行相对移动并应用轴锁。
     * @pitfall speed 当前未参与实现，实际时长优先使用 duration。
     */
    moveByNew(Axis: mw.Vector, isLocal?: undefined | false | true, time?: number, speed?: number, duration?: number, smoothValue?: number, deltay?: number, curStopTime?: number, tarStopTime?: number, repeat?: boolean): void;
    /**
     * 插值移动到目标位置并应用移动轴锁。
     */
    moveTo(targetPosition: mw.Vector, time: number, isLocal?: undefined | false | true, onComplete?: undefined | UDelegate<(...arg: Array<any>) => any>): void;
    /**
     * 销毁并重建当前场景挂接槽。
     */
    rebuildSlot(): SceneSlot;
    /**
     * 当前归一化世界右方向。
     */
    readonly right: mw.Vector;
    /**
     * 按旋转增量旋转并应用旋转轴锁定；Vector 形式会被归一化为旋转轴。
     */
    rotateBy(deltaRotation: mw.Vector | mw.Rotation | mw.Quaternion, multiplier: number, isLocal?: undefined | false | true, time?: number): void;
    /**
     * 使用运动器扩展参数执行相对旋转并应用轴锁。
     * @pitfall speed 当前未参与实现，实际时长优先使用 duration。
     */
    rotateByNew(Axis: mw.Vector, multiplier: number, isLocal?: undefined | false | true, time?: number, speed?: number, duration?: number, smoothValue?: number, deltay?: number, curStopTime?: number, tarStopTime?: number, repeat?: boolean): void;
    /**
     * 插值旋转到目标朝向并应用旋转轴锁。
     */
    rotateTo(targetRotation: mw.Rotation | mw.Quaternion, time: number, isLocal?: undefined | false | true, onComplete?: undefined | UDelegate<(...arg: Array<any>) => any>): void;
    /**
     * 按缩放增量缩放并过滤锁定轴。
     */
    scaleBy(deltaScale: mw.Vector, isLocal?: undefined | false | true, time?: number): void;
    /**
     * 使用运动器扩展参数执行相对缩放并应用轴锁。
     * @pitfall speed 当前未参与实现，实际时长优先使用 duration。
     */
    scaleByNew(deltaScale: mw.Vector, isLocal?: undefined | false | true, time?: number, speed?: number, duration?: number, smoothValue?: number, deltay?: number, curStopTime?: number, tarStopTime?: number, repeat?: boolean): void;
    /**
     * 插值缩放到目标值并应用缩放轴锁。
     */
    scaleTo(targetScale: mw.Vector, time: number, isLocal?: undefined | false | true, onComplete?: undefined | UDelegate<(...arg: Array<any>) => any>): void;
    /**
     * 保存默认世界变换的副本。
     */
    setDefaultTransform(transform: mw.Transform): void;
    /**
     * 设置本地位置并应用移动轴锁定。
     */
    setLocalPosition(position: mw.Vector): void;
    /**
     * 设置本地旋转并应用旋转轴锁定。
     */
    setLocalRotation(rotation: mw.Rotation): void;
    /**
     * 设置本地缩放并应用缩放轴锁定。
     */
    setLocalScale(scale: mw.Vector): void;
    /**
     * 设置本地变换并应用轴锁定。
     */
    setLocalTransform(transform: mw.Transform): void;
    /**
     * 设置世界位置并应用移动轴锁定。
     */
    setWorldPosition(position: mw.Vector): void;
    /**
     * 设置世界旋转并应用旋转轴锁定。
     */
    setWorldRotation(rotation: mw.Rotation): void;
    /**
     * 设置世界缩放并应用缩放轴锁定。
     */
    setWorldScale(scale: mw.Vector): void;
    /**
     * 设置世界变换并应用轴锁定，同时刷新移动相关状态。
     */
    setWorldTransform(transform: mw.Transform): void;
    /**
     * 当前实体的场景挂接槽。
     */
    readonly slot: SceneSlot;
    /**
     * 停止当前移动插值；对象无效时忽略。
     */
    stopMove(): void;
    /**
     * 停止当前旋转插值；对象无效时忽略。
     */
    stopRotate(): void;
    /**
     * 停止当前缩放插值；对象无效时忽略。
     */
    stopScale(): void;
    /**
     * 当前归一化世界上方向。
     */
    readonly up: mw.Vector;
    /**
     * 世界坐标变换；写入时应用各轴锁定。
     */
    worldTransform: mw.Transform;
  }

  /**
   * @category ability
   * @category animation
   * @category audio
   * @category equipment
   * @category gameplay
   * @category inventory
   * @category scene
   * @category shop
   */
  class UComponent extends BaseComponent {
  }

  /**
   * 提供已标注的运行态能力
   * @category equipment
   * @category weapon
   */
  class WeaponComponent extends EquipmentComponent {
    /**
     * 武器命中目标时广播武器拥有者与目标实体。
     */
    readonly onAttack: UDelegate<(...args: Array<any>) => void>;
    /**
     * 将武器装备给指定实体并注册其 AbilitySystem 命中效果监听。
     * @pitfall 调用者应在不再使用武器时配对调用 onUnEquip，避免保留效果监听。
     */
    onEquip(entity: IEntity): Promise<void>;
    /**
     * 武器击杀目标时广播武器拥有者与目标实体。
     */
    readonly onKillOther: UDelegate<(...args: Array<any>) => void>;
    /**
     * 从指定实体卸下武器并移除其 AbilitySystem 命中效果监听。
     */
    onUnEquip(entity: IEntity): void;
    /**
     * 命中普通非 ASC 对象时是否执行武器的命中响应。
     */
    respondForNormalHit: boolean;
  }
}

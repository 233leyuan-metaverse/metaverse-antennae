// AI Export Declarations (ai) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category ai
   */
  interface Inline_5ac7d0fba0 {
    "key": string;
    "value": any;
  }

  /**
   * 提供已标注的运行态能力
   * @category ai
   */
  class AIComponent extends InternalLifeComponent {
    /**
     * 当前配置的行为树名称。
     * @pitfall 直接写入只更新配置与动态属性；运行态切换应调用 runtimeChangeBehavior。
     */
    aiName: string;
    /**
     * 当前 running===true 的行为树名称列表（委托 DynamicAIComponent，避免业务访问私有 _behaviors）。
     * 2026-06-28 14:00:00 原因：BUG-19 待机语音 gating 需识别巡逻等行为树 running 态。
     * 返回新数组；组件没有 DynamicAIComponent 时返回空数组。
     */
    getActiveRunningBehaviorNames(): Array<string>;
    /**
     * 按工程中已注册的行为树名称切换当前运行行为，并写入调用方提供的节点或黑板参数。
     * @pitfall 参数值类型为 any，调用方必须使用目标行为树真实声明的 key 和值类型。
     */
    runtimeChangeBehavior(name: string, params?: undefined | Array<Inline_5ac7d0fba0>): boolean;
    /**
     * 设置当前行为树的主动暂停请求。
     * 传入 `true` 会停止当前行为；传入 `false` 仅在 AOI 与强制暂停条件都已解除时恢复当前行为。
     * 当前行为尚未注册时调用不产生运行态效果。
     */
    setPauseOrResume(bPause: boolean): void;
    /**
     * running 行为树是否阻塞 NPC 待机随机语音（读 BT 数据 blocksIdleVoice，非硬编码 BT 名）。
     * 2026-06-28 16:00:00 原因：BUG-19 解耦——Sound 只依赖本 API，新 AI 在 BTData 声明即可。
     * 2026-06-28 20:00:00 原因：BUG-19 Phase 2——Client 读
     * @pitfall 客户端结果同时受复制聚合状态与本地行为状态影响，行为切换后可能存在复制时序差异。
     */
    shouldBlockIdleVoice(): boolean;
  }

  /**
   * 提供已标注的运行态能力
   * @category ai
   */
  class DynamicAIComponent extends InternalLifeComponent {
    /**
     * 2026-07-07 17:12:00 原因：池化/模式切换/销毁统一使用安全清理，避免只清 Map 后 running 计数、检测体和 bounds cache 残留。
     */
    clearRuntimeBehaviors(): void;
    /**
     * 返回当前 running===true 的行为树名称列表（供 Idle 语音等 gating 排障查询）。
     * 2026-06-28 14:00:00 原因：BUG-19 巡逻 Wait 段须识别行为树 running 态，不能只看 AIComponent.aiName。
     * 返回新数组，不暴露内部行为表。
     */
    getActiveRunningBehaviorNames(): Array<string>;
    /**
     * 读取服务端同步到客户端的待机语音阻塞聚合结果。
     */
    getReplicableBlocksIdleVoice(): boolean;
    /**
     * 是否存在 running 且 BT 数据声明 blocksIdleVoice 的行为树。
     * 2026-06-28 16:00:00 原因：BUG-19 解耦——Sound 只调 AI 层 API，不感知 BT 名集合。
     */
    shouldBlockIdleVoice(): boolean;
  }
}

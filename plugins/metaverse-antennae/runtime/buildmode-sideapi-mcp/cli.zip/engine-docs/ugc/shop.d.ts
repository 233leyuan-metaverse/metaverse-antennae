// AI Export Declarations (shop) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category shop
   */
  interface CurrencyBinding {
    "currencyType": CurrencyType;
    "customCurrencyKey"?: undefined | string;
    "displayName"?: undefined | string;
    "iconAssetId"?: undefined | string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category shop
   */
  class GameMode<GameStateType = GameState<BasicPlayerInfo>, PlayerControllerType = IPlayerController> {
    enterPreparePhase(): void;
    getPlayerController(playerId: string): undefined | IPlayerController;
    hasPlayer(playerId: string): boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category shop
   */
  class PriceInfo {
    "_buyingPrice": number;
    "_cellPrice": number;
    "_customCurrencyKey": string;
    "_editPropertyName": Array<string>;
    "_parentShopItemGuid": string;
    "_priceIcon": string;
    "_priceInfo": CurrencyType;
    "_priceName": string;
    clone(): PriceInfo;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category shop
   */
  class ShopData {
    "_editPropertyName": Array<string>;
    "_guid": string;
    "_shopName": string;
    "_shopTabDataArr": Array<ShopTabData>;
    "_useCoinTypes": Array<PriceInfo>;
    addPriceInfo(priceType: CurrencyType, icon: string, name: string, customCurrencyKey?: string): void;
    addTabData(): undefined | ShopTabData;
    clearCustomCurrencyType(): void;
    clone(): ShopData;
    deleShopTabData(shopTabDataIndex: number): void;
    delPriceInfo(priceType: CurrencyType): void;
    findShopTabDataByGuid(guid: string): undefined | ShopTabData;
    getAllPriceType(): Array<any>;
    getShopTabDataArr(): Array<ShopTabData>;
    has(priceType: CurrencyType, customCurrencyKey: string): boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category shop
   */
  class ShopItemData {
    "_buyingPrice": Array<PriceInfo>;
    "_guid": string;
    "_isInfinity": boolean;
    "_itemGuid": string;
    "_itemIcon": string;
    "_purchaseLimit": number;
    "_state": boolean;
    addPrice(priceType: CurrencyType, count: number, icon: string, name: string, customCurrencyKey?: string): void;
    changeCurrency(currencyType: number, customCurrencyKey: string, value: number): void;
    changePrice(priceType: CurrencyType, count: number, icon: string, name: string, customCurrencyKey?: string, targetPriceIndex?: number): void;
    clone(index: number): ShopItemData;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category shop
   */
  class ShopTabData {
    "_editPropertyName": Array<string>;
    "_guid": string;
    "_shopItemDataArr": Array<ShopItemData>;
    "_tabName": string;
    addShopItem(guid?: undefined | string): ShopItemData;
    clone(index: number): ShopTabData;
    deleShopItemData(shopItemDataIndex: number): void;
    deleShopItemDataByGuid(guid: string): number;
    deleShopItemDataByItemGuid(shopItemGuid: string): void;
    getShopItemDataArr(): Array<ShopItemData>;
    getShopItemDataByGuid(shopItemGuid: string): undefined | ShopItemData;
    getShopItemDataByIndex(index: number): ShopItemData;
    moveShopItemDataByGuid(moveGuid: string, targetGuid: string): boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category shop
   */
  type StallMode = "Public" | "Private";

  /**
   * @aiExport
   * @since 1.0
   * @category shop
   */
  type StallTradingConfig = {
    "acceptedCurrencies": Array<CurrencyBinding>;
    "enableTrade": boolean;
    "feeRate": number;
    "maxStallSlotCount": number;
    "priceMax"?: undefined | number;
    "priceMin"?: undefined | number;
    "stallMode": StallMode;
    "stallOwnerEntityId": string;
    "stallOwnerRuntimeOverrideEntityId"?: undefined | string;
    "stallOwnerRuntimeOverrideUserId"?: undefined | string;
    "tradePointEntityId": string;
  };

  /**
   * @aiExport
   * @since 1.0
   * @category shop
   */
  type StallTradingHost = {
    findPlayerEntityByUserId(userId: string): null | IEntity;
    getConfig(): StallTradingConfig;
    getSceneGameMode(): undefined | null | GameMode<GameState<BasicPlayerInfo>, IPlayerController>;
    isPrivateStallOpenForBuyers(): boolean;
    refreshStallInteractForOverlaps(): void;
    setPrivateStallOpenForBuyers(open: boolean): void;
    tryAutoBindDemoPrivateSeller(executor: IEntity): void;
  };

  /**
   * @aiExport
   * @since 1.0
   * @category shop
   */
  type TradeType = "Stall";

  /**
   * @aiExport
   * @since 1.0
   * @category shop
   */
  class TradingAcceptedCurrencyEntry {
    "customCurrencyKey": string;
  }

  /**
   * 商店
   * @category shop
   */
  class ShopComponent extends InternalLifeComponent {
    /**
     * 按商品 ID 发起购买。
     */
    operateBuyShopItem(player: IEntity, shopItemGuid: string, buyPrice: number, shopCount: number, currencyKey: string, instructionItemGuid?: string): Promise<void>;
    /**
     * 按商品 ID 发起出售。
     */
    operateSellShopItem(player: IEntity, shopItemGuid: string, sellPrice: number, shopCount: number, currencyKey: string, instructionItemGuid?: string): Promise<void>;
  }

  /**
   * 提供已标注的运行态能力
   * @category shop
   */
  class ShopPlayerComponent extends UComponent {
    /**
     * 获取商品下架状态
     */
    getShopItemState(shopItemGuid: string): undefined | number;
    /**
     * 把商品状态值写入持久化缓存；当前实现不校验状态是否属于 `0`、`1`、`2`。
     */
    setShopItemState(shopItemGuid: string, state: number): void;
  }

  /**
   * 配置并控制交易摊位
   * @category shop
   */
  class TradingComponent extends InternalLifeComponent {
    /**
     * 摊位接受的货币配置。
     */
    acceptedCurrencyEntries: Array<TradingAcceptedCurrencyEntry>;
    /**
     * 判断玩家是否可在当前摊位上架商品。
     */
    canPlayerListOnStall(playerEntity: IEntity): boolean;
    /**
     * 清除私人摊位的运行时所属玩家覆盖。
     */
    clearStallOwnerRuntimeOverride(): void;
    /**
     * 为指定玩家关闭交易面板。
     */
    closeTradingPanel(playerEntity: IEntity): void;
    /**
     * 是否启用交易。
     */
    enableTrade: boolean;
    /**
     * 交易手续费百分比。
     */
    feeRate: number;
    /**
     * 获取当前有效上架商品数量。
     */
    getActiveListingCount(): number;
    /**
     * 获取结算使用的当前交易配置快照。
     */
    getConfig(): StallTradingConfig;
    /**
     * 查询私人摊是否向买家开放。
     */
    isPrivateStallOpenForBuyers(): boolean;
    /**
     * 摊位最大上架槽位数量。
     */
    maxStallSlotCount: number;
    /**
     * 为指定玩家打开交易面板。
     */
    openTradingPanel(playerEntity: IEntity): void;
    /**
     * 允许的商品最高单价。
     */
    priceMax: number;
    /**
     * 允许的商品最低单价。
     */
    priceMin: number;
    /**
     * 从实体上的多个交易组件中解析当前有效实例。
     */
    static resolveOnEntity(entity: undefined | null | IEntity): null | TradingComponent;
    /**
     * 设置私人摊是否向买家开放。
     */
    setPrivateStallOpenForBuyers(open: boolean): void;
    /**
     * 设置私人摊位的运行时所属玩家。
     */
    setStallOwner(playerEntity: IEntity): void;
    /**
     * 摊位的公共或私人模式。
     */
    stallMode: StallMode;
    /**
     * 私人摊位当前绑定的所属实体。
     */
    stallOwnerEntity: Entity;
    /**
     * 交易点类型。
     */
    tradeType: TradeType;
    /**
     * 交易 UI 资源 ID。
     */
    tradeUIAssetId: string;
  }
}

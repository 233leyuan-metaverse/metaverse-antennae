// AI Export Declarations (display) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * 提供已标注的运行态能力
   * @category display
   */
  class StatueComponent extends InternalLifeComponent {
    /**
     * 清除雕像角色（或传入角色）的挂件，并在动态挂件变化时等待形象就绪。
     * @pitfall 角色不存在或已销毁时会记录日志并直接返回；部分旧版全身形象会在清除插槽后提前结束。
     */
    clearAllDecora(char?: mw.Character): Promise<void>;
    /**
     * 雕像循环播放的待机动画资源 ID；空字符串表示不播放待机动画。
     * 写入同值不产生效果；值变化后客户端停止旧动画并尝试加载新资源，资源无效时保持无待机动画。
     */
    idleAnimation: string;
    /**
     * 用于加载雕像外观的平台用户 ID；空字符串会恢复默认形象并清除挂件。
     * 写入同值不产生效果；客户端异步请求外观，空结果或失效宿主不会应用外观。
     */
    userId: string;
  }
}

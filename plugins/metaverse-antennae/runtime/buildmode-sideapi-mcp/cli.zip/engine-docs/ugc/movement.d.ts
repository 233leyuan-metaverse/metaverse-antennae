// AI Export Declarations (movement) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category movement
   */
  class CompletableSteeringBehavior<T = SteeringBehavior<any>> extends SteeringBehavior<T> {
    "active": boolean;
    calculate(movement: MovementComponent, force: mw.Vector, delta: number): any;
    initialize(...args: Array<any>): T;
    "onComplete": UDelegate<(entity: IEntity, behavior: T) => void>;
    "owner": IEntity;
    "weight": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category movement
   */
  interface IHomingMovementComponent {
    "homing": boolean;
    "homingTarget": IEntity;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category movement
   */
  class MoveByBehavior extends CompletableSteeringBehavior<MoveByBehavior> {
    "direction": mw.Vector;
    "duration": number;
    "onComplete": UDelegate<(entity: IEntity, behavior: MoveByBehavior) => void>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category movement
   */
  class MoveControlComp extends InternalLifeComponent {
    readonly "canEverTick": boolean;
    "onArrived": UDelegate<(entity: IEntity, ...args: Array<any>) => void>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category movement
   */
  class PhysicMovementConfig {
    "acceleration": number;
    "gravityScale"?: undefined | number;
    "homing": boolean;
    "initialSpeed"?: undefined | number;
    "isRotationFollowsVelocity": boolean;
    "maxSpeed": number;
    "speedRetention"?: undefined | number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category movement
   */
  class SteeringBehavior<T = SteeringBehavior<any>> {
    "active": boolean;
    calculate(movement: MovementComponent, force: mw.Vector, delta: number): any;
    initialize(...args: Array<any>): T;
    "owner": IEntity;
    "weight": number;
  }

  /**
   * 驱动实体基础变换运动
   * @category movement
   */
  class BaseMoveComponent extends InternalLifeComponent {
    /**
     */
    duration: number;
    /**
     */
    integratedMoverEnable: boolean;
    /**
     * 平移启动延迟。
     */
    linearDelayStartTime: number;
    /**
     * 是否启用平移返程。
     */
    linearRepeat: boolean;
    /**
     * 平移到达后的停顿时间。
     */
    linearRepeatDelay: number;
    /**
     * 平移单程时间。
     */
    linearRepeatTime: number;
    /**
     * 平移返程后的停顿时间。
     */
    linearReturnDelay: number;
    /**
     * 平移速度。
     */
    linearSpeed: mw.Vector;
    /**
     */
    motionCoordinate: mw.MotionAxis;
    /**
     */
    motionMode: mw.MotionMode;
    /**
     * 启动平移运动。
     */
    move(speed: mw.Vector, isLocal: boolean, deltay: number, repeat: boolean, sportTime: number, tarStopTime: number, curStopTime: any, smoothValue: number): void;
    /**
     * 启动旋转运动。
     */
    rotate(speed: mw.Vector, isLocal: boolean, deltay: number, repeat: boolean, sportTime: number, tarStopTime: number, curStopTime: any, smoothValue: number): void;
    /**
     * 旋转启动延迟。
     */
    rotationDelayStartTime: number;
    /**
     * 是否启用旋转返程。
     */
    rotationRepeat: boolean;
    /**
     * 旋转到达后的停顿时间。
     */
    rotationRepeatDelay: number;
    /**
     * 旋转单程时间。
     */
    rotationRepeatTime: number;
    /**
     * 旋转返程后的停顿时间。
     */
    rotationReturnDelay: number;
    /**
     * 旋转速度。
     */
    rotationSpeed: mw.Vector;
    /**
     * 启动缩放运动。
     */
    scale(scale: mw.Vector, isLocal: boolean, deltay: number, repeat: boolean, scaleTime: number, tarStopTime: number, curStopTime: number, smoothValue: number): void;
    /**
     * 缩放启动延迟。
     */
    scaleDelayStartTime: number;
    /**
     * 是否启用缩放返程。
     */
    scaleRepeat: boolean;
    /**
     * 缩放到达后的停顿时间。
     */
    scaleRepeatDelay: number;
    /**
     * 缩放单程时间。
     */
    scaleRepeatTime: number;
    /**
     * 缩放返程后的停顿时间。
     */
    scaleReturnDelay: number;
    /**
     * 缩放速度。
     */
    scaleSpeed: mw.Vector;
    /**
     */
    smooth: boolean;
    /**
     * 平滑运动参数值。
     */
    readonly smoothValue: number;
    /**
     * 启动摆动运动。
     */
    swing(swingSpeed: mw.Vector, angle: number, isLocal: boolean, deltay: number, stopTime: number): void;
    /**
     * 摆动最大角度。
     */
    swingAngle: number;
    /**
     * 摆动启动延迟。
     */
    swingDelayStartTime: number;
    /**
     * 摆动速度。
     */
    swingSpeed: mw.Vector;
  }

  /**
   * 提供已标注的运行态能力
   * @category movement
   */
  class CharacterMoveToComponent extends MoveControlComp {
    /**
     * MoveTo 被取消时的事件接口。
     * @pitfall 当前实现没有找到该事件的广播点；订阅后可能不会收到回调。
     */
    readonly canceledDelegate: UDelegate<(entity: IEntity) => void>;
    /**
     * MoveTo 成功完成时在服务端触发。
     */
    readonly completedDelegate: UDelegate<(entity: IEntity) => void>;
    /**
     * MoveTo 因目标失效或低位移检测超时时在服务端触发。
     */
    readonly failedDelegate: UDelegate<(entity: IEntity) => void>;
    /**
     * 把世界位置或目标实体解析到输出向量。
     * @pitfall 目标实体或 transform 无效时实现会返回 undefined，但当前签名仍声明为 Vector。
     */
    static getTargetPosition(target: mw.Vector | IEntity, outer?: undefined | mw.Vector): mw.Vector;
    /**
     * 2026-06-23 12:00:00 原因：BUG-17 待机语音需识别寻路/行为移动 active，供 CharacterSoundComponent 查询。
     */
    isMoveToBehaviorActive(): boolean;
    /**
     * 启动朝目标位置或目标实体移动的行为，并替换当前移动目标。
     * 字符串按当前场景实体 ID 解析；玩家角色会把实际移动转发到主控客户端。
     * `checkTimeout` 大于零时，组件会累计低于预期位移的检测时间并在超时后结束为失败。
     */
    moveTo(target: string | mw.Vector, tolerance?: number, checkTimeout?: number): void;
    /**
     * 停止当前移动行为、清除跟随目标与检测计数，并恢复此前保存的角色移动朝向模式。
     * 玩家角色会把停止动作转发到主控客户端；当前实现不会广播 `canceledDelegate`。
     */
    stop(): void;
  }

  /**
   * 提供已标注的运行态能力
   * @category movement
   */
  class CharMovementComponent extends MovementComponent {
    /**
     * 添加一帧移动输入；移动禁用标签或交互退出规则可能忽略本次输入。
     */
    addMovement(direction: mw.Vector): void;
    /**
     * 空中控制提升乘数。
     */
    airControlBoostMultiplier: number;
    /**
     * 空中控制提升速度阈值。
     */
    airControlBoostVelocityThreshold: number;
    /**
     * 组件从交互状态退出时触发；无回调参数，同一生命周期内可重复触发。
     * 该事件没有单独的失败或取消状态。监听方必须在自身生命周期结束时取消订阅。
     */
    readonly breakInteractionState: UDelegate<() => void>;
    /**
     * 请求切换角色移动状态；加锁时只缓存最后一次请求。
     */
    changeState(v: mw.CharacterStateType): void;
    /**
     * 是否启用角色复杂移动。
     */
    complexMovementEnabled: boolean;
    /**
     * 将角色切换为下蹲状态；已经处于下蹲时不重复切换。
     */
    crouch(): void;
    /**
     * 角色当前移动状态。
     */
    readonly currentState: mw.CharacterStateType;
    /**
     * 下落控制系数。
     */
    driftControl: number;
    /**
     * 跳跃下降重力倍率。
     */
    fallGravity: number;
    /**
     * 将角色切换为飞行状态；已经处于飞行时不重复切换。
     */
    fly(): void;
    /**
     * 飞行制动减速度。
     */
    flyBrakeSpeed: number;
    /**
     * 飞行最大速度。
     */
    flySpeed: number;
    /**
     * 将角色切换为自由落体状态；已经处于自由落体时不重复切换。
     */
    freeFall(): void;
    /**
     * 角色基础重力倍率。
     */
    gravityScale: number;
    /**
     * 是否有尚未应用的缓存状态。
     */
    hasAnyCachedStateNotApplied(): boolean;
    /**
     * 下落水平制动速率。
     */
    horizontalBrakingDecelerationFalling: number;
    /**
     * 请求角色跳跃。
     * 玩家角色由服务端转发到主控客户端；跳跃未启用、交互状态不允许退出或仍处于动画冷却时不改变状态。
     */
    jump(): void;
    /**
     * 是否允许角色发起跳跃。
     */
    jumpEnable: boolean;
    /**
     * 单次跳跃高度。
     */
    jumpHeight: number;
    /**
     * 使用给定速度调用角色底层发射入口。
     * `ignoreXy` 与 `ignoreZ` 会原样传给底层 `LaunchCharacter`，默认都为 `true`。
     */
    launch(velocity: mw.Vector, ignoreXy?: boolean, ignoreZ?: boolean): void;
    /**
     * 暂存后续角色状态写入，直至对应 unlock。
     */
    lockCharacterStateSet(): void;
    /**
     * 最大下落速度的底层角色值。
     */
    maxFallingSpeed: number;
    /**
     * 最大下落速度。
     */
    maxFallSpeed: number;
    /**
     * 连续跳跃最大次数。
     */
    maxJumpCount: number;
    /**
     * 当前移动状态对应的最大速度。
     */
    maxSpeed: number;
    /**
     * 角色移动时的朝向模式。
     */
    moveFacingDirection: mw.MoveFacingDirection;
    /**
     * 移动输入方向的解释方式。
     */
    movementDirection: mw.MovementDirection;
    /**
     * 是否允许角色移动。
     */
    movementEnable: boolean;
    /**
     * 角色状态发生变化时触发，回调依次提供变化前状态与变化后状态。
     * 同一组件生命周期内可重复触发；该事件没有单独的失败或取消状态，池化重置会清空监听。
     * 监听方必须在自身生命周期结束时使用同一监听引用取消订阅。
     */
    readonly onCharacterStateChanged: UDelegate<(prevState: mw.CharacterStateType, newState: mw.CharacterStateType) => void>;
    /**
     * 跳跃开关变化时广播新值。
     */
    readonly onJumpEnableChanged: UDelegate<(enabled: boolean) => void>;
    /**
     * 将角色切换为布娃娃状态；已经处于布娃娃状态时不重复切换。
     */
    ragdoll(): void;
    /**
     * 是否启用角色布娃娃。
     */
    ragDollEnable: boolean;
    /**
     * 跳跃上升重力倍率。
     */
    riseGravity: number;
    /**
     * 角色转向速率。
     */
    rotateRate: number;
    /**
     * 将角色切换为运行状态；已经处于运行状态时不重复切换。
     */
    run(): void;
    /**
     * 返回角色当前速度向量。
     */
    speed(): mw.Vector;
    /**
     * 组件进入交互状态时触发；无回调参数，同一生命周期内可重复触发。
     * 该事件没有单独的失败或取消状态。监听方必须在自身生命周期结束时取消订阅。
     */
    readonly startInteractionState: UDelegate<() => void>;
    /**
     * 立即清零组件速度，并调用角色底层移动组件的立即停止入口。
     */
    stopMovementImmediately(): void;
    /**
     * 游泳制动减速度。
     */
    swimBrakeSpeed: number;
    /**
     * 游泳最大速度。
     */
    swimSpeed: number;
    /**
     * 解除一层状态写入锁，并在全部解锁后应用最后缓存状态。
     * @pitfall 必须与 lockCharacterStateSet 成对调用，额外 unlock 会使计数为负。
     */
    unlockCharacterStateSet(): void;
    /**
     * 角色当前速度向量。
     */
    velocity: mw.Vector;
    /**
     * 最大可行走坡面角度。
     */
    walkableFloorAngle: number;
    /**
     * 地面最大加速度。
     */
    walkAcceleration: number;
    /**
     * 地面制动减速度。
     */
    walkBrakeSpeed: number;
    /**
     * 地面最大移动速度。
     */
    walkSpeed: number;
  }

  /**
   * 配置曲线移动的追踪目标
   * @category movement
   */
  class CurveMovementComponent extends MovementComponent implements IHomingMovementComponent {
    /**
     * 是否追踪目标。
     */
    homing: boolean;
    /**
     * 当前追踪目标实体。
     */
    homingTarget: IEntity;
  }

  /**
   * 提供已标注的运行态能力
   * @category movement
   */
  class MovementComponent extends InternalLifeComponent {
    /**
     * 将给定向量累加到当前速度；存在 AbilitySystem 且带有摇杆移动禁用标签时忽略本次累加。
     */
    addMovement(direction: mw.Vector): void;
    /**
     * 是否在每次应用位移时把宿主朝向更新为本帧移动目标方向。
     */
    applyDirectionToRotation: boolean;
    /**
     * 更新阶段允许的最大速度长度。
     */
    maxSpeed: number;
    /**
     * 当前组件是否在更新阶段应用移动。
     * 写入不同值时更新内部状态并广播内部启用状态事件；写入相同值不产生效果。
     */
    movementEnable: boolean;
    /**
     * 立即把本组件保存的速度三个分量清零。
     */
    stopMovementImmediately(): void;
    /**
     * 宿主实体的变换组件，用于读取或修改移动所依据的世界变换。
     */
    readonly transformComponent: TransformComponent;
    /**
     * 当前移动速度向量；更新阶段会按 `maxSpeed` 限制其长度。
     * @pitfall getter 返回内部可变 Vector，原地修改会直接改变内部速度。
     */
    velocity: mw.Vector;
  }

  /**
   * 驱动物理投射运动
   * @category movement
   */
  class PhysicMovementComp extends MovementComponent implements IHomingMovementComponent {
    /**
     * 加速度。
     */
    acceleration: number;
    /**
     * 为当前速度叠加一个移动向量。
     */
    addMovement(direction: mw.Vector): void;
    /**
     * 物理移动配置；持久化键名保持 config，面板/能力使用 showConfig。
     */
    config: PhysicMovementConfig;
    /**
     * 重力缩放。
     */
    gravityScale: number;
    /**
     * 是否追踪目标。
     */
    homing: boolean;
    /**
     * 追踪加速度。
     */
    homingAcceleration: number;
    /**
     * 追踪目标实体。
     */
    homingTarget: IEntity;
    /**
     * 初始速度。
     */
    initialSpeed: number;
    /**
     * 是否使旋转跟随速度方向。
     */
    isRotationFollowsVelocity: boolean;
    /**
     * 按给定速度或缓存速度启动物理移动。
     */
    launch(velocity?: undefined | mw.Vector): void;
    /**
     * 是否在组件启动后立即发射。
     */
    launchWhenStart: boolean;
    /**
     * 最大速度。
     */
    maxSpeed: number;
    /**
     * 是否启用物理移动。
     */
    movementEnable: boolean;
    /**
     * 碰撞后的速度保留比例。
     */
    speedRetention: number;
    /**
     * 当前速度。
     */
    velocity: mw.Vector;
  }

  /**
   * 控制实体转向移动
   * @category movement
   */
  class SteeringMoveControlComp extends MoveControlComp {
    /**
     * 转向行为可累计的最大合力。
     */
    maxForce: number;
    /**
     * 使实体沿方向或朝目标实体方向移动指定时长。
     */
    moveBy(direction: mw.Vector | IEntity, duration?: number): MoveByBehavior | Promise<unknown>;
    /**
     * 使实体移动到目标位置或目标实体附近。
     */
    moveTo(position: mw.Vector | IEntity, radius?: number): void;
    /**
     * 使实体转向指定游戏对象。
     */
    rotateTo(target: string): void;
  }
}

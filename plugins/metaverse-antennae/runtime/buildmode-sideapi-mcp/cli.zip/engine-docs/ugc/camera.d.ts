// AI Export Declarations (camera) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category camera
   */
  enum CameraPresetConfig {
    Custom = "Custom",
    FirstPerson = "FirstPerson",
    ThirdPerson = "ThirdPerson",
    Horizontal = "Horizontal",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category camera
   */
  class CameraPresetRule {
    "armLength": number;
    "AttchHeight": number;
    "bAttachToEye": boolean;
    "cameraOffsetY": number;
    "cameraOffsetZ": number;
    clone(): CameraPresetRule;
    "collisionEnabled": boolean;
    "DownAngleLimit": number;
    "FieldOfView": number;
    "HorizontalOffset": number;
    "LeftHorizontalAngle": number;
    "movementDirection": mw.MovementDirection;
    "movementFaceDirection": mw.MoveFacingDirection;
    "RightHorizontalAngle": number;
    "SmoothValue": number;
    "UpAngleLimit": number;
    "useControllerRotation": boolean;
    "Zoom": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category camera
   */
  class CameraPresetRule_Horizontal {
    "cameraOffsetY": number;
    "cameraOffsetZ": number;
    clone(): CameraPresetRule_Horizontal;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category camera
   */
  enum CameraSwitchType {
    Player = 0,
    Scene = 1,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category camera
   */
  class TrackPointInfo {
    "durationTime": number;
    "transform": mw.Transform;
  }

  /**
   * 提供已标注的运行态能力
   * @category camera
   */
  class CameraComponent extends InternalLifeComponent {
    /**
     * 将当前玩家相机挂接到本组件实体。
     *
     * 仅在客户端且本组件属于本地受控实体时生效。规则要求贴合眼睛且实体是角色时挂到眼睛插槽，
     * 否则挂到实体本身；场景相机、无玩家控制器、无当前相机或形象编辑状态下不执行挂接。
     * @pitfall 场景相机、非本地受控实体、缺少玩家控制器/当前相机或形象编辑状态下会静默返回，不会改变挂接关系。
     */
    applyAttachCamera(rule: CameraPresetRule, bUpdateControllerRotation?: boolean): void;
    /**
     * 由服务端异步获取所属玩家客户端的当前相机前向。
     * @pitfall 非服务端、缺少玩家控制器或玩家对象时返回 `null`；RPC 返回类型当前仍为弱类型。
     */
    asyncGetCameraForward(): Promise<any>;
    /**
     * 当前摄像机预设类型。
     *
     * 在服务端写入时会按预设重建当前规则，并把规则同步到客户端应用；构建环境只保存配置值。
     */
    cameraPresetConfig: CameraPresetConfig;
    /**
     * 自定义摄像机预设规则。
     *
     * 写入时克隆传入规则并把预设类型切换为 `Custom`；服务端运行路径随后同步并应用新的当前规则。
     * 读取返回当前保存的自定义规则对象。
     */
    cameraPresetRule: CameraPresetRule;
    /**
     * 横版摄像机使用的弹簧臂局部偏移规则。
     * @pitfall 当前 setter 会把 `cameraPresetConfig` 切换为 `Custom`；调用后应读取实际预设并按项目需求确认结果。
     */
    cameraPresetRule_horizontal: CameraPresetRule_Horizontal;
    /**
     * 当前实际应用的摄像机规则；修改字段后调用 `updateCameraPresetConfig` 才会完整应用。
     * @pitfall 直接修改规则字段只改变内存对象，不会自动把新规则应用到相机或同步到另一端。
     */
    currentUseCameraRule: CameraPresetRule;
    /**
     * 获取运镜前缓存的相机；未处于运镜时返回当前相机。
     */
    getCurrentCamera(): mw.Camera;
    /**
     * CameraComponent 是否已完成初始化，供外部（如 CustomJoystick）在就绪前查询。
     */
    isJoystickReady: boolean;
    /**
     * 让指定实体开始驱动当前玩家的运镜。
     */
    playCameraMovement(player: IEntity, entity: IEntity): void;
    /**
     * 设置当前相机是否固定俯仰角。
     * @pitfall 当前相机不存在时只记录警告并返回，设置不会生效。
     */
    setCameraFixedElevation(player: IEntity, val: boolean): void;
    /**
     * 设置当前相机弹簧臂的世界位置。
     * @pitfall 当前相机不存在时只记录警告并返回，位置不会改变。
     */
    setSpringArmWorldLocation(player: IEntity, location: mw.Vector): void;
    /**
     * 按世界方向设置当前相机弹簧臂旋转，并在需要时同步控制器旋转。
     * @pitfall 当前相机不存在时只记录警告并返回，旋转不会改变。
     */
    setSpringArmWorldRotation(player: IEntity, _direction: mw.Vector): void;
    /**
     * 停止当前玩家运镜，并使用给定时长过渡回原相机。
     */
    stopCameraMovement(player: IEntity, durationTime: number): void;
    /**
     * 在玩家摄像机与场景摄像机之间切换，并应用对应规则。
     */
    switchCamera(player: IEntity, cameraType: CameraSwitchType, useControllerRotation: boolean): void;
    /**
     * 把摄像机规则复制为当前规则并应用到角色移动与本地相机。
     */
    updateCameraPresetConfig(player: IEntity, rule: CameraPresetRule, bUpdateControllerRotation: any): void;
  }

  /**
   * 控制相机轨道播放组件的启用状态
   * @category camera
   */
  class CameraMovementComponent extends InternalLifeComponent {
    /**
     * 组件是否启用；关闭时同时停止正在播放的本地相机轨道。
     */
    enable: boolean;
  }

  /**
   * 配置相机移动轨道点
   * @category camera
   */
  class TrackComponent extends InternalLifeComponent {
    /**
     * 轨道点配置列表。
     */
    trackPointInfoList: Array<TrackPointInfo>;
  }
}

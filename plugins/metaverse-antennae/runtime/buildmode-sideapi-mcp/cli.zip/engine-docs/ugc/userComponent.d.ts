
declare namespace  ugc{
    class UserComponentRuntimeBase extends InternalLifeComponent {
        
        public entity: IEntity;
        
        protected   onComponentStarted():void;
        
        protected  onComponentUpdate(dt:number):void;
        
        protected  onComponentDestroy();
    
        protected  log(...args: any[]):void;
        protected  error(...args: any[]):void;
        protected  warn(...args: any[]):void;
    }
}

// AI Export Declarations (test) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * 标识内部测试组件类型
   * @category test
   */
  class TestComp extends UComponent {
  }
}

// AI Export Declarations (ui) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  enum AvatarTargetKind {
    LocalPlayer = "localPlayer",
    RankSlot = "rankSlot",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  class BindableProperty<T> {
    bindTo(target: any, key: string, converter?: undefined | ((v: T) => any)): void;
    bindToMethod(target: any, setter: (target: any, value: T) => void, initialValue?: undefined | T): void;
    bindToStaticMethod(staticMethod: (value: T) => void, initialValue?: undefined | T): void;
    clear(): void;
    forceCallCustomSetter(v: T): void;
    forceSyncCurrentValueToBindTarget(): void;
    getBindTarget(): any;
    getWorldUIOwnerGuid(): string;
    getWorldUIOwnerIsPlayer(): boolean;
    getWorldUIOwnerKind(): "" | "player" | "scene";
    readonly "onChange": global_Action2;
    rebindTargetPreservingValue(target: any): boolean;
    resumeSync(): void;
    skipSync(): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  class CanvasData_Base {
    bindFrom(canvas: mw.Widget): void;
    bindTo(canvas: mw.Widget): void;
    copy(other: CanvasData_Base): void;
    destroy(): void;
    "generalProperties": CanvasProperties_General;
    "presentationKind": CanvasPresentationKind;
    readonly "runtimeCanvas": null | mw.Canvas;
    setVisible(visible: boolean): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  enum CanvasPresentationKind {
    ScreenStretch = "screenStretch",
    WorldFixedSize = "worldFixedSize",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  class CanvasProperties_General extends CustomUIProperties_Base {
    bindFrom(widget: mw.Widget): void;
    bindTo(canvas: mw.Widget): void;
    copy(other: CanvasProperties_General): void;
    "defaultShow": boolean;
    readonly "defaultShowProperty": BindableProperty<boolean>;
    destroy(): void;
    "name": string;
    onBindTo(widget: mw.Widget): void;
    "presentationKind": CanvasPresentationKind;
    "renderOpacity": number;
    readonly "renderOpacityProperty": BindableProperty<number>;
    "safeZoneShow": boolean;
    "worldCanvasHeight": number;
    "worldCanvasWidth": number;
    "zOrder": number;
    readonly "zOrderProperty": BindableProperty<number>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface ClientUIButtonRuntimeEvent {
    "ownerGuid": string;
    "surface": ClientUIRuntimeSurface;
    "widgetGuid": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  type ClientUIButtonRuntimeEventDelegate = UDelegate<(event: ClientUIButtonRuntimeEvent) => void>;

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface ClientUIRuntimeBindingState {
    "bound": boolean;
    "boundProperty": string;
    "sourceSummary": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface ClientUIRuntimeColorValue {
    "a": number;
    "b": number;
    "g": number;
    "r": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface ClientUIRuntimePropertyResult {
    "binding": ClientUIRuntimeBindingState;
    "code": ClientUIRuntimeResultCode;
    "effectiveValue": ClientUIRuntimePropertyValue;
    "message": string;
    "ok": boolean;
    "propertyPath": string;
    "target": ClientUIRuntimeTarget;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface ClientUIRuntimePropertySchema {
    "bindingSupported": boolean;
    "bound": boolean;
    "boundProperty": string;
    "enumValues": Array<number>;
    "exclusionReason": string;
    "maxValue": null | number;
    "minValue": null | number;
    "propertyPath": string;
    "schemaVersion": number;
    "valueKind": ClientUIRuntimePropertyValueKind;
    "writable": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface ClientUIRuntimePropertySchemaResult {
    "code": ClientUIRuntimeResultCode;
    "message": string;
    "ok": boolean;
    "properties": Array<ClientUIRuntimePropertySchema>;
    "runtimeDataType": string;
    "target": ClientUIRuntimeTarget;
    "targetKind": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  type ClientUIRuntimePropertyValue = null | string | number | false | true | ClientUIRuntimeVector2Value | ClientUIRuntimeColorValue;

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  enum ClientUIRuntimePropertyValueKind {
    String = "string",
    Number = "number",
    Boolean = "boolean",
    Vector2 = "vector2",
    Color = "color",
    Enum = "enum",
    AssetId = "assetId",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  enum ClientUIRuntimeResultCode {
    Success = "SUCCESS",
    ClientOnly = "CLIENT_ONLY",
    InvalidTarget = "INVALID_TARGET",
    TargetNotReady = "TARGET_NOT_READY",
    UnsupportedProperty = "UNSUPPORTED_PROPERTY",
    UnsupportedWidgetType = "UNSUPPORTED_WIDGET_TYPE",
    BoundProperty = "BOUND_PROPERTY",
    InvalidValue = "INVALID_VALUE",
    WriteFailed = "WRITE_FAILED",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  enum ClientUIRuntimeSurface {
    Screen = "screen",
    World = "world",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface ClientUIRuntimeTarget {
    "canvasGuid": string;
    "ownerGuid"?: undefined | string;
    "surface": ClientUIRuntimeSurface;
    "widgetGuid"?: undefined | string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface ClientUIRuntimeTargetResult {
    "code": ClientUIRuntimeResultCode;
    "message": string;
    "ok": boolean;
    "runtimeDataType": string;
    "target": ClientUIRuntimeTarget;
    "targetKind": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface ClientUIRuntimeVector2Value {
    "x": number;
    "y": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  class CustomUIData_Base {
    asyncSetImage(_imageTransitionType: string, _imageUrl: string): boolean;
    bindTo(widget: mw.Widget): void;
    copy(other: CustomUIData_Base): void;
    createWidget(): mw.Widget;
    "customUIRuntimePlacement": CustomUIRuntimePlacement;
    destroy(): void;
    "generalProperties": CustomUIProperties_General;
    getText(): string;
    initDefaultInfo(param: UIParam): void;
    onDestroy(): any;
    onEditorWidgetBeforeDestroy(): void;
    onEditorWidgetInitialized(_widget: mw.Widget): void;
    onEditorWidgetRestored(widget: mw.Widget): void;
    setFocus(): any;
    setImage(imageTransitionType: string, imageId: string): void;
    setText(newText: string): void;
    setVisible(bShow: boolean): void;
    "slotOperations": Array<UISlotOperation>;
    syncInstructionSlotsByCanvas(_canvasData?: undefined | null | CanvasData_Base): void;
    "worldUIOwnerGuid": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  class CustomUIProperties_Base {
    bindFrom(widget: mw.Widget): void;
    bindTo(widget: mw.Widget): void;
    copy(other: CustomUIProperties_Base): void;
    onBindTo(widget: mw.Widget): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  class CustomUIProperties_General extends CustomUIProperties_Base {
    bindFrom(widget: mw.Widget): void;
    bindTo(widget: mw.Widget): void;
    copy(other: CustomUIProperties_General): void;
    destroy(): void;
    "horizontalAlignment": mw.UIConstraintHorizontal;
    readonly "horizontalAlignmentProperty": BindableProperty<mw.UIConstraintHorizontal>;
    isRenderShearScaleAngleVisible(): boolean;
    isSizeVisible(): boolean;
    "name": string;
    readonly "nameProperty": BindableProperty<string>;
    onBindTo(widget: mw.Widget): void;
    "position": mw.Vector2;
    readonly "positionProperty": BindableProperty<mw.Vector2>;
    "renderOpacity": number;
    readonly "renderOpacityProperty": BindableProperty<number>;
    "renderScale": mw.Vector2;
    readonly "renderScaleProperty": BindableProperty<mw.Vector2>;
    "renderShear": mw.Vector2;
    readonly "renderShearProperty": BindableProperty<mw.Vector2>;
    "renderTransformAngle": number;
    readonly "renderTransformAngleProperty": BindableProperty<number>;
    "renderTransformPivot": mw.Vector2;
    readonly "renderTransformPivotProperty": BindableProperty<mw.Vector2>;
    setRenderShearScaleAngleEditable(editable: boolean): void;
    setSizeEditable(editable: boolean): void;
    "size": mw.Vector2;
    readonly "sizeProperty": BindableProperty<mw.Vector2>;
    updateWidgetPosition(): void;
    updateWidgetSize(): void;
    "verticalAlignment": mw.UIConstraintVertical;
    readonly "verticalAlignmentProperty": BindableProperty<mw.UIConstraintVertical>;
    "visibility": boolean;
    readonly "visibilityProperty": BindableProperty<boolean>;
    "zOrder": number;
    readonly "zOrderProperty": BindableProperty<number>;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  enum CustomUIRuntimePlacement {
    Invalid = 0,
    Screen = 1,
    World = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  enum DataBindFromType {
    Component = "component",
    UserProperty = "userProperty",
    GameProperty = "gameProperty",
    PlayerAvatar = "playerAvatar",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  enum EntityBindFromType {
    Player = "player",
    Scene = "scene",
    WolrdUIEntity = "WorldUIEntity",
    System = "system",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  enum HpVisibleMode {
    Hidden = "Hidden",
    Always = "Always",
    OnlyWhenHurt = "OnlyWhenHurt",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  class InternalGoComponent extends InternalLifeComponent {
    "_referenceCount": number;
    readonly "binder": mw.GameObject;
    readonly "canEverTick": boolean;
    readonly "canPersistentSerializedIgnore": boolean;
    readonly "gameObject": mw.GameObject;
    getIsAuthority(): boolean;
    getOccupy(context?: any): any;
    "id": string;
    readonly "internalBeselect": () => void;
    readonly "internalCloseDetailPanel": () => void;
    readonly "internalComponentAwake": () => void;
    readonly "internalComponentLateUpdate": (dt: number) => void;
    readonly "internalComponentStart": () => void;
    readonly "internalComponentUpdate": (dt: number) => void;
    readonly "internalDeselect": () => void;
    readonly "internalLiveBeselect": () => void;
    readonly "internalLiveDeselect": () => void;
    readonly "internalOnActivate": () => void;
    readonly "internalOnDeactivate": () => void;
    readonly "internalOnDestroy": () => void;
    readonly "internalOnGameModeChanged": (from: string, to: string) => void;
    readonly "internalOpenDetailPanel": () => void;
    "isAuthority": boolean;
    isPersistentSerialized(str: string): boolean;
    "name": string;
    notSupportLazyInitInBuild(): boolean;
    onDestroyed(): void;
    onEditorActiveUpdate(dt: number): void;
    onEditorSelectedUpdate(dt: number): void;
    onSyncPresetAfterDeserialize(): void;
    "ownership": ComponentOwnership;
    preSyncPreset(): void;
    "stateFlag": number;
    supportLazyInit(): boolean;
    "tickEnable": boolean;
    "useEditorSelectedUpdate": boolean;
    readonly "version": string;
    readonly "versionChangedCallback": (fromVersion: string, toVersion: string, component: InternalComponent) => void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  class PropertyBindFromHelper {
    "abilityName": string;
    "avatarRankSlot": number;
    "avatarTargetKind": AvatarTargetKind;
    "bindPropertyName": string;
    checkCanSelect(selected: IEntity): boolean;
    clone(): PropertyBindFromHelper;
    confirm(aggregator: IAggregator): void;
    copy(source: PropertyBindFromHelper): void;
    "customPropertyDisplayName": string;
    "dataBindFrom": DataBindFromType;
    delete(aggregator: IAggregator): void;
    "entityBindFrom": EntityBindFromType;
    "entityPropertyKey": string;
    "gamePropertyKey": string;
    isPlayerAvatarBind(): boolean;
    "propertyName": string;
    readonly "propertyType": Array<UIComponentType>;
    "targetSceneItem": string;
    "useBigNumberFormat": boolean;
    "userPropertyKey": string;
    "version": string;
    "versionChangedCallback": (fromVersion: string, toVersion: string, obj: PropertyBindFromHelper) => PropertyBindFromHelper;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface UIParam {
    "bDeserialize": boolean;
    "ConfigId": number;
    "IconId"?: undefined | string;
    "Path": string;
    "Type": number;
    "TypeId": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  enum UISlotOperation {
    MOVE = 0,
    SCALE = 1,
    COPY = 2,
    ROTATE = 3,
    TEXT = 4,
    NONE = 5,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  class WorldUIBaseComponent extends InternalGoComponent {
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface WorldUIBindingRepTarget {
    serverPushBindingChange(widgetGuid: string, propertyName: string, value: unknown, uiInstId: string): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ui
   */
  interface WorldUIReplicator {
    serverPushInstructionCanvasVisible(canvasGuid: string, bShow: boolean, ownerEpoch?: undefined | string, revision?: undefined | number): void;
    serverPushInstructionImage(canvasGuid: string, widgetGuid: string, imageTransitionType: string, imageId: string, ownerEpoch?: undefined | string, revision?: undefined | number): void;
    serverPushInstructionText(canvasGuid: string, widgetGuid: string, text: string, ownerEpoch?: undefined | string, revision?: undefined | number): void;
    serverPushInstructionWidgetVisible(canvasGuid: string, widgetGuid: string, bShow: boolean, bAutoShowCanvasWhenWidgetShow: boolean, bUseZOrder: boolean, zOrder: number, ownerEpoch?: undefined | string, revision?: undefined | number): void;
  }

  /**
   * 显示游戏版本更新公告
   * @category ui
   */
  class GameUpdateComponent extends InternalLifeComponent {
  }

  /**
   * 提供已标注的运行态能力
   * @category ui
   */
  class HeadUIComponent extends InternalLifeComponent {
    /**
     * 血条尺寸百分比，面板范围为 0 到 150。
     */
    hpBarSize: number;
    /**
     * 头顶血条的显示模式。
     */
    hpVisibleMode: HpVisibleMode;
    /**
     * 是否显示实体名称。
     */
    nameVisible: boolean;
    /**
     * 按当前阵营配置刷新头顶血条颜色。
     * @pitfall 非客户端、WorldUI 尚未创建或组件已失效时调用会静默返回，血条颜色不会改变。
     */
    refreshColor(): void;
    /**
     * 头顶 UI 相对默认位置的高度偏移，单位厘米。
     */
    uiHeight: number;
  }

  /**
   * 操作屏幕与世界 UI
   * @category ui
   */
  class UIModuleSystem {
    /**
     * 等待指定玩家客户端返回 UI 文本；玩家无效或等待 5 秒仍未返回时解析为空字符串。
     * @pitfall 玩家无效或等待超时时不会拒绝 Promise，而是返回空字符串，无法仅凭结果区分空文本与读取失败。
     */
    awaitInstructionGetText(player: mw.Player, canvasGuid: string, widgetGuid: string, operateObjId?: undefined | string): Promise<string>;
    /**
     * 清除本客户端 AI 属性层；未绑定时恢复记录的下层值，已绑定时保留绑定有效值。
     */
    clearClientUIRuntimeProperty(target: ClientUIRuntimeTarget, propertyPath: string): ClientUIRuntimePropertyResult;
    /**
     * 读取目标 UI 属性的当前有效值；若已绑定，同时返回绑定状态。
     */
    getClientUIRuntimeProperty(target: ClientUIRuntimeTarget, propertyPath: string): ClientUIRuntimePropertyResult;
    /**
     * 查询目标控件允许读取/写入的 canonical 属性路径及当前绑定状态。
     */
    getClientUIRuntimePropertySchema(target: ClientUIRuntimeTarget): ClientUIRuntimePropertySchemaResult;
    /**
     * 获取由子系统初始化流程登记的 UIModule 单例。
     * @pitfall `initialize()` 执行前底层单例仍为 `undefined`，直接调用返回值上的方法会失败。
     */
    static readonly ins: UIModuleSystem;
    /**
     * 为指定玩家加载并显示 CustomUI Canvas，可选择应用显示层级。
     */
    net_instruction_loadCustomUI(player: mw.Player, canvasGuid: string, bUseZOrder: boolean, zOrder: number): void;
    /**
     * 设置指定玩家的 Screen UI Canvas 显隐状态，并可更新显示层级。
     */
    net_instruction_setScreenCanvasVisible(player: mw.Player, canvasGuid: string, bShow: boolean, bUseZOrder: boolean, zOrder: number): void;
    /**
     * 设置指定玩家的 Screen UI 图片控件资源。
     */
    net_instruction_setScreenImage(player: mw.Player, canvasGuid: string, widgetGuid: string, imageTransitionType: string, imageId: string): void;
    /**
     * 设置指定玩家的 Screen UI 文本控件内容。
     */
    net_instruction_setScreenText(player: mw.Player, canvasGuid: string, widgetGuid: string, newText: string): void;
    /**
     * 设置指定玩家的 Screen UI Widget 显隐状态，并可在显示 Widget 时自动显示所属 Canvas。
     */
    net_instruction_setScreenWidgetVisible(player: mw.Player, canvasGuid: string, widgetGuid: string, bShow: boolean, bAutoShowCanvasWhenWidgetShow: boolean, bUseZOrder: boolean, zOrder: number): void;
    /**
     * 设置 World UI Canvas 显隐状态。
     */
    net_instruction_setWorldCanvasVisible(player: null | mw.Player, canvasGuid: string, bShow: boolean, operateObjId: string, bToAllClient: boolean, worldUIEntityHint?: undefined | IEntity): void;
    /**
     * 设置 World UI 图片控件资源。
     */
    net_instruction_setWorldImage(player: null | mw.Player, canvasGuid: string, widgetGuid: string, imageTransitionType: string, imageId: string, operateObjId: string, bToAllClient: boolean, worldUIEntityHint?: undefined | IEntity): void;
    /**
     * 设置 World UI 文本控件内容。
     */
    net_instruction_setWorldText(player: null | mw.Player, canvasGuid: string, widgetGuid: string, newText: string, operateObjId: string, bToAllClient: boolean, worldUIEntityHint?: undefined | IEntity): void;
    /**
     * 设置 World UI Widget 显隐状态，并可在显示 Widget 时自动显示所属 Canvas。
     */
    net_instruction_setWorldWidgetVisible(player: null | mw.Player, canvasGuid: string, widgetGuid: string, bShow: boolean, bAutoShowCanvasWhenWidgetShow: boolean, operateObjId: string, bToAllClient: boolean, bUseZOrder: boolean, zOrder: number, worldUIEntityHint?: undefined | IEntity): void;
    /**
     * 为指定玩家的 Screen UI Widget 播放透明度补间；透明度会裁剪到 `[0,1]`。
     */
    net_instruction_tweenScreenTransparency(player: mw.Player, canvasGuid: string, widgetGuid: string, startTransparency: number, endTransparency: number, time: number): void;
    /**
     * 为 World UI Widget 播放透明度补间；透明度会裁剪到 `[0,1]`。
     */
    net_instruction_tweenWorldTransparency(player: null | mw.Player, canvasGuid: string, widgetGuid: string, startTransparency: number, endTransparency: number, time: number, operateObjId: string, bToAllClient: boolean): void;
    /**
     * 为指定玩家卸载 CustomUI Canvas 及其运行态数据。
     */
    net_instruction_unLoadUI(player: mw.Player, canvasGuid: string): void;
    /**
     * Button 通过现有按压准入并完成原点击逻辑后触发。监听方须用 widgetGuid/ownerGuid 过滤并在自身生命周期结束时移除监听。
     */
    readonly onClientUIButtonClicked: UDelegate<(event: ClientUIButtonRuntimeEvent) => void>;
    /**
     * Button 通过现有 CD 准入并完成原按下逻辑后触发。监听方须用 widgetGuid/ownerGuid 过滤并在自身生命周期结束时移除监听。
     */
    readonly onClientUIButtonPressed: UDelegate<(event: ClientUIButtonRuntimeEvent) => void>;
    /**
     * Button 通过现有按压准入并完成原释放逻辑后触发。监听方须用 widgetGuid/ownerGuid 过滤并在自身生命周期结束时移除监听。
     */
    readonly onClientUIButtonReleased: UDelegate<(event: ClientUIButtonRuntimeEvent) => void>;
    /**
     * 查询客户端运行时 UI 目标是否已经物化，并返回规范化 GUID。
     */
    queryClientUIRuntimeTarget(target: ClientUIRuntimeTarget): ClientUIRuntimeTargetResult;
    /**
     * 在本客户端设置未绑定的运行时 UI 属性。绑定属性返回 BOUND_PROPERTY，且不会写 Store 或 UI。
     */
    setClientUIRuntimeProperty(target: ClientUIRuntimeTarget, propertyPath: string, value: ClientUIRuntimePropertyValue): ClientUIRuntimePropertyResult;
  }

  /**
   * 显示并设置世界文本
   * @category ui
   */
  class WorldTextComponent extends WorldUIBaseComponent {
    /**
     * 文本背景颜色。
     */
    bgColor: mw.LinearColor;
    /**
     * 是否显示文本背景。
     */
    bgVisible: boolean;
    /**
     * 文本颜色。
     */
    color: mw.LinearColor;
    /**
     * 显示的文本内容。
     */
    contentText: string;
    /**
     * 字符间距。
     */
    fontLetterSpace: number;
    /**
     * 文本字形。
     */
    glyph: mw.UIFontGlyph;
    /**
     * 文本水平对齐方式。
     */
    horizontalAlign: mw.TextJustify;
    /**
     * 文本垂直对齐方式。
     */
    verticalAlign: mw.TextVerticalJustify;
    /**
     * 当前文本 UI 是否满足显示条件。
     */
    readonly visibleCondition: boolean;
  }

  /**
   * 提供已标注的运行态能力
   * @category ui
   */
  class WorldUIComponentV2 extends InternalLifeComponent {
    /**
     * 2026-07-24 16:10:00 从 V2 `_REPDATA` 读取文本指令最终态；
     * 原因：获取世界 UI 文本全员分支读服务端权威。Plan：docs/plan/ui-get-text-instruction-plan.md
     */
    getInstructionText(canvasGuid: string, widgetGuid: string): undefined | string;
  }
}

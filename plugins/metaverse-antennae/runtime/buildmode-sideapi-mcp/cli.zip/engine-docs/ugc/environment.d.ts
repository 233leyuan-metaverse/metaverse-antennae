// AI Export Declarations (environment) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category environment
   */
  class PointLightConfig {
    "attenuationExponent": number;
    "attenuationRadius": number;
    "color": mw.LinearColor;
    "enable": boolean;
    "intensity": number;
    "lightName": string;
    "localTransform": mw.Transform;
  }

  /**
   * 配置实体点光源列表
   * @category environment
   */
  class PointLightMgrComponent extends InternalLifeComponent {
    /**
     * 点光源配置列表。
     */
    pointLightConfigs: Array<PointLightConfig>;
  }

  /**
   * 提供已标注的运行态能力
   * @category environment
   */
  class WaterVolumeComponent extends InternalLifeComponent {
    /**
     * 水体深层颜色；写入时复制颜色值并由服务端同步客户端。
     * @pitfall getter 返回内部可变颜色对象；原地修改不会经过 setter 的应用与同步流程。
     */
    deepColor: mw.LinearColor;
    /**
     * 水体流体摩擦标量，默认值为 `0.3`；运行态写入不做范围裁剪。
     * 写入后立即更新已绑定水体，并由服务端向客户端同步该值。
     */
    fluidFriction: number;
    /**
     * 是否启用水体浮力，默认值为 `false`。
     * 写入后立即更新已绑定水体，并由服务端向客户端同步该值。
     */
    ifUseBuoyancy: boolean;
    /**
     * 当前水体预设，默认值为 `WaterPreset.Default_2D`。
     * 已绑定水体时写入会应用预设并由服务端同步；未绑定水体时只保存配置值。
     */
    preset: mw.WaterPreset;
    /**
     * 是否渲染水下效果，默认值为 `true`。
     * 写入后立即更新已绑定水体，并由服务端向客户端同步该值。
     */
    renderUnderWater: boolean;
    /**
     * 水体浅层颜色；写入时复制颜色值并由服务端同步客户端。
     * @pitfall getter 返回内部可变颜色对象；原地修改不会经过 setter 的应用与同步流程。
     */
    surfaceColor: mw.LinearColor;
    /**
     * 水体透射/透明标量，默认值为 `0.3`；Inspector 范围为 `[0, 1]`，运行态写入不做裁剪。
     * 写入后立即更新已绑定水体，并由服务端向客户端同步该值。
     */
    transparency: number;
    /**
     * 水体密度标量，默认值为 `10`；Inspector 范围为 `[0, 10000]`，运行态写入不做裁剪。
     * 写入后立即更新已绑定水体，并由服务端向客户端同步该值。
     */
    volumeDensity: number;
    /**
     * 传给水体 `flowAngle` 的水波方向标量，默认值为 `0`。
     * Inspector 范围为 `[0, 1]`，运行态写入不做裁剪；服务端会同步该值。
     */
    waveAngle: number;
    /**
     * 水波法线平坦度标量，默认值为 `0.06`；Inspector 范围为 `[0, 1]`，运行态写入不做裁剪。
     * 写入后立即更新已绑定水体，并由服务端向客户端同步该值。
     */
    waveIntensity: number;
    /**
     * 传给水体 `flowSpeed` 的水波速度标量，默认值为 `30`。
     * Inspector 范围为 `[0, 300]`，运行态写入不做裁剪；服务端会同步该值。
     */
    waveSpeed: number;
    /**
     * 传给水体 `flowTile` 的水波平铺标量，默认值为 `3000`。
     * Inspector 范围为 `[0, 3000]`，运行态写入不做裁剪；服务端会同步该值。
     */
    waveTilling: number;
  }
}

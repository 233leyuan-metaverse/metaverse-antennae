// AI Export Declarations (interaction) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * 提供已标注的运行态能力
   * @category interaction
   */
  class InteractiveProcessComponent extends InternalLifeComponent {
    /**
     * 是否在进入交互范围后自动触发交互，而不显示按钮。
     */
    autoInteract: boolean;
    /**
     * 交互按钮使用的图标资源 ID。
     */
    buttonUIAssetIdReal: string;
    /**
     * 交互按钮显示的文本；纯数字字符串会在客户端按语言表 ID 解析。
     */
    buttonUIName: string;
    /**
     * 是否允许交互；关闭时隐藏按钮，重新开启时恢复范围内玩家的按钮。
     * @pitfall 服务端重新开启时会为当前重叠实体补发显示 RPC；客户端直接写入只恢复本地玩家按钮。
     */
    enableInteract: boolean;
    /**
     * 是否启用交互次数限制。
     */
    enableWithTimes: boolean;
    /**
     * 剩余可交互次数；写入非正数时隐藏交互按钮。
     */
    interactTimes: number;
    /**
     * 服务端验证取消交互并执行取消指令时触发。
     */
    readonly onButtonCanceled: UDelegate<(executor: IEntity) => void>;
    /**
     * 服务端验证交互成功并执行点击指令时触发。
     */
    readonly onButtonClicked: UDelegate<(executor: IEntity) => void>;
  }

  /**
   * 提供已标注的运行态能力
   * @category interaction
   */
  class SceneGatherComponent extends InternalLifeComponent {
    /**
     * 采集完成后创建或授予的运行时预设资源 ID。
     */
    autoCreateRuntimeAsset: string;
    /**
     * 单次采集数量；写入后同步交互按钮上的拾取数量。
     */
    onceGatherAmount: number;
    /**
     * 根据执行端播放采集物向执行者移动的表现。
     */
    playGatherMovement(playAtServer: boolean, executor?: undefined | IEntity): void;
    /**
     * 在服务端为指定执行实体启动一次采集。
     * 组件禁用、执行实体无效、采集数量非正数，或在线环境下距离、并发锁、阵营校验失败时不启动采集。
     */
    startGather(executor: IEntity): void;
  }

  /**
   * 监听触发区域进出
   * @category interaction
   */
  class TouchDetectorComponent extends TriggerComponent implements ILazyWakeCapable {
    /**
     * 是否允许触发区域执行进入与离开检测。
     * @pitfall 该字段控制业务检测；组件整体启停仍由继承的 enable 状态管理。
     */
    bEnable: boolean;
    /**
     * 查询指定实体当前是否通过检测条件并处于触发区域内。
     */
    checkInArea(entity: IEntity): boolean;
    /**
     * 是否把检测形状状态同步到客户端。
     */
    enableShapeReplicated: boolean;
    /**
     * 允许触发检测的阵营配置标识；写入后会重新检查当前重叠实体。
     */
    factionDetectTypes: string;
    /**
     * 返回当前通过检测条件且仍可解析的重叠实体快照。
     */
    getCurrentOverlapEntitiesSnapshot(): Array<IEntity>;
    /**
     * 根据宿主物体的包围盒计算触发区域的默认相对变换。
     */
    getDefaultTransform(): mw.Transform;
    /**
     * 单个实体在一次停留期间允许触发进入或离开逻辑的最大次数。
     */
    maxEventExecutionCount: number;
    /**
     * 实体通过检测条件并进入触发区域时广播。
     */
    readonly onEnterDelegate: UDelegate<(entity: IEntity, hitResult: mw.HitResult) => void>;
    /**
     * 已记录在触发区域内的实体离开或不再满足检测条件时广播。
     */
    readonly onLeaveDelegate: UDelegate<(entity: IEntity) => void>;
    /**
     * 检测区域辅助模型的透明度。
     */
    opacity: number;
    /**
     * 触发区域相对宿主实体的位置。
     */
    position: mw.Vector;
    /**
     * 触发区域的相对旋转。
     */
    rotation: mw.Rotation;
    /**
     * 运行态触发区域模型是否可见，默认值为 `false`。
     * 写入后更新复制字段并立即调用客户端模型刷新回调；该属性不改变触发检测是否启用。
     */
    runtimeVisible: boolean;
    /**
     * 触发区域的相对缩放。
     */
    scale: mw.Vector;
    /**
     * 基于宿主包围盒计算默认检测区域时使用的缩放倍率。
     */
    scaleMult: number;
    /**
     * 应用触发区域的相对变换并同步运行时检测形状。
     */
    setTransform(value: mw.Transform, path?: any, aggregator?: any): void;
    /**
     * 触发区域的基础形状；运行时写入会重建对应检测形状。
     */
    shape: TouchDetectShape;
    /**
     * 球形检测区域的直径，写入时同步更新区域缩放。
     */
    sphereDiameter: number;
    /**
     * 球形检测区域的半径，写入时同步换算为直径。
     */
    sphereRadius: number;
    /**
     * 触发区域相对宿主实体的完整变换。
     */
    transform: mw.Transform;
    /**
     * 触发区域的世界坐标位置。
     */
    worldPosition: mw.Vector;
  }

  /**
   * 控制运行时触发体
   * @category interaction
   */
  class TriggerComponent extends InternalLifeComponent {
    /**
     * 更新运行时触发区域的形状、尺寸与相对变换；触发体已创建时立即生效。
     * @pitfall 自定义形状需同时设置 bUseCustomShape、shape 与 customShapeGuid。
     */
    configureTriggerShape(data: TriggerShapeData): void;
    /**
     * 查询底层运行时触发体是否已经创建。
     */
    hasTriggerComponent(): boolean;
    /**
     * 设置运行时触发体的期望启用状态；触发体尚未创建时会保留该状态。
     */
    setTriggerEnabled(enabled: boolean): void;
  }
}

// AI Export Declarations (matchmaking) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * 提供已标注的运行态能力
   * @category matchmaking
   */
  class MatchAreaProcessComponent extends InternalLifeComponent {
    /**
     * 匹配/取消按钮使用的图标资源 ID。
     */
    buttonUIAssetId: string;
    /**
     * 已入队时显示的取消匹配按钮文案。
     */
    cancelMatchButtonText: string;
    /**
     * 未入队时显示的匹配按钮文案。
     */
    matchButtonText: string;
    /**
     * 开始匹配跳转所需人数；单机模式固定为 1，其余按关卡房间上限夹紧。
     */
    requiredCount: number;
    /**
     * 匹配成功后跳转的目标关卡文件名。
     */
    targetLevelFileName: string;
  }
}

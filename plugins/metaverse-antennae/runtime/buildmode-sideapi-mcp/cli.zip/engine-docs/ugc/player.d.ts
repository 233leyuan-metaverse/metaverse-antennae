// AI Export Declarations (player) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * 获取本地玩家控制器
   * @aiExport
   * @category player
   * @capability framework.player
   * @since 1.0
   */
  function getLocalPlayerController<T extends IPlayerController>(): T;

  /**
   * 获取本地玩家所在的场景  仅仅客户端可用
   * @aiExport
   * @category player
   * @capability framework.player
   * @since 1.0
   */
  function getLocalScene(): IScene;
}

// AI Export Declarations (ability) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  class AbilityDefine {
    "ability": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  class ComboAbilityInfo {
    "changeTime": number;
    "everyAbilityChangeTime": Map<number, number>;
    "resetTimer": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  interface ICloneable<T> {
    clone(): T;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  interface ICopyable<T> {
    copy(source: T): T;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  interface IDeSerializerObject {
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  interface IGameplayTagAsset {
    getOwnerAllTags(ret: TagContainer): boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  interface INetSerializable {
    postUnSerialize(): void;
    preSerialize(): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  interface ISerializeObject {
    preSerialize(): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  interface IVersionable<T> {
    "version": string;
    "versionChangedCallback": (fromVersion: string, toVersion: string, obj: T) => T;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  interface RuntimeComboItem {
    "abilityHandlers": Array<number>;
    "currentAbilityIndex": number;
    "info": ComboAbilityInfo;
    "inputId": number;
    "resetTimerHandler": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  enum SkillAutomaticReleaseMode {
    Close = "Close",
    WhenEnemyInRange = "WhenEnemyInRange",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  enum SkillReleaseTarget {
    Enemy = "Enemy",
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  class SkillSlotConfig {
    "abilityUuid": string;
    "automaticReleaseMode": SkillAutomaticReleaseMode;
    "enemyInRange": number;
    "enemyInRangeNew": number;
    readonly "isAvailable": boolean;
    readonly "name": string;
    "releaseTarget": SkillReleaseTarget;
    readonly "skillUuid": string;
    "slotIndex": number;
    "slotState": SkillSlotState;
    "uiSlotIndex": number;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category ability
   */
  enum SkillSlotState {
    Empty = "Empty",
    Equipped = "Equipped",
  }

  /**
   * 保存建造态技能编辑上下文
   * @category ability
   */
  class SkillEditComponent extends InternalLifeComponent {
  }

  /**
   * 管理技能槽与技能授予
   * @category ability
   */
  class SkillMgrComponent extends UComponent {
    /**
     * 创建一个空技能槽并返回槽位索引。
     */
    createSkillSlot(): number;
    /**
     * 查找空技能槽；没有时自动创建。
     */
    findEmptySlot(): number;
    /**
     * 按内部槽位索引查询技能槽。
     */
    getSkillSlot(slotIndex: number): null | SkillSlotConfig;
    /**
     * 按技能资源 UUID 查询技能槽。
     */
    getSkillSlotByAbilityUuid(uuid: string): null | SkillSlotConfig;
    /**
     * 按 UI 槽位索引查询技能槽。
     */
    getSkillSlotWithUISlotIndex(uiSlotIndex: number): null | SkillSlotConfig;
    /**
     * 将技能授予实体并放入指定 UI 槽位。
     * @pitfall 必须在服务端调用；技能资源不存在时不会授予。
     */
    giveAbility(uuid: string | AbilityDefine, uiSlotIndex: number): void;
    /**
     * 按技能 UUID 移除技能。
     */
    removeAbility(abilityId: string): boolean;
    /**
     * 设置技能槽自动释放模式。
     */
    setSlotAutoReleaseMode(slotIndex: number, mode: SkillAutomaticReleaseMode): boolean;
    /**
     * 设置技能槽索敌范围。
     */
    setSlotEnemyRange(slotIndex: number, range: number): boolean;
    /**
     * 设置技能槽释放目标类型。
     */
    setSlotReleaseTarget(slotIndex: number, target: SkillReleaseTarget): boolean;
    /**
     * 当前技能槽配置列表。
     */
    readonly SkillConfigs: Array<SkillSlotConfig>;
    /**
     * 技能槽配置列表。
     */
    skillSlots: Array<SkillSlotConfig>;
    /**
     * 技能槽数据版本。
     */
    readonly version: string;
  }

  /**
   * 提供已标注的运行态能力
   * @category ability
   */
  class UAbilitySystemComponent extends AbilitySystemComponent {
    /**
     * 处理本地能力输入；连招未消费时转交基础能力系统。
     */
    abilityLocalInputPressed(inputId: number): void;
    /**
     * 按能力规格句柄尝试推进并激活所属连招。
     *
     * 只有句柄位于某棵连招树的当前索引时才会尝试激活；该包装方法不返回成功结果。
     */
    activateAbilityBySpecHandler(specHandler: AbilitySpecHandle): void;
    /**
     * 按输入 ID 查询连招当前节点或普通已授予技能规格。
     *
     * 未找到匹配规格时返回 `null`。
     */
    getAbilitySpecWithInputId(inputId: number): GameplayAbilitySpec;
    /**
     * 最近一次激活且带 UGC Skill 标签的能力 UUID。
     *
     * 在尚未记录符合条件的能力时为空字符串。
     */
    lastActivatedAbilityUUID: string;
    /**
     * 连招当前能力索引发生变化时触发。
     *
     * 成功推进连招或超时重置到起点时广播当前运行项；同一连招可重复触发。
     * 监听方须在自身生命周期结束时取消监听。
     */
    readonly onComboAbilityChanged: UDelegate<(comboItem: RuntimeComboItem) => void>;
    /**
     * 注册一棵连招树。
     *
     * 服务端保存输入命令、时间配置和有序能力句柄，并同步给对应客户端；重复输入命令会由连招系统记录错误并忽略。
     */
    registerComboTree(inputCommand: number, info: ComboAbilityInfo, abilityHandlers: Array<number>): void;
    /**
     * 移除指定输入命令的连招树。
     *
     * 方法会清理运行计时、输入锁和复制项；服务端同时通知客户端移除。
     */
    removeComboTree(inputCommand: number): void;
  }
}

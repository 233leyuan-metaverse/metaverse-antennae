// AI Export Declarations (data) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category data
   */
  interface Inline_f8f50ea69a {
    "gameObjectId"?: undefined | string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category data
   */
  class UGCSet_EditData {
    gridDragSwitch(): boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category data
   */
  class UGCSet_RoomData {
    readonly "aoiDistanceSquard": number;
    goLevelSettings(): false;
    "isFirstInitGameMode": boolean;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category data
   */
  class UGCSet_SystemData {
    InitData(): void;
    migrateFromSceneCustomProperties(): void;
    "showBagBtn": boolean;
    "showGameResetBtn": boolean;
    "showRoleBtn": boolean;
    syncCustomPropertiesToScene(): void;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category data
   */
  class UGCSetData {
    adoptRoomData(data: UGCSet_RoomData): void;
    applySharedFromFile(editData: UGCSet_EditData, systemData: UGCSet_SystemData): void;
    clearSharedFromFile(): void;
    readonly "editData": UGCSet_EditData;
    getLegacyEditData(): UGCSet_EditData;
    getLegacySystemData(): UGCSet_SystemData;
    isSharedFromFile(): boolean;
    readonly "roomData": UGCSet_RoomData;
    switchToSharedWorkingCopy(cloneEdit: (s: UGCSet_EditData) => UGCSet_EditData, cloneSystem: (s: UGCSet_SystemData) => UGCSet_SystemData): void;
    readonly "systemData": UGCSet_SystemData;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category data
   */
  type UgcSetSharedSnapshot = {
    "editData": UGCSet_EditData;
    "systemData": UGCSet_SystemData;
  };

  /**
   * 提供已标注的运行态能力
   * @category data
   */
  class GameCustomPropertyComponent extends InternalLifeComponent {
    /**
     * 按 schema 键读取当前游戏属性值。
     * @pitfall 泛型 T 由调用方断言且未知键实际返回 null；应先调用 hasGameCustomProperty 并使用工程 schema 对应类型。
     */
    getGameCustomProperty<T>(key: string): Promise<T>;
    /**
     * 查询运行态游戏属性 schema 是否包含指定键。
     *
     * 该查询只检查已加载的 schema，不读取属性值，也不触发远端刷新。
     */
    hasGameCustomProperty(key: string): boolean;
    /**
     * 按运行态 schema 写入指定游戏属性。
     *
     * 专端客户端会把写入路由到服务端权威实例；其余环境直接更新当前实例内存，并按字段配置触发
     * 复制、变更通知与防抖持久化。该方法返回时不保证远端调用、复制或 DataStorage 写入已经完成。
     */
    setGameCustomProperty(key: string, value: string | number | false | true | Array<unknown> | Inline_f8f50ea69a): void;
  }

  /**
   * 加载与保存 UGC 共享设置
   * @category data
   */
  class UGCSetComponent extends InternalLifeComponent {
    /**
     * 捕获当前编辑与系统设置的共享快照。
     */
    captureSharedSnapshot(): UgcSetSharedSnapshot;
    /**
     * 等待共享设置加载完成并与当前关卡 registry 对齐。
     */
    ensureSharedReady(): Promise<void>;
    /**
     * 通知共享设置已变更并触发防抖保存。
     */
    notifySharedSettingsChanged(): void;
    /**
     * 将共享设置保存到工程 DataFile。
     */
    saveUgcSetSharedToDataFile(immediate?: boolean): Promise<boolean>;
    /**
     * 场景边界的最低高度。
     */
    sceneNadir: number;
    /**
     * 当前关卡的 UGC 设置数据。
     */
    ugcSetData: UGCSetData;
  }
}

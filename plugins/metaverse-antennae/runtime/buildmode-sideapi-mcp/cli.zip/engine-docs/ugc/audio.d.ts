// AI Export Declarations (audio) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category audio
   */
  interface ISoundComponent {
    "assetID": string;
    "onFinish": UDelegate<() => void>;
    "onPause": UDelegate<() => void>;
    "onPlay": UDelegate<() => void>;
    pause(bPause?: undefined | false | true): void;
    play(startTime?: undefined | number, onSuccess?: undefined | (() => void)): void;
    playSound(): void;
    readonly "playState": mw.SoundPlayState;
    stop(): void;
    stopSound(): void;
    readonly "timeLength": number;
  }

  /**
   * 配置角色运动音效和 NPC 待机随机语音
   * @category audio
   */
  class CharacterSoundComponent extends InternalLifeComponent {
  }

  /**
   * 创建并控制实体音效
   * @category audio
   */
  class SoundComponent extends UComponent implements ISoundComponent {
    /**
     * 音效资源 ID。
     */
    assetID: string;
    /**
     * 创建并绑定音效对象。
     */
    createSound(assetGUID: string): Promise<void>;
    /**
     * 是否循环播放。
     */
    isLoop: boolean;
    /**
     * 是否启用空间音效。
     */
    isSpatialization: boolean;
    /**
     * 音效播放结束事件。
     */
    readonly onFinish: UDelegate<() => void>;
    /**
     * 音效暂停事件。
     */
    readonly onPause: UDelegate<() => void>;
    /**
     * 音效开始播放事件。
     */
    readonly onPlay: UDelegate<() => void>;
    /**
     * 暂停或恢复播放。
     */
    pause(bPause?: boolean): void;
    /**
     * 从指定时间开始播放已创建的音效。
     */
    play(startTime?: undefined | number, onSuccess?: undefined | (() => void)): void;
    /**
     * 根据当前资源和属性创建并播放音效。
     */
    playSound(): Promise<void>;
    /**
     * 当前播放状态。
     */
    readonly playState: mw.SoundPlayState;
    /**
     * 停止播放。
     */
    stop(): void;
    /**
     * 停止当前配置音效。
     */
    stopSound(): void;
    /**
     * 音效总时长。
     */
    readonly timeLength: number;
    /**
     * 音量，范围为 0 到 1。
     */
    volume: number;
  }

  /**
   * 标识实体的音效覆盖组件
   * @category audio
   */
  class SoundOverrideComponent extends InternalLifeComponent {
  }
}

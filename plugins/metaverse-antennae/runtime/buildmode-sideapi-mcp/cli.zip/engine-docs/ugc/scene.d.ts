// AI Export Declarations (scene) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @category scene
   * @capability framework.scene
   * @since 1.0
   */
  function getCurrentScene(): any;

  /**
   * @aiExport
   * @since 1.0
   * @category scene
   */
  enum SpawnCalcDirectionType {
    RANDOM_DIRECTION = 0,
    FACE_INTERACTOR = 1,
    ENTITY_FRONT = 2,
  }

  /**
   * @aiExport
   * @since 1.0
   * @category scene
   */
  class SpawnConfig {
    "delaytime"?: undefined | number;
    "SpawnAssetId": string;
    "SpawnCount": number;
  }

  /**
   * 管理建造态组合节点
   * @category scene
   */
  class MultiNodeComponent extends InternalLifeComponent {
  }

  /**
   * 批量生成场景实体
   * @category scene
   */
  class SceneSpawnComponent extends UComponent {
    /**
     * 开始生成时触发。
     */
    beginSpawnDelegate: mw.MulticastDelegate<(spawnAssetId: string, spawnCount: number, executor: IEntity) => void>;
    /**
     * 完成生成时触发。
     */
    endSpawnDelegate: mw.MulticastDelegate<(spawnAssetId: string, spawnCount: number, executor: IEntity) => void>;
    /**
     * 按组件配置生成实体。
     */
    spawn(): void;
  }
}

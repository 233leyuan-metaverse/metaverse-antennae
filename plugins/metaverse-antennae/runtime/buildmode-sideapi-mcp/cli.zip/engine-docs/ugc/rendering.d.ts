// AI Export Declarations (rendering) — revision: 90e12ed20d5a7777a7040368cc0d953c47d539b399e46ac3536fee697e169aec
// 自动生成，请勿手改。源：component-ai-export-spec v2.5
declare namespace ugc {
  /**
   * @aiExport
   * @since 1.0
   * @category rendering
   */
  interface IModelComponent {
    getMaterialInfo(): Array<MaterialParameters>;
    getMaterialInfoBySlot(index: number): MaterialParameters;
    getSlotColor(index: number): mw.LinearColor;
    getSlotCount(): number;
    getSlotMaterialID(index: number): string;
    "materialInfo": Array<MaterialParameters>;
    "modelColor": mw.LinearColor;
    "modelOpacity": number;
    "modelShadow": boolean;
    setMaterialInfo(mList: Array<MaterialParameters>): void;
    setMaterialInfoBySlot(index: number, material: MaterialParameters): void;
    setSlotColor(index: number, color: mw.LinearColor): void;
    setSlotMaterialID(index: number, materialID: string): void;
    setSlotTextureID(index: number, textureID: string): void;
    "staticMeshAsset": string;
  }

  /**
   * @aiExport
   * @since 1.0
   * @category rendering
   */
  class MaterialParameters {
    "bEnableLerp": boolean;
    "bEnableLerp_Common": boolean;
    "breathColor": mw.LinearColor;
    "breathFrequency": number;
    clone(targetMaterialParams: MaterialParameters, updateChanged?: undefined | ((propName?: undefined | string) => void)): void;
    "defaultMatID": string;
    "lerpColor0": mw.LinearColor;
    "lerpColor1": mw.LinearColor;
    "lerpDirection": number;
    "lerpDirection_Color": mw.LinearColor;
    "lerpOffset": number;
    "lerpOffset_Valid": number;
    "lerpRange": number;
    "lerpRange_Valid": number;
    "main_TileX": number;
    "main_TileY": number;
    "metallic": number;
    "roughness": number;
    "saturation": number;
    "slotColor": mw.LinearColor;
    "slotIndex": number;
    "slotMaterialID": string;
    "slotTextureID": string;
    "textureOffsetX": number;
    "textureOffsetY": number;
  }

  /**
   * 控制模型资源、显示与材质插槽
   * @category rendering
   */
  class ModelComponent extends InternalLifeComponent implements IModelComponent {
    /**
     * 读取当前模型的全部材质插槽参数。
     */
    getMaterialInfo(): Array<MaterialParameters>;
    /**
     * 读取并刷新指定插槽的材质参数。
     */
    getMaterialInfoBySlot(index: number): MaterialParameters;
    /**
     * 读取指定插槽颜色；索引越界时返回全零颜色。
     */
    getSlotColor(index: number): mw.LinearColor;
    /**
     * 返回模型的材质插槽数量。
     */
    getSlotCount(): number;
    /**
     * 读取指定插槽材质资源 ID；索引越界时返回空字符串。
     */
    getSlotMaterialID(index: number): string;
    /**
     * 当前模型全部材质插槽参数；写入时按数组顺序应用到各插槽。
     */
    materialInfo: Array<MaterialParameters>;
    /**
     * 模型整体颜色；模型没有可用材质插槽时读取结果可能为空。
     */
    modelColor: mw.LinearColor;
    /**
     * 模型不透明度，面板范围为 0 到 1；写入后同步阴影状态。
     */
    modelOpacity: number;
    /**
     * 模型是否允许投射阴影；透明度接近零时仍会关闭实际阴影。
     */
    modelShadow: boolean;
    /**
     * 以当前模型插槽资源重置默认材质 ID。
     */
    resetDefaultMatID(): void;
    /**
     * 按数组顺序把材质参数应用到模型插槽。
     */
    setMaterialInfo(mList: Array<MaterialParameters>): void;
    /**
     * 把材质、贴图、颜色和数值参数应用到指定插槽。
     */
    setMaterialInfoBySlot(index: number, material: MaterialParameters): void;
    /**
     * 设置指定插槽颜色；索引越界时不执行。
     */
    setSlotColor(index: number, color: mw.LinearColor): void;
    /**
     * 设置指定插槽材质资源 ID；索引越界时不执行。
     */
    setSlotMaterialID(index: number, materialID: string): void;
    /**
     * 创建材质实例并设置指定插槽的贴图资源 ID。
     * @pitfall 索引越界时可能在访问 `materialIns.slotTextureID` 处失败，而不是返回 `false`。
     */
    setSlotTextureID(index: number, textureID: string): boolean;
    /**
     * 当前静态模型资源 ID；写入后异步下载并替换模型资源。
     */
    staticMeshAsset: string;
    /**
     * 模型可见状态；写入时同步到子实体上的模型组件。
     */
    visibleState: any;
  }
}
